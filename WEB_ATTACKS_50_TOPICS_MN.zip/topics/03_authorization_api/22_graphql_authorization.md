# 22. GraphQL Authorization — Query resolver-ийн эрхийн алдаа

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** GraphQL query-ийн өөр өөр field/resolver дээр authorization consistent биш байх.
- **Хаана шалгах?** `/graphql`, `node(id:)`, `user(id:)`, nested fields, mutations.
- **Аюулгүй жишээ:**
  ```graphql
  query {
    viewer { id displayName }
  }
  ```
  Өөрийн user-ийн `viewer`-ийг normal user ба anonymous context-д харьцуул; nested **өөрийн** test object-р шалга.
- **Яаж таних?** Unauthorized resolver private value буцаавал confirmed; schema introspection ажиллах нь дангаараа vulnerability биш.
- **Хэрхэн засах?** Resolver-level auth for objects/fields, depth/complexity limits, per-tenant restrictions.
