# 18. Vertical Privilege Escalation — Role өсгөх

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Normal user manager/admin-only мэдээлэл, функцэд зөвшөөрөлгүй хандах.
- **Хаана шалгах?** Admin menu hidden routes, API roles, reports, approval screens.
- **Аюулгүй жишээ:** Өөрийн `viewer` user-аас `/reports/internal`-г нээгээд ижил request-ийг `admin` test session-тай харьцуул.
- **Яаж таних?** Role-оор хамгаалах ёстой мэдээлэл viewer-д ирсэн бол vulnerability; UI-д цэс нуух нь authorization биш.
- **Хэрхэн засах?** Least privilege, per-endpoint server-side RBAC/ABAC policy, deny-by-default.
