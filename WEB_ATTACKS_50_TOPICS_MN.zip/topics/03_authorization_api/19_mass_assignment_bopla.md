# 19. Mass Assignment / BOPLA — Илүүдэл property өөрчлөх

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** JSON request-ийн сервер удирдах ёстой `role`, `approved`, `ownerId` зэрэг field-г client дур мэдэн тохируулна. **BOPLA** = Broken Object Property Level Authorization.
- **Хаана шалгах?** `PATCH /api/me`, `PUT /api/users/{id}`, create/update DTO.
- **Аюулгүй жишээ:**
  ```http
  PATCH /api/me HTTP/1.1
  Host: 127.0.0.1:8080
  Content-Type: application/json

  {"displayName":"LAB_TEST","isAdmin":true}
  ```
- **Яаж таних?** Өөрийн test user-ийн `isAdmin` үнэхээр `true` болсон эсэхийг **өөрийн** subsequent GET-ээр шалга. JSON echo эсвэл `200` дангаараа хангалтгүй.
- **Хэрхэн засах?** Explicit writable-field allowlist, per-field authorization, never bind request directly to privileged database model.
