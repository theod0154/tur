# 17. BFLA — Broken Function Level Authorization

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Энгийн user зөвхөн admin хийх ёстой function/API-г дуудна.
- **Хаана шалгах?** `/api/admin/*`, role management, user enable/disable, export endpoints.
- **Аюулгүй жишээ:** Өөрийн admin lab-д `GET /api/admin/settings`-ийг normal-user test session-ээр шалга; state-changing admin action бүү ажиллуул.
- **Яаж таних?** Admin-only confidential settings нормал user-т харагдсан бол evidence. `403` биш `404`-ийг зориуд хэрэглэсэн байж болно — access deny бол сайн.
- **Хэрхэн засах?** Server-side function permission matrix, authorization middleware, role-based tests.
