# 20. Tenant Isolation — Байгууллага хоорондын тусгаарлалтын алдаа

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** SaaS олон tenant-тэй үед A байгууллагын user B tenant-ийн объект руу орно.
- **Хаана шалгах?** `/api/tenants/{id}/`, organization header, projects, invoices, multi-tenant search.
- **Аюулгүй жишээ:** Зөвхөн өөрийн test Tenant-A / Tenant-B үүсгээд A token-оор B-ийн `LAB_TENANT_B` record-г **read-only** шалга.
- **Яаж таних?** B-ийн тусгаарлагдсан record A-д харагдвал батлагдана; global public catalog байвал boundary-г урьдчилан тогтоо.
- **Хэрхэн засах?** Tenant ID-г trusted auth context-оос авах, every query-д tenant predicate, row-level security, cross-tenant tests.
