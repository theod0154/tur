# 21. Excessive Data Exposure — API илүүдэл мэдээлэл буцаах

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** UI-д харуулахгүй боловч API response-д unnecessary private fields ирнэ; front-end шүүхээр security хангахгүй.
- **Хаана шалгах?** `/api/users`, mobile API, reports, GraphQL object selection.
- **Аюулгүй жишээ:** Өөрийн profile API JSON-д `internalNote`, `resetToken`, `salary` зэрэг **зөвшөөрөгдөөгүй** field байгаа эсэхийг DevTools Network-оор хар.
- **Яаж таних?** Field ирсэн нь автоматаар flaw биш; normal user-д очих ёсгүй sensitive value эсэхийг policy-тай тулгана. Бусдын мэдээлэл татах шаардлагагүй.
- **Хэрхэн засах?** Response DTO allowlist, field-level authorization, data minimization.
