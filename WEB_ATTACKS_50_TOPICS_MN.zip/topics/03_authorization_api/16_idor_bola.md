# 16. IDOR / BOLA — Object-level эрхийн алдаа

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Client-ийн `id`-г солиход server тухайн объектын owner/permission-г шалгаагүй. **IDOR** = Insecure Direct Object Reference; API-д **BOLA** = Broken Object Level Authorization гэж нэрлэдэг.
- **Хаана шалгах?** `/api/orders/{id}`, `/files/{id}`, `?userId=`, invoices, profile, GraphQL node IDs.
- **Аюулгүй жишээ (2 өөрийн user):**
  ```http
  GET /api/notes/101 HTTP/1.1
  Host: 127.0.0.1:8080
  Cookie: session=USER_A_TEST_SESSION
  ```
  `101`-ийг User B-ийн **өөрийн урьдчилан үүсгэсэн** note ID болгож ганц request явуул.
- **Яаж таних?** A session B-ийн note-ийн `LAB_B_PRIVATE` marker-ийг **уншиж/өөрчилж** байвал confirmed. `200` боловч зөвхөн public/empty wrapper гарвал IDOR биш.
- **Хэрхэн засах?** Every object access дээр server-side policy (`requested_object.owner == current_user` эсвэл tenant/ACL rule), default deny; UUID нь authorization орлохгүй.
