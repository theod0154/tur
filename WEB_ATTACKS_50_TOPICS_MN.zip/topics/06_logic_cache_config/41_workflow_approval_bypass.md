# 41. Workflow / Approval Bypass — Алхам алгасах

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Батлах, төлөх, и-мэйл verify хийх гэх мэт заавал давах state machine-г алгасч final state-д очих.
- **Хаана шалгах?** Signup activation, checkout steps, approval workflow, KYC-like demo flow.
- **Аюулгүй жишээ:** Өөрийн demo request-г `DRAFT → REVIEW → APPROVED` state дарааллаар шалга; `DRAFT` state-тай record-ийн `GET /status`-д **зөвхөн read-only** шалгалт хий.
- **Яаж таних?** Unapproved test record өөрөө authorized биш атлаа final state авсан эсвэл restricted benefit бодитоор олдсон бол flaw.
- **Хэрхэн засах?** Server-side state transition rules, per-step authorization, immutable audit trail.
