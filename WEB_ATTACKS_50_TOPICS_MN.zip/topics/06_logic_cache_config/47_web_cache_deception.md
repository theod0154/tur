# 47. Web Cache Deception — Private content public cache path-аар алдагдах

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Dynamic private response-г static file мэт URL/path ашиглан shared cache-д хадгалуулна.
- **Хаана шалгах?** Authenticated routes, cache extension rules (`.css`, `.js`), CDN behavior.
- **Аюулгүй жишээ:** Тусгаарласан lab-д өөрийн private `LAB_A_ONLY` response cache-д хадгалагдах эсэхийг хоёр **өөрийн** session-ээр шалга; shared production cache бүү бохирдуул.
- **Яаж таних?** Anonymous/B test session A-ийн өөрийн private marker-г cache-аас авсан бол батлагдана. Cache header өөрөө proof биш.
- **Хэрхэн засах?** Private path caching disable, origin cache headers enforce, consistent URL parsing between CDN and origin.
