# 46. Web Cache Poisoning — Shared cache-г хортой content-оор дүүргэх

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Cache key-д ороогүй request input (жишээ header) response-д нөлөөлж, дараагийн user-д ижил хариу serve болно.
- **Хаана шалгах?** Reverse proxy/CDN dynamic endpoints, `X-Forwarded-Host`, reflected headers.
- **Аюулгүй жишээ:** **Private isolated cache lab**-д `X-Lab-Canary: ABC` хүсэлт явуулж ижил cache key-ийн дараагийн anonymous response-д **өөрийн** `ABC` marker орж байгааг шалга.
- **Яаж таних?** Response reflection биш, **request-гүй дараагийн response cache-д хадгалагдсаныг** control-test-аар нотол. Public CDN-д poison хийхгүй.
- **Хэрхэн засах?** Cache key canonicalization, untrusted input-ийн response influence-ийг арилгах, caching policy hardening.
