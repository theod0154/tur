# 49. Prototype Pollution — JavaScript object prototype бохирдох

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Untrusted object deep merge-ийн үед `__proto__` зэрэг key JavaScript object-ийн inherited properties-д нөлөөлнө.
- **Хаана шалгах?** JSON merges, URL query-to-object parser, settings/state libraries.
- **Аюулгүй жишээ:** **Зөвхөн өөрийн JS lab**-д plain benign `{ "__proto__": { "labMarker": "yes" } }` объект merge хийх test unit ажиллуул; production object-д mutation хийхгүй.
- **Яаж таних?** Шинэ, unrelated plain object `labMarker` inherited болсон бол pollution батлагдана; exploit impact хүрэх **separate sink** байгаа эсэхийг дараа үнэл.
- **Хэрхэн засах?** Unsafe deep merge арилгах, `__proto__`/`constructor`/`prototype` хориглох, safe parsers, `Object.create(null)` where appropriate.
