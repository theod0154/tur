# 43. Verbose Errors / Debug Exposure

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Debug stack trace, environment config, filesystem paths, internal IP, secrets response-д ил болдог.
- **Хаана шалгах?** Invalid input error pages, `/debug`, monitoring/status pages, API errors.
- **Аюулгүй жишээ:** Өөрийн lab-ийн `?id=not-a-number` request-г **ганц** удаа илгээж structured error response-г шалга.
- **Яаж таних?** Stack trace дангаараа context-specific information disclosure; secret/reusable credential/unsafe debug action илэрвэл ноцтой. Error 500 дангаараа vulnerability биш.
- **Хэрхэн засах?** Production debug off, generic errors, structured logging with secret redaction, restrict debug/admin endpoints.
