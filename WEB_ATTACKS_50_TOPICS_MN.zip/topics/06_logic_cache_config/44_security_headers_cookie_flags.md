# 44. Security Headers / Cookie Flags

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Browser хамгаалалт дутуу: `HttpOnly`, `Secure`, `SameSite`, CSP, HSTS зэрэг буруу/алга.
- **Хаана шалгах?** `Set-Cookie`, `Content-Security-Policy`, `Strict-Transport-Security`, `X-Content-Type-Options`.
- **Аюулгүй жишээ:**
  ```bash
  curl -sS -D - -o /dev/null "$LAB/"
  ```
- **Яаж таних?** Cookie-ийн `Secure` production HTTPS-д байхгүй бол risk; **local HTTP lab-д** зориудаар байхгүй байж болно. Missing header бол severity-г threat model-оор үнэл — header absence дангаараа exploit батлахгүй.
- **Хэрхэн засах?** HTTPS + HSTS, `Secure; HttpOnly; SameSite=Lax/Strict` тохируулга, CSP, `nosniff`, correct cache policy.
