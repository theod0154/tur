# 40. Price / Coupon Logic — Үнийн бизнес дүрэм алдагдах

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Client-side price/discount-д server итгэдэг, coupon limits/quantity policy буруу шалгадаг.
- **Хаана шалгах?** Cart, checkout, discounts, loyalty, gift balance.
- **Аюулгүй жишээ:** Өөрийн lab захиалгад `unitPrice`-ийг client request-д зориудаар өөрчлөөд **payment хийхгүйгээр** quote response-г үз.
- **Яаж таних?** Server trusted catalog-аас тооцох ёстой үнээ client price-аар сольсон бол strong evidence; UI харагдах үнэ өөрчлөгдөх нь баталгаа биш.
- **Хэрхэн засах?** Price/tax/discount totals-г server-side authoritative data-аас тооцох, invariant checks, idempotency.
