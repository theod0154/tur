# 45. Sensitive Caching — Private response cache-д хадгалагдах

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Private API response browser эсвэл shared proxy cache-д буруу хадгалагдаж, өөр context-д өртөх.
- **Хаана шалгах?** `/account`, `/api/me`, statements, auth responses, CDN routes.
- **Аюулгүй жишээ:** Өөрийн session-ээс private request-ийн `Cache-Control`, `Vary`, `Age`, `X-Cache` header-ийг харьцуул.
- **Яаж таних?** `X-Cache: HIT` дангаараа data leak биш; **өөрийн хоёр test account**-ын private marker cross-user буцаж байвал батлагдана.
- **Хэрхэн засах?** Sensitive responses `Cache-Control: no-store`, correct CDN bypass, `Vary` by appropriate keys, user-specific responses never shared.
