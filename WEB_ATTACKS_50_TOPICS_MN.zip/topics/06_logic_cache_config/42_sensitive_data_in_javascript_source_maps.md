# 42. Sensitive Data in JavaScript / Source Maps

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Public JS bundle эсвэл `.map`-д production secret, token, internal code/context алдагдсан.
- **Хаана шалгах?** `/static/*.js`, `*.js.map`, sourceMappingURL, mobile config.
- **Аюулгүй жишээ:** Өөрийн lab front-end bundle-д зориуд хийсэн `LAB_PUBLIC_MARKER` хай; **жинхэнэ олдсон credential-ийг ашиглаж шалгахгүй**.
- **Яаж таних?** `apiKey` нэртэй бүх string secret биш (public identifier байж болно). Үнэхээр privileged secret, sensitivity, scope-ийг owner-той баталгаажуул.
- **Хэрхэн засах?** Secrets client bundle-д оруулахгүй, credentials rotate, production source map access policy, CI secret scanning.
