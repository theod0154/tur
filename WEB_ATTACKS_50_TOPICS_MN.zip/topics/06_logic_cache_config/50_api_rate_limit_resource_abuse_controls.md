# 50. API Rate-Limit / Resource Abuse Controls

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Нэг user/client хэт олон resource-expensive request хийхэд abuse protections байхгүй.
- **Хаана шалгах?** OTP delivery, search, report export, invitation, expensive GraphQL queries.
- **Аюулгүй жишээ:** Written-approved **very low** request quota дотор 2–3 controlled lab requests хийж documented `429`/backoff behavior ажигла. Public target дээр stress/DoS test хийхгүй.
- **Яаж таних?** `429` харагдахгүй нь автоматаар flaw биш; app policy, endpoint cost, business impact, counters-аар үнэлнэ.
- **Хэрхэн засах?** Per-identity/IP/context quotas, exponential backoff, queue limits, GraphQL complexity budget, monitoring.
