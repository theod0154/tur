# 48. WebSocket Authorization / Cross-Site WebSocket Hijacking

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** WebSocket connection upgrade эсвэл channel subscription-д user/Origin/room authorization шалгаагүй.
- **Хаана шалгах?** `/ws`, chat subscriptions, notifications, real-time dashboards.
- **Аюулгүй жишээ:** Өөрийн хоёр account ашиглан A session-ээр B-ийн **өөрийн** test room subscription-г хүс; cross-origin connection-д cookie auto-sent эсэхийг браузераар шалга.
- **Яаж таних?** A session B room-ийн private test message авбал authorization flaw. `Origin` шалгалт алга байх нь автоматаар cross-site hijacking батлахгүй; credential delivery-г шалга.
- **Хэрхэн засах?** Upgrade + each message/channel authorization, Origin allowlist, session/token validation, tenant checks.
