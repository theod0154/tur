# 07. CORS Misconfiguration — Cross-Origin Resource Sharing буруу тохируулга

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Browser бусад origin-д хандах үед response унших эрхийг server хэт өргөн олгох. CORS бол server-side authorization орлуулагч биш.
- **Хаана шалгах?** Authenticated API, `Access-Control-Allow-Origin`, `Access-Control-Allow-Credentials`, `Origin` header.
- **Аюулгүй жишээ:**
  ```bash
  curl -i -H 'Origin: http://127.0.0.1:3000' "$LAB/api/me"
  ```
- **Яаж таних?** `ACAO` дотор arbitrary origin буцаасан нь **сэжиг**. Бодит эрсдэл нь browser JS authenticated *sensitive* response-г унших боломжтой эсэх (`credentials: include`, cookies, SameSite, response body, CSP etc.)-ээр тодорхойлогдоно. `ACAO: *` + credentials нь browser-д хүчинтэй credentialed access болдоггүй.
- **Хэрхэн засах?** Exact origin allowlist, `Vary: Origin`, зөвхөн хэрэгтэй үед credential sharing, public ба private API-г тусгаарлах.
