# 01. Reflected XSS — Хариунд шууд туссан JavaScript

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Хэрэглэгчийн input тухайн HTTP response-д шүүгдэхгүй буцаж, browser түүнийг JavaScript гэж ажиллуулна. Жишээ нь хайлтын мөрийн утга HTML болж хувирах.
- **Хаана шалгах?** `/search?q=`, `/error?message=`, filters, URL query, зарим HTTP headers.
- **Аюулгүй жишээ (local lab):**
  ```http
  GET /search?q=%3Csvg%20onload%3Dalert(1)%3E HTTP/1.1
  Host: 127.0.0.1:8080
  ```
  Энэ payload зөвхөн lab tab-д `alert(1)` ажиллуулах зорилготой; жинхэнэ сайт руу хэрэглэхгүй. Эхлээд `XSS_LAB_01` marker-аар reflection-ийг шалга.
- **Яаж таних?** `View Source` / DevTools **Elements** дээр payload executable DOM болсон, `alert(1)` тухайн **response-оос** ажилласан бол батлах боломжтой. Зүгээр текстээр харагдах нь XSS биш; Content Security Policy (CSP) хамгаалалт ажиллахгүй болгосон эсэхийг тэмдэглэ.
- **Хэрхэн засах?** Context-aware output encoding (HTML, attribute, URL, JS-д тус тусад нь), safe templating, DOM `textContent`; нэмэлт хамгаалалт болгон хатуу CSP.
