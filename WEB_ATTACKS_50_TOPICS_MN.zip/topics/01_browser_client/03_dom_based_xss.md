# 03. DOM-based XSS — Browser-side JavaScript-ийн алдаа

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Server response аюулгүй байсан ч front-end JS `location.hash`/`location.search`-ийг аюултай DOM sink (`innerHTML`) рүү дамжуулна.
- **Хаана шалгах?** JS router, hash fragments, client-side search, `innerHTML`, `document.write`, risky URL assignment.
- **Аюулгүй жишээ (lab source-ийг унш):**
  ```javascript
  // Эмзэг жишээ — кодыг production-д БҮҮ ашигла
  document.querySelector('#result').innerHTML = location.hash.slice(1);
  // Зөв хувилбар
  document.querySelector('#result').textContent = location.hash.slice(1);
  ```
- **Яаж таних?** URL `#<img src=x onerror=alert(1)>` рүү өөрчлөхөд **network response өөрчлөгдөхгүй атлаа** DOM дээр JS ажиллавал DOM XSS-ийн нотолгоо. Console-д CSP error байвал ялгаж тэмдэглэ.
- **Хэрхэн засах?** `textContent`, `createElement`, DOMPurify (HTML шаардлагатай үед), Trusted Types боломжтой бол хэрэглэх.
