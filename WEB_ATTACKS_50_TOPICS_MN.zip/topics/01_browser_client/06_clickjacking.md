# 06. Clickjacking — Харагдахгүй/давхарласан iframe-аар click хийлгэх

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Сайтыг өөр page-ийн iframe-д нууж/давхарлан хэрэглэгчээр санаандгүй товч даруулах.
- **Хаана шалгах?** Account settings, confirm buttons, billing action, permission dialogs; response-ийн `Content-Security-Policy: frame-ancestors` / `X-Frame-Options`.
- **Аюулгүй жишээ:**
  ```html
  <iframe src="http://127.0.0.1:8080/profile" width="800" height="500"></iframe>
  ```
- **Яаж таних?** Өөр origin-оос iframe-д page **ачаалж**, overlay click-ийн зорилтот элемент бодитоор ажиллах боломжтой байвал эрсдэлтэй. Frame дотор ачаалсан нь дангаараа high severity биш.
- **Хэрхэн засах?** `Content-Security-Policy: frame-ancestors 'none'` (эсвэл хатуу allowlist), legacy `X-Frame-Options`, өндөр эрсдэлтэй үйлдэлд баталгаажуулалт.
