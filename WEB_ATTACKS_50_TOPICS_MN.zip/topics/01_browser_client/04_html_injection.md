# 04. HTML Injection — HTML бүтэц оруулах

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Input HTML element болж дүрслэгдэнэ; заавал JavaScript ажиллахгүй. UI-г хуурамчаар харагдуулах, content хуурах эрсдэлтэй.
- **Хаана шалгах?** Search results, comment preview, username displays, template placeholders.
- **Аюулгүй жишээ:** `LAB_<b>bold</b>` гэсэн input-ыг local lab-д оруулах.
- **Яаж таних?** `<b>` бодит DOM element болсон боловч JS ажиллаагүй бол **HTML Injection**, XSS гэж шууд нэрлэхгүй. UI-д ямар нөлөөтэйг шалга.
- **Хэрхэн засах?** HTML encode, зөвхөн шаардлагатай tag/attribute-ийг sanitizer-аар allowlist хийх.
