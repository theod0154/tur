# 08. Open Redirect — Гадны сайт руу дур мэдэн чиглүүлэх

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** `next`, `returnUrl` гэх параметрээр хэрэглэгчийг баталгаагүй external destination руу redirect хийнэ; phishing-д ашиглагдаж болзошгүй.
- **Хаана шалгах?** Login callback, logout, SSO return paths, marketing links.
- **Аюулгүй жишээ:**
  ```bash
  curl -I "$LAB/redirect?next=https%3A%2F%2Fexample.com%2F"
  ```
- **Яаж таних?** `Location: https://example.com/` зөвшөөрөгдөөгүй үед илэрвэл open redirect. Сайтын зөвшөөрсөн outbound links байж болно; security impact-ийг login/OAuth зэрэг context-оор үнэл.
- **Хэрхэн засах?** Relative paths, exact origin allowlist, redirect token/map; user input-д URL-ийг шууд итгэхгүй.
