# 05. CSRF — Cross-Site Request Forgery

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Хэрэглэгч сайт руу login хийсэн байхад өөр website браузераар нь хүсэлт явуулж, хэрэглэгч хүсээгүй үйлдэл хийлгэнэ. Гол шалтгаан: cookie автоматаар хавсардаг байж болно.
- **Хаана шалгах?** Email/profile change, address update, preference save, account action зэрэг **state-changing** `POST`/`PUT`/`DELETE` болон бүр буруу `GET` endpoint.
- **Аюулгүй жишээ (өөрийн account + local lab):**
  ```html
  <!-- Өөрийн lab-д localhost дээр хадгалсан csrf-test.html -->
  <form method="POST" action="http://127.0.0.1:8080/profile/nickname">
    <input name="nickname" value="CSRF_LAB_ONLY">
    <button type="submit">Test my own profile</button>
  </form>
  ```
  Энэ HTML-ийг **өөр origin**-оос нээж, зөвхөн өөрийн test profile-д submit хий.
- **Яаж таних?** Authenticated browser-аас cross-site submit хийхэд anti-CSRF token/Origin/Referer validation-гүйгээр өөрийн profile **өөрчлөгдвөл** батлагдана. Cookie-ийн `SameSite=Lax/Strict`, `Secure`, request-ийн content type, browser behavior-ийг шалга. Зөвхөн CSRF token харагдахгүй байх нь нотолгоо биш.
- **Хэрхэн засах?** Server-side validated CSRF token, `Origin`/`Referer` validation, SameSite cookies, state-changing GET-г хориглох; AJAX API-д зөв authentication + explicit CORS.
