# 02. Stored XSS — Хадгалагддаг JavaScript

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Comment/profile гэх мэт талбарт хадгалсан input дараагийн удаа page нээгдэхэд JS болж ажиллах.
- **Хаана шалгах?** Comments, profile bio, support tickets, Markdown renderer, admin dashboard-т харагдах хэрэглэгчийн мэдээлэл.
- **Аюулгүй жишээ (өөрийн test record):**
  ```text
  Display name = <img src=x onerror=alert(1)>
  ```
  Зөвхөн өөрийн account-д хадгалаад **өөрийн** browser/session-д нээ.
- **Яаж таних?** Save хийхэд биш, **дахин ачаалсан page дээр** код ажиллана; хадгалагдсан утга HTML/DOM-д executable болсон байна. Markdown-д raw HTML дүрслэгдэх нь дангаараа XSS биш.
- **Хэрхэн засах?** Хадгалсан өгөгдөлд итгэхгүй; rendering үеийн context-aware encoding, HTML зөвшөөрөх бол sanitizer, strong CSP.
