# 37. Insecure Deserialization — Итгэлгүй serialized object сэргээх

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** User-controlled serialized bytes-г unsafe object parser/deserializer code path-д итгэн боловсруулдаг.
- **Хаана шалгах?** State cookies, signed/unsigned serialized blobs, backend queues, object import.
- **Аюулгүй жишээ:** Local lab-д unsigned serialized **benign** field-ийн value-г өөрчлөхөд server validation reject хийж байгаа эсэхийг шалга; gadget chain эсвэл RCE payload хэрэглэхгүй.
- **Яаж таних?** Input deserializer рүү орж trusted object state-г unauthorized өөрчилсөн бол evidence; Base64 string байх нь proof биш.
- **Хэрхэн засах?** Untrusted serialized object-с зайлсхийж JSON+schema хэрэглэх, cryptographic integrity, safe types allowlist, updated libraries.
