# 39. Race Condition — Нэгэн зэрэг request-ээс үүсэх логикийн алдаа

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Parallel request ижил shared state шалгаж, update хийхийн хооронд давхацсанаас business rule алдагдана.
- **Хаана шалгах?** One-time coupon, inventory reservation, redemption, approval, transfer simulation.
- **Аюулгүй жишээ:** **Тусгаарласан** lab-д synthetic token `LABCOUPON`-г хоёр test request-ээр зэрэг redeem хийж, database-ийн **өөрийн** counter `1`-ээс хэтэрсэн эсэхийг хар.
- **Яаж таних?** Expected exactly-one operation байхад controlled test-д `2` successful commits гарвал confirmed. Network timing төдийхөн нь proof биш; production дээр concurrency stress хийхгүй.
- **Хэрхэн засах?** Transactions, atomic constraints, unique keys, idempotency keys, locking/version checks.
