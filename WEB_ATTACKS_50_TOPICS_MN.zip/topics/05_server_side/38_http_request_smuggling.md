# 38. HTTP Request Smuggling — Proxy/backend request boundary зөрөх

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Front-end proxy ба backend HTTP request-ийн **хил**-ийг өөрөөр уншихад дараагийн request-д нөлөөлөх боломж үүснэ.
- **Хаана шалгах?** Reverse proxy + application server chain, HTTP/1.1 and HTTP/2 translation.
- **Аюулгүй жишээ:** Зөвхөн **single-user isolated lab**-д proxy/backend request framing болон parsed request count-ийг packet capture/log-оос харьцуул. Production/live shared connection руу smuggling payload илгээхгүй.
- **Яаж таних?** Parser disagreement лабораторийн log-д давтагдах ёстой. `400`, timeout, connection reset дангаараа request smuggling батлахгүй.
- **Хэрхэн засах?** Normalize/reject ambiguous framing, strict proxy/backend configurations, patched servers, consistent HTTP handling.
