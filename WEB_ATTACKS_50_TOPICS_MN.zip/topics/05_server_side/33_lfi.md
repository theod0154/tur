# 33. LFI — Local File Inclusion

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Local File Inclusion (LFI) нь хэрэглэгчийн input-г server-side include/template болгон ашиглаж local file-г unintended байдлаар include хийх.
- **Хаана шалгах?** `?page=`, `?template=`, language/content template routing.
- **Аюулгүй жишээ:** Lab-д өөрийн `/app/templates/lab-info.txt` бэлдээд `page=lab-info` болон зөвшөөрөгдөөгүй relative path-г харьцуул.
- **Яаж таних?** Allowlist-аас гаднах local marker-г app-ийн template inclusion уншсан бол evidence; ердийн static download нь LFI биш, traversal/data exposure байж болно.
- **Хэрхэн засах?** User-supplied filename-ээр include хийхгүй, fixed template allowlist, strict root confinement.
