# 34. RFI — Remote File Inclusion

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Remote File Inclusion (RFI) үед server external resource-ийг executable template/code хэлбэрээр include хийж болзошгүй.
- **Хаана шалгах?** Remote template/plugin configuration, legacy include features.
- **Аюулгүй жишээ:** Өөрийн isolated lab-д **inert текст** `RFI_LAB_MARKER` агуулсан local HTTP endpoint өгч remote fetching **эсвэл include** болж байгаа эсэхийг ажигла; executable code/remote shell бүү байрлуул.
- **Яаж таних?** Зөвхөн file fetch хийсэн нь RFI биш — server-side include/evaluation гэдгийг app log болон authorized lab trace-аар тусад нь нотол.
- **Хэрхэн засах?** Remote include feature унтраах, fixed signed templates/plugins, restrict network egress.
