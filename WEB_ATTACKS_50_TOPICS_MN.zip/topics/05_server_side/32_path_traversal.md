# 32. Path Traversal — Файлын замын хязгаараас гарах

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** `../`-ээр intended upload/download directory-гээс дээш шилжинэ.
- **Хаана шалгах?** `/download?file=`, template path, export filename, image renderer.
- **Аюулгүй жишээ:** Өөрийн lab storage-д `/app/public/report.txt`, `/app/lab-marker.txt` гэсэн **нууц биш** хоёр файл үүсгээд `file=../lab-marker.txt` шалга.
- **Яаж таних?** Intended `/app/public`-оос гаднах `LAB_MARKER` файл уншигдвал confirmed. `404` эсвэл reflected `../` нь proof биш.
- **Хэрхэн засах?** Path normalization + canonical base-dir confinement, static ID→file mapping, filesystem least privilege.
