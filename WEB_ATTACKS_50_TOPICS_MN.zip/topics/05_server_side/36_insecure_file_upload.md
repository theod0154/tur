# 36. Insecure File Upload — Файл upload баталгаажуулалтын алдаа

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Upload шалгалт хангалтгүйгээс аюултай file content executable эсвэл unrestricted public resource болж болно.
- **Хаана шалгах?** Avatar upload, document attachments, imports, image processing.
- **Аюулгүй жишээ:** Өөрийн lab-д **executables биш** `lab.txt` болон `lab.svg` (JS агуулаагүй) upload хийж storage location, MIME, download behavior шалга.
- **Яаж таних?** `.txt` content-г HTML гэж serve хийх зэрэг browser interpretation risk, private file public болох зэрэг policy violation-ийг тусад нь нотол. File extension accept хийх нь дангаараа critical vulnerability биш.
- **Хэрхэн засах?** File type validation by parser/magic bytes, safe re-encoding, non-executable separate storage, random names, `Content-Disposition: attachment`, strict access control.
