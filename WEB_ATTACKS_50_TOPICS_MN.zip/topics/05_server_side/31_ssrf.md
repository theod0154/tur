# 31. SSRF — Server-Side Request Forgery

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Client URL оруулж, серверээр өөр destination руу HTTP request явуулдаг; network boundary буруу давж болно.
- **Хаана шалгах?** Image URL fetch, webhook test, URL preview, PDF render, import from URL.
- **Аюулгүй жишээ (2 local service):** Lab application `127.0.0.1:8080`, **өөрийн** receiver `127.0.0.1:9001` дээр ажиллана. Lab-ийн URL-fetch параметрт `http://127.0.0.1:9001/lab-ping` өг. Container isolation/namespace өөр бол `127.0.0.1` нь өөр host заадаг болохыг сана.
- **Яаж таних?** Receiver log-д server-generated request ирсэн нь server-side fetch-ийг батална; **SSRF vulnerability** болох эсэх нь destination allowlist/security boundary зөрчсөн эсэхээс хамаарна. Cloud metadata/internal admin target руу бүү чиглүүл.
- **Хэрхэн засах?** URL scheme/host/IP allowlist, DNS resolve + revalidation, outbound network restrictions, redirect blocking, timeout.
