# 35. XXE — XML External Entity Injection

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** XML parser external entity resolve хийж server-ээр файл эсвэл remote resource уншуулах эрсдэлтэй.
- **Хаана шалгах?** XML/SOAP upload, SVG/XML parsing, document converters.
- **Аюулгүй жишээ:** Эхлээд local internal entity (`<!ENTITY marker "LAB_OK">`) parser боловсруулж буй эсэхийг шалга. Энэ нь **XXE биш**; зөвхөн зориуд бэлтгэсэн lab-д external entity-ийг өөрийн `127.0.0.1:9001` receiver рүү чиглүүлж хяна.
- **Яаж таних?** Local controlled receiver-д XML entity resolution-ээс request ирсэн нь external fetch нотолно; parser DOCTYPE зөвшөөрөх нь дангаараа file exfiltration болохгүй.
- **Хэрхэн засах?** DTD/external entities бүрэн disable, hardened XML parsers, egress restriction.
