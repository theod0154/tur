# 29. CRLF / HTTP Response Splitting — Header-д мөр таслах

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** `\r\n` буюу Carriage Return/Line Feed (CRLF) тэмдэгт header value-д орвол шинэ header/response structure үүсгэж болно.
- **Хаана шалгах?** `Location`, download filename, custom response headers, redirect parameter.
- **Аюулгүй жишээ:** Local lab-д `filename=report%0D%0AX-Lab-Canary%3A%20yes` ашиглаж, өөрийн response header-ийг үз.
- **Яаж таних?** `X-Lab-Canary: yes` үнэхээр **тусдаа response header** болсон бол баттай indicator; URL-д `%0D%0A` хэвээр байвал flaw биш.
- **Хэрхэн засах?** Header values-д CR/LF хориглох, framework header API, RFC-compliant filename handling.
