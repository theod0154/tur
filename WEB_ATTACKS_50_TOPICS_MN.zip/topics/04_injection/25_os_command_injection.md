# 25. OS Command Injection — Shell command-д input шингэх

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Program user input-г shell string-тэй нийлүүлж ажиллуулснаар input command syntax болно.
- **Хаана шалгах?** Diagnostics ping, conversion utilities, archive/file operations, admin automation.
- **Аюулгүй жишээ (тусгаарласан lab-only feature):**
  ```text
  name=demo; echo LAB_OK
  ```
  Хэрэв lab зөвшөөрдөг бол зөвхөн `LAB_OK` marker хэвлэж буй эсэхийг шалга; OS файл унших/устгахгүй.
- **Яаж таних?** `LAB_OK` command-ийн **output** server response-д гарсан нь strong evidence; input энгийн текстээр echo хийгдсэн эсэхийг control-test-аар ялга.
- **Хэрхэн засах?** Shell огт ашиглахгүй native API, argument-array execution, allowlisted input, low-privilege sandbox.
