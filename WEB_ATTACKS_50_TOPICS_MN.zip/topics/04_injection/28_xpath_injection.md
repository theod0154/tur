# 28. XPath Injection — XML query expression-д input шингэх

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** XML database-ийн XPath query user input-тай string concatenation хийдэг.
- **Хаана шалгах?** Legacy XML apps, XML-backed search, directory services.
- **Аюулгүй жишээ:** Local test XML record-ийн name параметрт `O'Reilly` мэт **literal apostrophe** орсон үед query эвдэрч/буруу record буцааж байгаа эсэхийг шалга.
- **Яаж таних?** Query interpolation-ийн улмаас query meaning өөрчлөгдөж байгааг custom lab log/expected XML sample-тай тулга; ганц parser error proof биш.
- **Хэрхэн засах?** Parameterized XPath API/variable binding, robust escaping, schema-based validation.
