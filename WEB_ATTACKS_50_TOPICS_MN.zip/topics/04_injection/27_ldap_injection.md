# 27. LDAP Injection — Directory query filter-д input шингэх

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** LDAP (Lightweight Directory Access Protocol) filter string-д user input escape хийгдээгүй нийлнэ.
- **Хаана шалгах?** Directory search, employee lookup, AD/LDAP-backed filters.
- **Аюулгүй жишээ:** Өөрийн test directory-д `lab.user` болон literal special-char `lab*(user)` нэр хайж, **expected literal matching** байгаа эсэхийг шалга.
- **Яаж таних?** Special-char input LDAP filter бүтцийг санаандгүй өөрчилсөн нь server logs/test directory result-т давтагдвал strong evidence; zero results дангаараа proof биш.
- **Хэрхэн засах?** RFC 4515 filter-value escaping, safe LDAP builder API, least-privilege bind.
