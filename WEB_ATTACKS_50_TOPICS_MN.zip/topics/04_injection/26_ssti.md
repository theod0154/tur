# 26. SSTI — Server-Side Template Injection

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Template engine хэрэглэгчийн input-г plain text биш template expression гэж боловсруулна.
- **Хаана шалгах?** Email previews, page templates, render endpoints, invoice templates, notification formatting.
- **Аюулгүй жишээ:** `{{7*7}}` болон `LAB_{{7*7}}`-г зөвхөн local lab template field-д оруул.
- **Яаж таних?** Raw `{{7*7}}` бус `49` гарсан бол **template evaluation-ийн сэжиг**; engine өөрчлөх/substring replace байж болох учир хэд хэдэн benign control expression-ээр батал.
- **Хэрхэн засах?** User input-г template source гэж compile хийхгүй, untrusted values only, sandboxed template engine, escaped output.
