# 24. NoSQL Injection — NoSQL query operator шингэх

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Input raw JSON/Mongo query operator байдлаар ойлгогдож query logic өөрчлөгдөнө.
- **Хаана шалгах?** JSON filters, MongoDB-backed login, search endpoints.
- **Аюулгүй жишээ:** Өөрийн local lab-д normal `{"name":"LAB"}` ба type-mismatch `{"name":{"$eq":"LAB"}}`-ийн behavior-ийг харьцуул.
- **Яаж таних?** Operator өөр query semantics үүсгэж server client-д зөвшөөрөөгүй selector-ийг ажиллуулж байвал flaw; зөвхөн JSON object хүлээн авдаг бол хангалтгүй.
- **Хэрхэн засах?** Strong input schema, field-specific primitive types, operator allowlist/deny; parameterized driver API.
