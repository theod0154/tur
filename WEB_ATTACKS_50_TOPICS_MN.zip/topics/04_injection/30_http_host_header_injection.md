# 30. HTTP Host Header Injection — Host-оос буруу absolute URL үүсэх

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Server `Host` header-ийг trust хийж password reset link, redirects, canonical URL-ийг хуурамч origin-оор бүтээдэг.
- **Хаана шалгах?** Absolute redirect, account emails (өөрийн test inbox), canonical tags, generated links.
- **Аюулгүй жишээ:**
  ```bash
  curl -i -H 'Host: lab.invalid' "$LAB/"
  ```
- **Яаж таних?** App-generated absolute link `lab.invalid` болсон нь анхааруулга; reset URL poisoning-д **өөрийн inbox** дээр баталгаажуулж, бусдад email явуулахгүй.
- **Хэрхэн засах?** Trusted application base URL config, Host allowlist, proxy header trust boundary.
