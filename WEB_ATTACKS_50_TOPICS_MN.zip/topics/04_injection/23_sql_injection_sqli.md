# 23. SQL Injection (SQLi) — SQL query-д input шингэх

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** User input SQL query-ийн **syntax** болж query-ийн утга санааг өөрчилнө; data parameter биш query logic болчихно.
- **Хаана шалгах?** Search/filter, `/item?id=`, login query, sorting, reporting APIs.
- **Аюулгүй жишээ (зөвхөн intentionally vulnerable lab):**
  ```text
  ?id=1
  ?id=1 AND 1=1
  ?id=1 AND 1=2
  ```
  Өөр хооронд нь харагдах **өөрийн demo item**-ийн үр дүнг харьцуул; зөвхөн integer expected endpoint-д ашигла.
- **Яаж таних?** True/false нөхцлөөс шалтгаалан query result **давтагдахуйц логикоор** ялгарах + control test баталж байвал SQLi-ийн strong evidence. Зөвхөн `'` тэмдэгтээс `500` гарах нь proof биш. DB dump, `UNION` extraction, state change хийхгүй.
- **Хэрхэн засах?** Prepared statements/parameterized queries, ORM safety, SQL identifier allowlist, least-privileged DB account, structured error handling.
