# 11. MFA Flow Bypass — Multi-Factor Authentication урсгалын алдаа

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Нэмэлт баталгаажуулалт дуусаагүй байхад бүрэн authenticated resource-д хандах.
- **Хаана шалгах?** Login → MFA challenge → account page; `pre_mfa` session/claims; API auth gates.
- **Аюулгүй жишээ:** Өөрийн test user-аар password оруулж MFA алхмаас өмнө **өөрийн** `/api/me`-г Burp Repeater-ээс request хийх.
- **Яаж таних?** Pre-MFA context-оос full permission-тэй private route нээгдсэн бол баталгаажуулалт; зөвхөн HTML shell гарсан нь хангалтгүй.
- **Хэрхэн засах?** Centralized MFA-completed authorization checks on every protected endpoint; correct session elevation and expiring challenges.
