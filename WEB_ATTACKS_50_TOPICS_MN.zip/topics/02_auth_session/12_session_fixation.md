# 12. Session Fixation — Нэвтрэхэд session солигдохгүй байх

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Login өмнөх session identifier-г login дараа хэвээр үлдээх нь урьдчилан мэдэгдсэн session ашиглагдах эрсдэлтэй.
- **Хаана шалгах?** Login before/after `Set-Cookie`, authenticated session lifecycle.
- **Аюулгүй жишээ:** DevTools → Application → Cookies: login өмнөх ба дараах test account session ID-г харьцуул; cookie утгыг report-д **mask** хий.
- **Яаж таних?** ID өөрчлөгдөөгүй нь анхааруулга; exploitability нь attacker уг ID-г victim-д тогтоож чадах эсэх зэрэг нөхцөлөөс хамаарна.
- **Хэрхэн засах?** Auth boundary дээр session rotation, secure cookie flags, server-side expiration.
