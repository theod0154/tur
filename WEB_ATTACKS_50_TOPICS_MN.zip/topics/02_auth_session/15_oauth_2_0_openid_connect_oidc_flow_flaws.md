# 15. OAuth 2.0 / OpenID Connect (OIDC) Flow Flaws

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Login redirect flow-д `state`, `nonce`, `redirect_uri`, code/PKCE binding буруу бол account/session буруу холбогдож болно.
- **Хаана шалгах?** `/authorize`, `/callback`, login-with-provider, token exchange; SSO flows.
- **Аюулгүй жишээ:** Өөрийн **хоёр local test browser profile**-аар OAuth login эхлүүлж, `state` нь session-тэй холбогдож, буруу/missing state rejection-д хүрч байгааг шалга. Жинхэнэ third-party account солихгүй.
- **Яаж таних?** Mismatched state-г зөвшөөрч өөрийн test user-ийн auth session солигдох нь evidence. `state` харагдах нь flaw биш, server validation чухал.
- **Хэрхэн засах?** Strict redirect URI allowlist, state + nonce validation, PKCE, one-time code, correct OIDC ID token validation.
