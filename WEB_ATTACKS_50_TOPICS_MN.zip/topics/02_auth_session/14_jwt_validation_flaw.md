# 14. JWT Validation Flaw — JSON Web Token шалгалтын алдаа

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Server token signature, `iss` (issuer), `aud` (audience), `exp` (expiry), `alg`-ийг буруу шалгана.
- **Хаана шалгах?** `Authorization: Bearer`, cookies, mobile/API JWT, refresh flow.
- **Аюулгүй жишээ:** Өөрийн JWT-ийн payload-ыг **offline** decode хийж claim-уудыг хар (decode ≠ verify):
  ```bash
  python3 - <<'PY'
  import base64, json
  sample='eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJsYWItdXNlciIsImV4cCI6NDA3MDkwODgwMH0.signature'
  p=sample.split('.')[1]
  print(json.loads(base64.urlsafe_b64decode(p+'='*(-len(p)%4))))
  PY
  ```
- **Яаж таних?** Token-д өөрийн test claim-г өөрчлөөд signature хэвээр байхад **protected** API зөвшөөрвөл signature-validation flaw; зөвхөн JWT decode болох нь vulnerability биш.
- **Хэрхэн засах?** Trusted library-гаар fixed algorithm allowlist, signature + issuer + audience + expiry validation; secret/key rotation.
