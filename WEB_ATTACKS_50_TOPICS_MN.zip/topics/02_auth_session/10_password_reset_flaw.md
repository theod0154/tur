# 10. Password Reset Flaw — Нууц үг сэргээх урсгалын алдаа

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Reset token дахин ашиглагдах, expiry/owner-той холбогдоогүй, эсвэл бусад user-ийн session/action-д хүчингүй болдоггүй.
- **Хаана шалгах?** `/forgot-password`, `/reset?token=`, email confirmation, password change.
- **Аюулгүй жишээ:** Өөрийн account-д **нэг** reset link авч хугацаа, token reuse, reset дараах token invalidation-ийг шалга.
- **Яаж таних?** Өөрийн хэрэглэсэн token-аар хоёр дахь удаа password change хүлээн авбал flaw. Token query-д харагдах нь дангаараа vulnerability биш; referrer/log leak эрсдэл тусдаа.
- **Хэрхэн засах?** Cryptographic random single-use short-lived token; account + purpose binding, safe logging, token invalidation.
