# 13. Logout / Revocation Failure — Logout дараа session хүчинтэй үлдэх

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** User logout хийсэн ч өмнөх session/token сервер дээр хүчингүй болохгүй.
- **Хаана шалгах?** `/logout`, `/api/me`, refresh tokens, password change.
- **Аюулгүй жишээ:** Өөрийн login session-ээр private request-г Burp-д хадгалаад logout хийнэ; өмнөх cookie/token-ийг **өөрийн** `/api/me` дээр нэг удаа replay хий.
- **Яаж таних?** `200` + бодит private data буцсан бол сэжигтэй. Stateless access JWT-тэй системд logout semantics/TTL/refresh revocation дүрмийг тусад нь үнэл.
- **Хэрхэн засах?** Server-side revocation эсвэл богино access TTL + refresh rotation; revoke refresh sessions, clear client state.
