# 09. Account Enumeration — Хэрэглэгч бүртгэлтэй эсэхийг ил болгох

> [Индекс](../../README.md) · [Нэгдсэн guide](../../WEB_ATTACKS_FIELD_GUIDE_MN.md) · Зөвхөн authorized lab

- **Юу вэ?** Login/register/reset flow өөр response өгснөөр account байгаа эсэх мэдэгдэнэ.
- **Хаана шалгах?** `/login`, `/register`, `/forgot-password`.
- **Аюулгүй жишээ:** Өөрийн үүсгэсэн `test-a@localhost.invalid` болон `absent@localhost.invalid` хоёр утгаар **цөөн** request илгээж message/status/timing харьцуулах.
- **Яаж таних?** `Account exists` vs `No user` гэх тогтмол ялгаа бол evidence. Timing-д нэг удаагийн зөрүү нотолгоо биш; credential stuffing/brute-force бүү хий.
- **Хэрхэн засах?** Ижил ерөнхий message, тэнцүү response logic, rate limiting, мониторинг.
