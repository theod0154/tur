# Web Attacks — Practical Field Guide (MN)

> **Формат:** Юу вэ → Хаана шалгах → Аюулгүй жишээ → Яаж таних → Хэрхэн засах  
> **Зориулалт:** Beginner → Intermediate · Burp Suite · Browser DevTools · `curl` · API  
> **Орчин:** Зөвхөн өөрийн local lab, intentionally vulnerable lab, эсвэл бичгээр зөвшөөрсөн in-scope систем.

## Агуулга

- [0. Энэ материалыг яаж ашиглах вэ?](#0-энэ-материалыг-яаж-ашиглах-вэ)
- [1. Browser & Client-Side Attacks](#1-browser--client-side-attacks) — XSS, HTML Injection, CSRF, CORS, Clickjacking, Open Redirect
- [2. Authentication & Session](#2-authentication--session) — Enumeration, Reset, MFA, Session, JWT, OAuth
- [3. Authorization & API](#3-authorization--api) — IDOR, BOLA, BFLA, Mass Assignment, Tenant, GraphQL
- [4. Injection](#4-injection) — SQLi, NoSQLi, Command, SSTI, LDAP, XPath, CRLF, Host Header
- [5. Server-Side Attacks](#5-server-side-attacks) — SSRF, Traversal, LFI, RFI, XXE, Upload, Deserialization, Smuggling, Race
- [6. Business Logic, Cache & Misconfiguration](#6-business-logic-cache--misconfiguration) — Logic, Cache, WebSockets, JS, Debug, Headers
- [7. Тестийн богино workflow](#7-тестийн-богино-workflow)
- [8. Evidence ба Report загвар](#8-evidence-ба-report-загвар)
- [9. Эх сурвалж, дараагийн сургалт](#9-эх-сурвалж-дараагийн-сургалт)

---

## 0. Энэ материалыг яаж ашиглах вэ?

**Нэг өгүүлбэрийн дүрэм:** *Input өөрчлөгдөхөд ямар trust boundary давж, ямар эрхгүй үйлдэл эсвэл буруу боловсруулалт үүсэж байгааг хар.*

**Тэмдэглэгээ:**
- `LAB` = зөвхөн өөрийн тестийн орчин; `http://127.0.0.1:8080` жишээ хаяг. Доорх `/search`, `/api/...` замууд **сургалтын хийсвэр endpoint** бөгөөд OWASP Juice Shop зэрэг lab-д заавал ижил байх албагүй.
- `User A` / `User B` = хоёулаа **өөрийн үүсгэсэн** хоёр туршилтын account.
- `marker` / `LAB_OK` = нууц биш, өөрөө үүсгэсэн шалгах утга.
- **Сэжигтэй** = анхан ажиглалт; **батлагдсан** = давтагдах, хяналтын (negative control) тесттэй, бодит security boundary зөрчсөн evidence.
- `200 OK`, `403 Forbidden`, `500 Internal Server Error` нь дангаараа эмзэг байдал **батлахгүй**.

```bash
# Terminal: зөвхөн local lab руу хүсэлт илгээнэ
export LAB='http://127.0.0.1:8080'
curl -i "$LAB/"                 # -i: response headers + body харуулна
curl -sS -D - "$LAB/robots.txt" # -sS: progress-гүй, error-ийг харуулна; -D -: headers-ийг stdout руу
```

**Ажиллах арга:** ① normal request хадгалах → ② нэг параметр өөрчлөх → ③ response/DOM/state харьцуулах → ④ negative control хийх → ⑤ зөвхөн өөрийн өгөгдлөөр баталгаажуулах → ⑥ report бичих. Хэт олон автомат хүсэлт, credentials guessing, DoS, бусдын дата үзэх, production record өөрчлөхийг хэрэглэхгүй.

**Түгээмэл ялгаа:**

| Ойлголт | Гол асуудал | Шалгах асуулт |
|---|---|---|
| **XSS** | Browser-д итгэлгүй JS ажиллах | User input **код болж ажиллаж** байна уу? |
| **CSRF** | Browser cookie-тай хүсэлтийг өөр сайтаас өдөөх | User-ийн зөвшөөрөлгүй state change болсон уу? |
| **IDOR / BOLA** | Объект тус бүрийн эрх шалгаагүй | A account B-ийн **өөрийн test object**-ийг уншиж/өөрчилж чадсан уу? |
| **SQLi** | Input SQL syntax-д нөлөөлөх | Query semantics injection-ийн улмаас өөрчлөгдөв үү? |
| **SSRF** | Server хэрэглэгчийн өгсөн хаяг руу хүсэлт гаргах | Server зөвшөөрөгдөөгүй destination руу fetch хийв үү? |
| **CORS** | Origin хооронд data унших хэт өргөн зөвшөөрөл | Attacker origin authenticated response-г JS-аар **уншиж** чадах уу? |
| **Open Redirect** | URL parameter хөндлөн redirect хийх | Дурын external origin руу илгээж байна уу? |

---

## 1. Browser & Client-Side Attacks

### 01. Reflected XSS — Хариунд шууд туссан JavaScript

- **Юу вэ?** Хэрэглэгчийн input тухайн HTTP response-д шүүгдэхгүй буцаж, browser түүнийг JavaScript гэж ажиллуулна. Жишээ нь хайлтын мөрийн утга HTML болж хувирах.
- **Хаана шалгах?** `/search?q=`, `/error?message=`, filters, URL query, зарим HTTP headers.
- **Аюулгүй жишээ (local lab):**
  ```http
  GET /search?q=%3Csvg%20onload%3Dalert(1)%3E HTTP/1.1
  Host: 127.0.0.1:8080
  ```
  Энэ payload зөвхөн lab tab-д `alert(1)` ажиллуулах зорилготой; жинхэнэ сайт руу хэрэглэхгүй. Эхлээд `XSS_LAB_01` marker-аар reflection-ийг шалга.
- **Яаж таних?** `View Source` / DevTools **Elements** дээр payload executable DOM болсон, `alert(1)` тухайн **response-оос** ажилласан бол батлах боломжтой. Зүгээр текстээр харагдах нь XSS биш; Content Security Policy (CSP) хамгаалалт ажиллахгүй болгосон эсэхийг тэмдэглэ.
- **Хэрхэн засах?** Context-aware output encoding (HTML, attribute, URL, JS-д тус тусад нь), safe templating, DOM `textContent`; нэмэлт хамгаалалт болгон хатуу CSP.

### 02. Stored XSS — Хадгалагддаг JavaScript

- **Юу вэ?** Comment/profile гэх мэт талбарт хадгалсан input дараагийн удаа page нээгдэхэд JS болж ажиллах.
- **Хаана шалгах?** Comments, profile bio, support tickets, Markdown renderer, admin dashboard-т харагдах хэрэглэгчийн мэдээлэл.
- **Аюулгүй жишээ (өөрийн test record):**
  ```text
  Display name = <img src=x onerror=alert(1)>
  ```
  Зөвхөн өөрийн account-д хадгалаад **өөрийн** browser/session-д нээ.
- **Яаж таних?** Save хийхэд биш, **дахин ачаалсан page дээр** код ажиллана; хадгалагдсан утга HTML/DOM-д executable болсон байна. Markdown-д raw HTML дүрслэгдэх нь дангаараа XSS биш.
- **Хэрхэн засах?** Хадгалсан өгөгдөлд итгэхгүй; rendering үеийн context-aware encoding, HTML зөвшөөрөх бол sanitizer, strong CSP.

### 03. DOM-based XSS — Browser-side JavaScript-ийн алдаа

- **Юу вэ?** Server response аюулгүй байсан ч front-end JS `location.hash`/`location.search`-ийг аюултай DOM sink (`innerHTML`) рүү дамжуулна.
- **Хаана шалгах?** JS router, hash fragments, client-side search, `innerHTML`, `document.write`, risky URL assignment.
- **Аюулгүй жишээ (lab source-ийг унш):**
  ```javascript
  // Эмзэг жишээ — кодыг production-д БҮҮ ашигла
  document.querySelector('#result').innerHTML = location.hash.slice(1);
  // Зөв хувилбар
  document.querySelector('#result').textContent = location.hash.slice(1);
  ```
- **Яаж таних?** URL `#<img src=x onerror=alert(1)>` рүү өөрчлөхөд **network response өөрчлөгдөхгүй атлаа** DOM дээр JS ажиллавал DOM XSS-ийн нотолгоо. Console-д CSP error байвал ялгаж тэмдэглэ.
- **Хэрхэн засах?** `textContent`, `createElement`, DOMPurify (HTML шаардлагатай үед), Trusted Types боломжтой бол хэрэглэх.

### 04. HTML Injection — HTML бүтэц оруулах

- **Юу вэ?** Input HTML element болж дүрслэгдэнэ; заавал JavaScript ажиллахгүй. UI-г хуурамчаар харагдуулах, content хуурах эрсдэлтэй.
- **Хаана шалгах?** Search results, comment preview, username displays, template placeholders.
- **Аюулгүй жишээ:** `LAB_<b>bold</b>` гэсэн input-ыг local lab-д оруулах.
- **Яаж таних?** `<b>` бодит DOM element болсон боловч JS ажиллаагүй бол **HTML Injection**, XSS гэж шууд нэрлэхгүй. UI-д ямар нөлөөтэйг шалга.
- **Хэрхэн засах?** HTML encode, зөвхөн шаардлагатай tag/attribute-ийг sanitizer-аар allowlist хийх.

### 05. CSRF — Cross-Site Request Forgery

- **Юу вэ?** Хэрэглэгч сайт руу login хийсэн байхад өөр website браузераар нь хүсэлт явуулж, хэрэглэгч хүсээгүй үйлдэл хийлгэнэ. Гол шалтгаан: cookie автоматаар хавсардаг байж болно.
- **Хаана шалгах?** Email/profile change, address update, preference save, account action зэрэг **state-changing** `POST`/`PUT`/`DELETE` болон бүр буруу `GET` endpoint.
- **Аюулгүй жишээ (өөрийн account + local lab):**
  ```html
  <!-- Өөрийн lab-д localhost дээр хадгалсан csrf-test.html -->
  <form method="POST" action="http://127.0.0.1:8080/profile/nickname">
    <input name="nickname" value="CSRF_LAB_ONLY">
    <button type="submit">Test my own profile</button>
  </form>
  ```
  Энэ HTML-ийг **өөр origin**-оос нээж, зөвхөн өөрийн test profile-д submit хий.
- **Яаж таних?** Authenticated browser-аас cross-site submit хийхэд anti-CSRF token/Origin/Referer validation-гүйгээр өөрийн profile **өөрчлөгдвөл** батлагдана. Cookie-ийн `SameSite=Lax/Strict`, `Secure`, request-ийн content type, browser behavior-ийг шалга. Зөвхөн CSRF token харагдахгүй байх нь нотолгоо биш.
- **Хэрхэн засах?** Server-side validated CSRF token, `Origin`/`Referer` validation, SameSite cookies, state-changing GET-г хориглох; AJAX API-д зөв authentication + explicit CORS.

### 06. Clickjacking — Харагдахгүй/давхарласан iframe-аар click хийлгэх

- **Юу вэ?** Сайтыг өөр page-ийн iframe-д нууж/давхарлан хэрэглэгчээр санаандгүй товч даруулах.
- **Хаана шалгах?** Account settings, confirm buttons, billing action, permission dialogs; response-ийн `Content-Security-Policy: frame-ancestors` / `X-Frame-Options`.
- **Аюулгүй жишээ:**
  ```html
  <iframe src="http://127.0.0.1:8080/profile" width="800" height="500"></iframe>
  ```
- **Яаж таних?** Өөр origin-оос iframe-д page **ачаалж**, overlay click-ийн зорилтот элемент бодитоор ажиллах боломжтой байвал эрсдэлтэй. Frame дотор ачаалсан нь дангаараа high severity биш.
- **Хэрхэн засах?** `Content-Security-Policy: frame-ancestors 'none'` (эсвэл хатуу allowlist), legacy `X-Frame-Options`, өндөр эрсдэлтэй үйлдэлд баталгаажуулалт.

### 07. CORS Misconfiguration — Cross-Origin Resource Sharing буруу тохируулга

- **Юу вэ?** Browser бусад origin-д хандах үед response унших эрхийг server хэт өргөн олгох. CORS бол server-side authorization орлуулагч биш.
- **Хаана шалгах?** Authenticated API, `Access-Control-Allow-Origin`, `Access-Control-Allow-Credentials`, `Origin` header.
- **Аюулгүй жишээ:**
  ```bash
  curl -i -H 'Origin: http://127.0.0.1:3000' "$LAB/api/me"
  ```
- **Яаж таних?** `ACAO` дотор arbitrary origin буцаасан нь **сэжиг**. Бодит эрсдэл нь browser JS authenticated *sensitive* response-г унших боломжтой эсэх (`credentials: include`, cookies, SameSite, response body, CSP etc.)-ээр тодорхойлогдоно. `ACAO: *` + credentials нь browser-д хүчинтэй credentialed access болдоггүй.
- **Хэрхэн засах?** Exact origin allowlist, `Vary: Origin`, зөвхөн хэрэгтэй үед credential sharing, public ба private API-г тусгаарлах.

### 08. Open Redirect — Гадны сайт руу дур мэдэн чиглүүлэх

- **Юу вэ?** `next`, `returnUrl` гэх параметрээр хэрэглэгчийг баталгаагүй external destination руу redirect хийнэ; phishing-д ашиглагдаж болзошгүй.
- **Хаана шалгах?** Login callback, logout, SSO return paths, marketing links.
- **Аюулгүй жишээ:**
  ```bash
  curl -I "$LAB/redirect?next=https%3A%2F%2Fexample.com%2F"
  ```
- **Яаж таних?** `Location: https://example.com/` зөвшөөрөгдөөгүй үед илэрвэл open redirect. Сайтын зөвшөөрсөн outbound links байж болно; security impact-ийг login/OAuth зэрэг context-оор үнэл.
- **Хэрхэн засах?** Relative paths, exact origin allowlist, redirect token/map; user input-д URL-ийг шууд итгэхгүй.

---

## 2. Authentication & Session

### 09. Account Enumeration — Хэрэглэгч бүртгэлтэй эсэхийг ил болгох

- **Юу вэ?** Login/register/reset flow өөр response өгснөөр account байгаа эсэх мэдэгдэнэ.
- **Хаана шалгах?** `/login`, `/register`, `/forgot-password`.
- **Аюулгүй жишээ:** Өөрийн үүсгэсэн `test-a@localhost.invalid` болон `absent@localhost.invalid` хоёр утгаар **цөөн** request илгээж message/status/timing харьцуулах.
- **Яаж таних?** `Account exists` vs `No user` гэх тогтмол ялгаа бол evidence. Timing-д нэг удаагийн зөрүү нотолгоо биш; credential stuffing/brute-force бүү хий.
- **Хэрхэн засах?** Ижил ерөнхий message, тэнцүү response logic, rate limiting, мониторинг.

### 10. Password Reset Flaw — Нууц үг сэргээх урсгалын алдаа

- **Юу вэ?** Reset token дахин ашиглагдах, expiry/owner-той холбогдоогүй, эсвэл бусад user-ийн session/action-д хүчингүй болдоггүй.
- **Хаана шалгах?** `/forgot-password`, `/reset?token=`, email confirmation, password change.
- **Аюулгүй жишээ:** Өөрийн account-д **нэг** reset link авч хугацаа, token reuse, reset дараах token invalidation-ийг шалга.
- **Яаж таних?** Өөрийн хэрэглэсэн token-аар хоёр дахь удаа password change хүлээн авбал flaw. Token query-д харагдах нь дангаараа vulnerability биш; referrer/log leak эрсдэл тусдаа.
- **Хэрхэн засах?** Cryptographic random single-use short-lived token; account + purpose binding, safe logging, token invalidation.

### 11. MFA Flow Bypass — Multi-Factor Authentication урсгалын алдаа

- **Юу вэ?** Нэмэлт баталгаажуулалт дуусаагүй байхад бүрэн authenticated resource-д хандах.
- **Хаана шалгах?** Login → MFA challenge → account page; `pre_mfa` session/claims; API auth gates.
- **Аюулгүй жишээ:** Өөрийн test user-аар password оруулж MFA алхмаас өмнө **өөрийн** `/api/me`-г Burp Repeater-ээс request хийх.
- **Яаж таних?** Pre-MFA context-оос full permission-тэй private route нээгдсэн бол баталгаажуулалт; зөвхөн HTML shell гарсан нь хангалтгүй.
- **Хэрхэн засах?** Centralized MFA-completed authorization checks on every protected endpoint; correct session elevation and expiring challenges.

### 12. Session Fixation — Нэвтрэхэд session солигдохгүй байх

- **Юу вэ?** Login өмнөх session identifier-г login дараа хэвээр үлдээх нь урьдчилан мэдэгдсэн session ашиглагдах эрсдэлтэй.
- **Хаана шалгах?** Login before/after `Set-Cookie`, authenticated session lifecycle.
- **Аюулгүй жишээ:** DevTools → Application → Cookies: login өмнөх ба дараах test account session ID-г харьцуул; cookie утгыг report-д **mask** хий.
- **Яаж таних?** ID өөрчлөгдөөгүй нь анхааруулга; exploitability нь attacker уг ID-г victim-д тогтоож чадах эсэх зэрэг нөхцөлөөс хамаарна.
- **Хэрхэн засах?** Auth boundary дээр session rotation, secure cookie flags, server-side expiration.

### 13. Logout / Revocation Failure — Logout дараа session хүчинтэй үлдэх

- **Юу вэ?** User logout хийсэн ч өмнөх session/token сервер дээр хүчингүй болохгүй.
- **Хаана шалгах?** `/logout`, `/api/me`, refresh tokens, password change.
- **Аюулгүй жишээ:** Өөрийн login session-ээр private request-г Burp-д хадгалаад logout хийнэ; өмнөх cookie/token-ийг **өөрийн** `/api/me` дээр нэг удаа replay хий.
- **Яаж таних?** `200` + бодит private data буцсан бол сэжигтэй. Stateless access JWT-тэй системд logout semantics/TTL/refresh revocation дүрмийг тусад нь үнэл.
- **Хэрхэн засах?** Server-side revocation эсвэл богино access TTL + refresh rotation; revoke refresh sessions, clear client state.

### 14. JWT Validation Flaw — JSON Web Token шалгалтын алдаа

- **Юу вэ?** Server token signature, `iss` (issuer), `aud` (audience), `exp` (expiry), `alg`-ийг буруу шалгана.
- **Хаана шалгах?** `Authorization: Bearer`, cookies, mobile/API JWT, refresh flow.
- **Аюулгүй жишээ:** Өөрийн JWT-ийн payload-ыг **offline** decode хийж claim-уудыг хар (decode ≠ verify):
  ```bash
  python3 - <<'PY'
  import base64, json
  sample='eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJsYWItdXNlciIsImV4cCI6NDA3MDkwODgwMH0.signature'
  p=sample.split('.')[1]
  print(json.loads(base64.urlsafe_b64decode(p+'='*(-len(p)%4))))
  PY
  ```
- **Яаж таних?** Token-д өөрийн test claim-г өөрчлөөд signature хэвээр байхад **protected** API зөвшөөрвөл signature-validation flaw; зөвхөн JWT decode болох нь vulnerability биш.
- **Хэрхэн засах?** Trusted library-гаар fixed algorithm allowlist, signature + issuer + audience + expiry validation; secret/key rotation.

### 15. OAuth 2.0 / OpenID Connect (OIDC) Flow Flaws

- **Юу вэ?** Login redirect flow-д `state`, `nonce`, `redirect_uri`, code/PKCE binding буруу бол account/session буруу холбогдож болно.
- **Хаана шалгах?** `/authorize`, `/callback`, login-with-provider, token exchange; SSO flows.
- **Аюулгүй жишээ:** Өөрийн **хоёр local test browser profile**-аар OAuth login эхлүүлж, `state` нь session-тэй холбогдож, буруу/missing state rejection-д хүрч байгааг шалга. Жинхэнэ third-party account солихгүй.
- **Яаж таних?** Mismatched state-г зөвшөөрч өөрийн test user-ийн auth session солигдох нь evidence. `state` харагдах нь flaw биш, server validation чухал.
- **Хэрхэн засах?** Strict redirect URI allowlist, state + nonce validation, PKCE, one-time code, correct OIDC ID token validation.

---

## 3. Authorization & API

### 16. IDOR / BOLA — Object-level эрхийн алдаа

- **Юу вэ?** Client-ийн `id`-г солиход server тухайн объектын owner/permission-г шалгаагүй. **IDOR** = Insecure Direct Object Reference; API-д **BOLA** = Broken Object Level Authorization гэж нэрлэдэг.
- **Хаана шалгах?** `/api/orders/{id}`, `/files/{id}`, `?userId=`, invoices, profile, GraphQL node IDs.
- **Аюулгүй жишээ (2 өөрийн user):**
  ```http
  GET /api/notes/101 HTTP/1.1
  Host: 127.0.0.1:8080
  Cookie: session=USER_A_TEST_SESSION
  ```
  `101`-ийг User B-ийн **өөрийн урьдчилан үүсгэсэн** note ID болгож ганц request явуул.
- **Яаж таних?** A session B-ийн note-ийн `LAB_B_PRIVATE` marker-ийг **уншиж/өөрчилж** байвал confirmed. `200` боловч зөвхөн public/empty wrapper гарвал IDOR биш.
- **Хэрхэн засах?** Every object access дээр server-side policy (`requested_object.owner == current_user` эсвэл tenant/ACL rule), default deny; UUID нь authorization орлохгүй.

### 17. BFLA — Broken Function Level Authorization

- **Юу вэ?** Энгийн user зөвхөн admin хийх ёстой function/API-г дуудна.
- **Хаана шалгах?** `/api/admin/*`, role management, user enable/disable, export endpoints.
- **Аюулгүй жишээ:** Өөрийн admin lab-д `GET /api/admin/settings`-ийг normal-user test session-ээр шалга; state-changing admin action бүү ажиллуул.
- **Яаж таних?** Admin-only confidential settings нормал user-т харагдсан бол evidence. `403` биш `404`-ийг зориуд хэрэглэсэн байж болно — access deny бол сайн.
- **Хэрхэн засах?** Server-side function permission matrix, authorization middleware, role-based tests.

### 18. Vertical Privilege Escalation — Role өсгөх

- **Юу вэ?** Normal user manager/admin-only мэдээлэл, функцэд зөвшөөрөлгүй хандах.
- **Хаана шалгах?** Admin menu hidden routes, API roles, reports, approval screens.
- **Аюулгүй жишээ:** Өөрийн `viewer` user-аас `/reports/internal`-г нээгээд ижил request-ийг `admin` test session-тай харьцуул.
- **Яаж таних?** Role-оор хамгаалах ёстой мэдээлэл viewer-д ирсэн бол vulnerability; UI-д цэс нуух нь authorization биш.
- **Хэрхэн засах?** Least privilege, per-endpoint server-side RBAC/ABAC policy, deny-by-default.

### 19. Mass Assignment / BOPLA — Илүүдэл property өөрчлөх

- **Юу вэ?** JSON request-ийн сервер удирдах ёстой `role`, `approved`, `ownerId` зэрэг field-г client дур мэдэн тохируулна. **BOPLA** = Broken Object Property Level Authorization.
- **Хаана шалгах?** `PATCH /api/me`, `PUT /api/users/{id}`, create/update DTO.
- **Аюулгүй жишээ:**
  ```http
  PATCH /api/me HTTP/1.1
  Host: 127.0.0.1:8080
  Content-Type: application/json

  {"displayName":"LAB_TEST","isAdmin":true}
  ```
- **Яаж таних?** Өөрийн test user-ийн `isAdmin` үнэхээр `true` болсон эсэхийг **өөрийн** subsequent GET-ээр шалга. JSON echo эсвэл `200` дангаараа хангалтгүй.
- **Хэрхэн засах?** Explicit writable-field allowlist, per-field authorization, never bind request directly to privileged database model.

### 20. Tenant Isolation — Байгууллага хоорондын тусгаарлалтын алдаа

- **Юу вэ?** SaaS олон tenant-тэй үед A байгууллагын user B tenant-ийн объект руу орно.
- **Хаана шалгах?** `/api/tenants/{id}/`, organization header, projects, invoices, multi-tenant search.
- **Аюулгүй жишээ:** Зөвхөн өөрийн test Tenant-A / Tenant-B үүсгээд A token-оор B-ийн `LAB_TENANT_B` record-г **read-only** шалга.
- **Яаж таних?** B-ийн тусгаарлагдсан record A-д харагдвал батлагдана; global public catalog байвал boundary-г урьдчилан тогтоо.
- **Хэрхэн засах?** Tenant ID-г trusted auth context-оос авах, every query-д tenant predicate, row-level security, cross-tenant tests.

### 21. Excessive Data Exposure — API илүүдэл мэдээлэл буцаах

- **Юу вэ?** UI-д харуулахгүй боловч API response-д unnecessary private fields ирнэ; front-end шүүхээр security хангахгүй.
- **Хаана шалгах?** `/api/users`, mobile API, reports, GraphQL object selection.
- **Аюулгүй жишээ:** Өөрийн profile API JSON-д `internalNote`, `resetToken`, `salary` зэрэг **зөвшөөрөгдөөгүй** field байгаа эсэхийг DevTools Network-оор хар.
- **Яаж таних?** Field ирсэн нь автоматаар flaw биш; normal user-д очих ёсгүй sensitive value эсэхийг policy-тай тулгана. Бусдын мэдээлэл татах шаардлагагүй.
- **Хэрхэн засах?** Response DTO allowlist, field-level authorization, data minimization.

### 22. GraphQL Authorization — Query resolver-ийн эрхийн алдаа

- **Юу вэ?** GraphQL query-ийн өөр өөр field/resolver дээр authorization consistent биш байх.
- **Хаана шалгах?** `/graphql`, `node(id:)`, `user(id:)`, nested fields, mutations.
- **Аюулгүй жишээ:**
  ```graphql
  query {
    viewer { id displayName }
  }
  ```
  Өөрийн user-ийн `viewer`-ийг normal user ба anonymous context-д харьцуул; nested **өөрийн** test object-р шалга.
- **Яаж таних?** Unauthorized resolver private value буцаавал confirmed; schema introspection ажиллах нь дангаараа vulnerability биш.
- **Хэрхэн засах?** Resolver-level auth for objects/fields, depth/complexity limits, per-tenant restrictions.

---

## 4. Injection

### 23. SQL Injection (SQLi) — SQL query-д input шингэх

- **Юу вэ?** User input SQL query-ийн **syntax** болж query-ийн утга санааг өөрчилнө; data parameter биш query logic болчихно.
- **Хаана шалгах?** Search/filter, `/item?id=`, login query, sorting, reporting APIs.
- **Аюулгүй жишээ (зөвхөн intentionally vulnerable lab):**
  ```text
  ?id=1
  ?id=1 AND 1=1
  ?id=1 AND 1=2
  ```
  Өөр хооронд нь харагдах **өөрийн demo item**-ийн үр дүнг харьцуул; зөвхөн integer expected endpoint-д ашигла.
- **Яаж таних?** True/false нөхцлөөс шалтгаалан query result **давтагдахуйц логикоор** ялгарах + control test баталж байвал SQLi-ийн strong evidence. Зөвхөн `'` тэмдэгтээс `500` гарах нь proof биш. DB dump, `UNION` extraction, state change хийхгүй.
- **Хэрхэн засах?** Prepared statements/parameterized queries, ORM safety, SQL identifier allowlist, least-privileged DB account, structured error handling.

### 24. NoSQL Injection — NoSQL query operator шингэх

- **Юу вэ?** Input raw JSON/Mongo query operator байдлаар ойлгогдож query logic өөрчлөгдөнө.
- **Хаана шалгах?** JSON filters, MongoDB-backed login, search endpoints.
- **Аюулгүй жишээ:** Өөрийн local lab-д normal `{"name":"LAB"}` ба type-mismatch `{"name":{"$eq":"LAB"}}`-ийн behavior-ийг харьцуул.
- **Яаж таних?** Operator өөр query semantics үүсгэж server client-д зөвшөөрөөгүй selector-ийг ажиллуулж байвал flaw; зөвхөн JSON object хүлээн авдаг бол хангалтгүй.
- **Хэрхэн засах?** Strong input schema, field-specific primitive types, operator allowlist/deny; parameterized driver API.

### 25. OS Command Injection — Shell command-д input шингэх

- **Юу вэ?** Program user input-г shell string-тэй нийлүүлж ажиллуулснаар input command syntax болно.
- **Хаана шалгах?** Diagnostics ping, conversion utilities, archive/file operations, admin automation.
- **Аюулгүй жишээ (тусгаарласан lab-only feature):**
  ```text
  name=demo; echo LAB_OK
  ```
  Хэрэв lab зөвшөөрдөг бол зөвхөн `LAB_OK` marker хэвлэж буй эсэхийг шалга; OS файл унших/устгахгүй.
- **Яаж таних?** `LAB_OK` command-ийн **output** server response-д гарсан нь strong evidence; input энгийн текстээр echo хийгдсэн эсэхийг control-test-аар ялга.
- **Хэрхэн засах?** Shell огт ашиглахгүй native API, argument-array execution, allowlisted input, low-privilege sandbox.

### 26. SSTI — Server-Side Template Injection

- **Юу вэ?** Template engine хэрэглэгчийн input-г plain text биш template expression гэж боловсруулна.
- **Хаана шалгах?** Email previews, page templates, render endpoints, invoice templates, notification formatting.
- **Аюулгүй жишээ:** `{{7*7}}` болон `LAB_{{7*7}}`-г зөвхөн local lab template field-д оруул.
- **Яаж таних?** Raw `{{7*7}}` бус `49` гарсан бол **template evaluation-ийн сэжиг**; engine өөрчлөх/substring replace байж болох учир хэд хэдэн benign control expression-ээр батал.
- **Хэрхэн засах?** User input-г template source гэж compile хийхгүй, untrusted values only, sandboxed template engine, escaped output.

### 27. LDAP Injection — Directory query filter-д input шингэх

- **Юу вэ?** LDAP (Lightweight Directory Access Protocol) filter string-д user input escape хийгдээгүй нийлнэ.
- **Хаана шалгах?** Directory search, employee lookup, AD/LDAP-backed filters.
- **Аюулгүй жишээ:** Өөрийн test directory-д `lab.user` болон literal special-char `lab*(user)` нэр хайж, **expected literal matching** байгаа эсэхийг шалга.
- **Яаж таних?** Special-char input LDAP filter бүтцийг санаандгүй өөрчилсөн нь server logs/test directory result-т давтагдвал strong evidence; zero results дангаараа proof биш.
- **Хэрхэн засах?** RFC 4515 filter-value escaping, safe LDAP builder API, least-privilege bind.

### 28. XPath Injection — XML query expression-д input шингэх

- **Юу вэ?** XML database-ийн XPath query user input-тай string concatenation хийдэг.
- **Хаана шалгах?** Legacy XML apps, XML-backed search, directory services.
- **Аюулгүй жишээ:** Local test XML record-ийн name параметрт `O'Reilly` мэт **literal apostrophe** орсон үед query эвдэрч/буруу record буцааж байгаа эсэхийг шалга.
- **Яаж таних?** Query interpolation-ийн улмаас query meaning өөрчлөгдөж байгааг custom lab log/expected XML sample-тай тулга; ганц parser error proof биш.
- **Хэрхэн засах?** Parameterized XPath API/variable binding, robust escaping, schema-based validation.

### 29. CRLF / HTTP Response Splitting — Header-д мөр таслах

- **Юу вэ?** `\r\n` буюу Carriage Return/Line Feed (CRLF) тэмдэгт header value-д орвол шинэ header/response structure үүсгэж болно.
- **Хаана шалгах?** `Location`, download filename, custom response headers, redirect parameter.
- **Аюулгүй жишээ:** Local lab-д `filename=report%0D%0AX-Lab-Canary%3A%20yes` ашиглаж, өөрийн response header-ийг үз.
- **Яаж таних?** `X-Lab-Canary: yes` үнэхээр **тусдаа response header** болсон бол баттай indicator; URL-д `%0D%0A` хэвээр байвал flaw биш.
- **Хэрхэн засах?** Header values-д CR/LF хориглох, framework header API, RFC-compliant filename handling.

### 30. HTTP Host Header Injection — Host-оос буруу absolute URL үүсэх

- **Юу вэ?** Server `Host` header-ийг trust хийж password reset link, redirects, canonical URL-ийг хуурамч origin-оор бүтээдэг.
- **Хаана шалгах?** Absolute redirect, account emails (өөрийн test inbox), canonical tags, generated links.
- **Аюулгүй жишээ:**
  ```bash
  curl -i -H 'Host: lab.invalid' "$LAB/"
  ```
- **Яаж таних?** App-generated absolute link `lab.invalid` болсон нь анхааруулга; reset URL poisoning-д **өөрийн inbox** дээр баталгаажуулж, бусдад email явуулахгүй.
- **Хэрхэн засах?** Trusted application base URL config, Host allowlist, proxy header trust boundary.

---

## 5. Server-Side Attacks

### 31. SSRF — Server-Side Request Forgery

- **Юу вэ?** Client URL оруулж, серверээр өөр destination руу HTTP request явуулдаг; network boundary буруу давж болно.
- **Хаана шалгах?** Image URL fetch, webhook test, URL preview, PDF render, import from URL.
- **Аюулгүй жишээ (2 local service):** Lab application `127.0.0.1:8080`, **өөрийн** receiver `127.0.0.1:9001` дээр ажиллана. Lab-ийн URL-fetch параметрт `http://127.0.0.1:9001/lab-ping` өг. Container isolation/namespace өөр бол `127.0.0.1` нь өөр host заадаг болохыг сана.
- **Яаж таних?** Receiver log-д server-generated request ирсэн нь server-side fetch-ийг батална; **SSRF vulnerability** болох эсэх нь destination allowlist/security boundary зөрчсөн эсэхээс хамаарна. Cloud metadata/internal admin target руу бүү чиглүүл.
- **Хэрхэн засах?** URL scheme/host/IP allowlist, DNS resolve + revalidation, outbound network restrictions, redirect blocking, timeout.

### 32. Path Traversal — Файлын замын хязгаараас гарах

- **Юу вэ?** `../`-ээр intended upload/download directory-гээс дээш шилжинэ.
- **Хаана шалгах?** `/download?file=`, template path, export filename, image renderer.
- **Аюулгүй жишээ:** Өөрийн lab storage-д `/app/public/report.txt`, `/app/lab-marker.txt` гэсэн **нууц биш** хоёр файл үүсгээд `file=../lab-marker.txt` шалга.
- **Яаж таних?** Intended `/app/public`-оос гаднах `LAB_MARKER` файл уншигдвал confirmed. `404` эсвэл reflected `../` нь proof биш.
- **Хэрхэн засах?** Path normalization + canonical base-dir confinement, static ID→file mapping, filesystem least privilege.

### 33. LFI — Local File Inclusion

- **Юу вэ?** Local File Inclusion (LFI) нь хэрэглэгчийн input-г server-side include/template болгон ашиглаж local file-г unintended байдлаар include хийх.
- **Хаана шалгах?** `?page=`, `?template=`, language/content template routing.
- **Аюулгүй жишээ:** Lab-д өөрийн `/app/templates/lab-info.txt` бэлдээд `page=lab-info` болон зөвшөөрөгдөөгүй relative path-г харьцуул.
- **Яаж таних?** Allowlist-аас гаднах local marker-г app-ийн template inclusion уншсан бол evidence; ердийн static download нь LFI биш, traversal/data exposure байж болно.
- **Хэрхэн засах?** User-supplied filename-ээр include хийхгүй, fixed template allowlist, strict root confinement.

### 34. RFI — Remote File Inclusion

- **Юу вэ?** Remote File Inclusion (RFI) үед server external resource-ийг executable template/code хэлбэрээр include хийж болзошгүй.
- **Хаана шалгах?** Remote template/plugin configuration, legacy include features.
- **Аюулгүй жишээ:** Өөрийн isolated lab-д **inert текст** `RFI_LAB_MARKER` агуулсан local HTTP endpoint өгч remote fetching **эсвэл include** болж байгаа эсэхийг ажигла; executable code/remote shell бүү байрлуул.
- **Яаж таних?** Зөвхөн file fetch хийсэн нь RFI биш — server-side include/evaluation гэдгийг app log болон authorized lab trace-аар тусад нь нотол.
- **Хэрхэн засах?** Remote include feature унтраах, fixed signed templates/plugins, restrict network egress.

### 35. XXE — XML External Entity Injection

- **Юу вэ?** XML parser external entity resolve хийж server-ээр файл эсвэл remote resource уншуулах эрсдэлтэй.
- **Хаана шалгах?** XML/SOAP upload, SVG/XML parsing, document converters.
- **Аюулгүй жишээ:** Эхлээд local internal entity (`<!ENTITY marker "LAB_OK">`) parser боловсруулж буй эсэхийг шалга. Энэ нь **XXE биш**; зөвхөн зориуд бэлтгэсэн lab-д external entity-ийг өөрийн `127.0.0.1:9001` receiver рүү чиглүүлж хяна.
- **Яаж таних?** Local controlled receiver-д XML entity resolution-ээс request ирсэн нь external fetch нотолно; parser DOCTYPE зөвшөөрөх нь дангаараа file exfiltration болохгүй.
- **Хэрхэн засах?** DTD/external entities бүрэн disable, hardened XML parsers, egress restriction.

### 36. Insecure File Upload — Файл upload баталгаажуулалтын алдаа

- **Юу вэ?** Upload шалгалт хангалтгүйгээс аюултай file content executable эсвэл unrestricted public resource болж болно.
- **Хаана шалгах?** Avatar upload, document attachments, imports, image processing.
- **Аюулгүй жишээ:** Өөрийн lab-д **executables биш** `lab.txt` болон `lab.svg` (JS агуулаагүй) upload хийж storage location, MIME, download behavior шалга.
- **Яаж таних?** `.txt` content-г HTML гэж serve хийх зэрэг browser interpretation risk, private file public болох зэрэг policy violation-ийг тусад нь нотол. File extension accept хийх нь дангаараа critical vulnerability биш.
- **Хэрхэн засах?** File type validation by parser/magic bytes, safe re-encoding, non-executable separate storage, random names, `Content-Disposition: attachment`, strict access control.

### 37. Insecure Deserialization — Итгэлгүй serialized object сэргээх

- **Юу вэ?** User-controlled serialized bytes-г unsafe object parser/deserializer code path-д итгэн боловсруулдаг.
- **Хаана шалгах?** State cookies, signed/unsigned serialized blobs, backend queues, object import.
- **Аюулгүй жишээ:** Local lab-д unsigned serialized **benign** field-ийн value-г өөрчлөхөд server validation reject хийж байгаа эсэхийг шалга; gadget chain эсвэл RCE payload хэрэглэхгүй.
- **Яаж таних?** Input deserializer рүү орж trusted object state-г unauthorized өөрчилсөн бол evidence; Base64 string байх нь proof биш.
- **Хэрхэн засах?** Untrusted serialized object-с зайлсхийж JSON+schema хэрэглэх, cryptographic integrity, safe types allowlist, updated libraries.

### 38. HTTP Request Smuggling — Proxy/backend request boundary зөрөх

- **Юу вэ?** Front-end proxy ба backend HTTP request-ийн **хил**-ийг өөрөөр уншихад дараагийн request-д нөлөөлөх боломж үүснэ.
- **Хаана шалгах?** Reverse proxy + application server chain, HTTP/1.1 and HTTP/2 translation.
- **Аюулгүй жишээ:** Зөвхөн **single-user isolated lab**-д proxy/backend request framing болон parsed request count-ийг packet capture/log-оос харьцуул. Production/live shared connection руу smuggling payload илгээхгүй.
- **Яаж таних?** Parser disagreement лабораторийн log-д давтагдах ёстой. `400`, timeout, connection reset дангаараа request smuggling батлахгүй.
- **Хэрхэн засах?** Normalize/reject ambiguous framing, strict proxy/backend configurations, patched servers, consistent HTTP handling.

### 39. Race Condition — Нэгэн зэрэг request-ээс үүсэх логикийн алдаа

- **Юу вэ?** Parallel request ижил shared state шалгаж, update хийхийн хооронд давхацсанаас business rule алдагдана.
- **Хаана шалгах?** One-time coupon, inventory reservation, redemption, approval, transfer simulation.
- **Аюулгүй жишээ:** **Тусгаарласан** lab-д synthetic token `LABCOUPON`-г хоёр test request-ээр зэрэг redeem хийж, database-ийн **өөрийн** counter `1`-ээс хэтэрсэн эсэхийг хар.
- **Яаж таних?** Expected exactly-one operation байхад controlled test-д `2` successful commits гарвал confirmed. Network timing төдийхөн нь proof биш; production дээр concurrency stress хийхгүй.
- **Хэрхэн засах?** Transactions, atomic constraints, unique keys, idempotency keys, locking/version checks.

---

## 6. Business Logic, Cache & Misconfiguration

### 40. Price / Coupon Logic — Үнийн бизнес дүрэм алдагдах

- **Юу вэ?** Client-side price/discount-д server итгэдэг, coupon limits/quantity policy буруу шалгадаг.
- **Хаана шалгах?** Cart, checkout, discounts, loyalty, gift balance.
- **Аюулгүй жишээ:** Өөрийн lab захиалгад `unitPrice`-ийг client request-д зориудаар өөрчлөөд **payment хийхгүйгээр** quote response-г үз.
- **Яаж таних?** Server trusted catalog-аас тооцох ёстой үнээ client price-аар сольсон бол strong evidence; UI харагдах үнэ өөрчлөгдөх нь баталгаа биш.
- **Хэрхэн засах?** Price/tax/discount totals-г server-side authoritative data-аас тооцох, invariant checks, idempotency.

### 41. Workflow / Approval Bypass — Алхам алгасах

- **Юу вэ?** Батлах, төлөх, и-мэйл verify хийх гэх мэт заавал давах state machine-г алгасч final state-д очих.
- **Хаана шалгах?** Signup activation, checkout steps, approval workflow, KYC-like demo flow.
- **Аюулгүй жишээ:** Өөрийн demo request-г `DRAFT → REVIEW → APPROVED` state дарааллаар шалга; `DRAFT` state-тай record-ийн `GET /status`-д **зөвхөн read-only** шалгалт хий.
- **Яаж таних?** Unapproved test record өөрөө authorized биш атлаа final state авсан эсвэл restricted benefit бодитоор олдсон бол flaw.
- **Хэрхэн засах?** Server-side state transition rules, per-step authorization, immutable audit trail.

### 42. Sensitive Data in JavaScript / Source Maps

- **Юу вэ?** Public JS bundle эсвэл `.map`-д production secret, token, internal code/context алдагдсан.
- **Хаана шалгах?** `/static/*.js`, `*.js.map`, sourceMappingURL, mobile config.
- **Аюулгүй жишээ:** Өөрийн lab front-end bundle-д зориуд хийсэн `LAB_PUBLIC_MARKER` хай; **жинхэнэ олдсон credential-ийг ашиглаж шалгахгүй**.
- **Яаж таних?** `apiKey` нэртэй бүх string secret биш (public identifier байж болно). Үнэхээр privileged secret, sensitivity, scope-ийг owner-той баталгаажуул.
- **Хэрхэн засах?** Secrets client bundle-д оруулахгүй, credentials rotate, production source map access policy, CI secret scanning.

### 43. Verbose Errors / Debug Exposure

- **Юу вэ?** Debug stack trace, environment config, filesystem paths, internal IP, secrets response-д ил болдог.
- **Хаана шалгах?** Invalid input error pages, `/debug`, monitoring/status pages, API errors.
- **Аюулгүй жишээ:** Өөрийн lab-ийн `?id=not-a-number` request-г **ганц** удаа илгээж structured error response-г шалга.
- **Яаж таних?** Stack trace дангаараа context-specific information disclosure; secret/reusable credential/unsafe debug action илэрвэл ноцтой. Error 500 дангаараа vulnerability биш.
- **Хэрхэн засах?** Production debug off, generic errors, structured logging with secret redaction, restrict debug/admin endpoints.

### 44. Security Headers / Cookie Flags

- **Юу вэ?** Browser хамгаалалт дутуу: `HttpOnly`, `Secure`, `SameSite`, CSP, HSTS зэрэг буруу/алга.
- **Хаана шалгах?** `Set-Cookie`, `Content-Security-Policy`, `Strict-Transport-Security`, `X-Content-Type-Options`.
- **Аюулгүй жишээ:**
  ```bash
  curl -sS -D - -o /dev/null "$LAB/"
  ```
- **Яаж таних?** Cookie-ийн `Secure` production HTTPS-д байхгүй бол risk; **local HTTP lab-д** зориудаар байхгүй байж болно. Missing header бол severity-г threat model-оор үнэл — header absence дангаараа exploit батлахгүй.
- **Хэрхэн засах?** HTTPS + HSTS, `Secure; HttpOnly; SameSite=Lax/Strict` тохируулга, CSP, `nosniff`, correct cache policy.

### 45. Sensitive Caching — Private response cache-д хадгалагдах

- **Юу вэ?** Private API response browser эсвэл shared proxy cache-д буруу хадгалагдаж, өөр context-д өртөх.
- **Хаана шалгах?** `/account`, `/api/me`, statements, auth responses, CDN routes.
- **Аюулгүй жишээ:** Өөрийн session-ээс private request-ийн `Cache-Control`, `Vary`, `Age`, `X-Cache` header-ийг харьцуул.
- **Яаж таних?** `X-Cache: HIT` дангаараа data leak биш; **өөрийн хоёр test account**-ын private marker cross-user буцаж байвал батлагдана.
- **Хэрхэн засах?** Sensitive responses `Cache-Control: no-store`, correct CDN bypass, `Vary` by appropriate keys, user-specific responses never shared.

### 46. Web Cache Poisoning — Shared cache-г хортой content-оор дүүргэх

- **Юу вэ?** Cache key-д ороогүй request input (жишээ header) response-д нөлөөлж, дараагийн user-д ижил хариу serve болно.
- **Хаана шалгах?** Reverse proxy/CDN dynamic endpoints, `X-Forwarded-Host`, reflected headers.
- **Аюулгүй жишээ:** **Private isolated cache lab**-д `X-Lab-Canary: ABC` хүсэлт явуулж ижил cache key-ийн дараагийн anonymous response-д **өөрийн** `ABC` marker орж байгааг шалга.
- **Яаж таних?** Response reflection биш, **request-гүй дараагийн response cache-д хадгалагдсаныг** control-test-аар нотол. Public CDN-д poison хийхгүй.
- **Хэрхэн засах?** Cache key canonicalization, untrusted input-ийн response influence-ийг арилгах, caching policy hardening.

### 47. Web Cache Deception — Private content public cache path-аар алдагдах

- **Юу вэ?** Dynamic private response-г static file мэт URL/path ашиглан shared cache-д хадгалуулна.
- **Хаана шалгах?** Authenticated routes, cache extension rules (`.css`, `.js`), CDN behavior.
- **Аюулгүй жишээ:** Тусгаарласан lab-д өөрийн private `LAB_A_ONLY` response cache-д хадгалагдах эсэхийг хоёр **өөрийн** session-ээр шалга; shared production cache бүү бохирдуул.
- **Яаж таних?** Anonymous/B test session A-ийн өөрийн private marker-г cache-аас авсан бол батлагдана. Cache header өөрөө proof биш.
- **Хэрхэн засах?** Private path caching disable, origin cache headers enforce, consistent URL parsing between CDN and origin.

### 48. WebSocket Authorization / Cross-Site WebSocket Hijacking

- **Юу вэ?** WebSocket connection upgrade эсвэл channel subscription-д user/Origin/room authorization шалгаагүй.
- **Хаана шалгах?** `/ws`, chat subscriptions, notifications, real-time dashboards.
- **Аюулгүй жишээ:** Өөрийн хоёр account ашиглан A session-ээр B-ийн **өөрийн** test room subscription-г хүс; cross-origin connection-д cookie auto-sent эсэхийг браузераар шалга.
- **Яаж таних?** A session B room-ийн private test message авбал authorization flaw. `Origin` шалгалт алга байх нь автоматаар cross-site hijacking батлахгүй; credential delivery-г шалга.
- **Хэрхэн засах?** Upgrade + each message/channel authorization, Origin allowlist, session/token validation, tenant checks.

### 49. Prototype Pollution — JavaScript object prototype бохирдох

- **Юу вэ?** Untrusted object deep merge-ийн үед `__proto__` зэрэг key JavaScript object-ийн inherited properties-д нөлөөлнө.
- **Хаана шалгах?** JSON merges, URL query-to-object parser, settings/state libraries.
- **Аюулгүй жишээ:** **Зөвхөн өөрийн JS lab**-д plain benign `{ "__proto__": { "labMarker": "yes" } }` объект merge хийх test unit ажиллуул; production object-д mutation хийхгүй.
- **Яаж таних?** Шинэ, unrelated plain object `labMarker` inherited болсон бол pollution батлагдана; exploit impact хүрэх **separate sink** байгаа эсэхийг дараа үнэл.
- **Хэрхэн засах?** Unsafe deep merge арилгах, `__proto__`/`constructor`/`prototype` хориглох, safe parsers, `Object.create(null)` where appropriate.

### 50. API Rate-Limit / Resource Abuse Controls

- **Юу вэ?** Нэг user/client хэт олон resource-expensive request хийхэд abuse protections байхгүй.
- **Хаана шалгах?** OTP delivery, search, report export, invitation, expensive GraphQL queries.
- **Аюулгүй жишээ:** Written-approved **very low** request quota дотор 2–3 controlled lab requests хийж documented `429`/backoff behavior ажигла. Public target дээр stress/DoS test хийхгүй.
- **Яаж таних?** `429` харагдахгүй нь автоматаар flaw биш; app policy, endpoint cost, business impact, counters-аар үнэлнэ.
- **Хэрхэн засах?** Per-identity/IP/context quotas, exponential backoff, queue limits, GraphQL complexity budget, monitoring.

---

## 7. Тестийн богино workflow

1. [ ] **Scope:** Target, wildcard, login, rate limit, prohibited activities-ийг бичгээр баталгаажуул.
2. [ ] **Map:** Login → profile → API → file → admin → payment/action гэсэн route & role map гарга.
3. [ ] **Baseline:** Burp Proxy/HTTP history-аар нормал `request/response` хадгал.
4. [ ] **Authentication:** 2 test account, session, MFA, reset flows шалга.
5. [ ] **Authorization:** Owner ID, role, tenant, object fields, API nested resolver-ийг тусад нь баталгаажуул.
6. [ ] **Input:** HTML/JS/template/SQL/filter/file URL зэрэг trust boundary тус бүрийг шалга.
7. [ ] **Client:** DOM sinks, CSRF, CORS, clickjacking, browser policies хар.
8. [ ] **Server:** URL fetching, filesystem, parsers, uploads, proxy/caching rules-ийг lab/scope-д тохируул.
9. [ ] **Business logic:** Single-use, price, approval, state transition invariant-ийг synthetic өгөгдлөөр турш.
10. [ ] **Evidence:** baseline vs modified, timestamp, request ID, negative control, expected/actual-г mask хийж хадгал.
11. [ ] **Severity:** Confidentiality/Integrity/Availability, user interaction, privilege needed, scope, exploit preconditions.
12. [ ] **Report:** Нэг finding-д нэг root cause, давтагдах minimal PoC, remediation.

### Юуг «батлагдсан» гэж үзэх вэ?

| Зөвхөн сэжиг | Батлахад хэрэгтэй зүйл |
|---|---|
| Input HTML-д харагдах | XSS-д executable JS context + harmless code execution |
| `500 Internal Server Error` | Injection-д semantics-ийн controlled true/false ялгаа эсвэл server-side proof |
| ID солиход `200` | Өөрийн B object-ийн **private marker** A-д гарсан |
| CSRF token байхгүй | Cross-origin browser-аас cookie хавсарсан **state change** |
| `Access-Control-Allow-Origin: *` | Sensitive credentialed response-г browser JS уншсан эсэх |
| Server URL fetch хийсэн | Зөвшөөрөгдөөгүй outbound destination/security boundary зөрчсөн эсэх |
| Cache hit | Cross-context **private data** буцаж байгаа эсэх |

---

## 8. Evidence ба Report загвар

```markdown
# [Vulnerability] in [Affected Function]

## Summary
[1–2 өгүүлбэр: trust boundary, яг ямар буруу үйлдэл гарсан]

## Scope & Preconditions
- In-scope lab/app: ...
- Test roles: User A (owner), User B (other owner) / Viewer, Admin
- Data: synthetic only

## Steps to Reproduce
1. Өөрийн тест account-уудаар өгөгдөл үүсгэнэ.
2. Normal request-ийг Burp Repeater-д хадгална.
3. Зөвхөн [parameter]-ийг [benign marker] болгон өөрчилнө.
4. Expected ба Actual response/state-г харьцуулна.
5. Negative control-ийг ажиллуулна.

## Expected vs Actual
- Expected: 403 / escaped output / rejected cross-site request
- Actual: [яг бодит нотолгоо; дан HTTP status биш]

## Evidence (secrets redacted)
- Timestamp, endpoint, request method, sanitized request/response
- Screenshot/DOM/database entry of own synthetic marker
- Negative control outcome

## Impact
- Confidentiality: ...
- Integrity: ...
- Availability: ...
- Preconditions: ...
- Severity: Contextual (CVSS if used)

## Remediation
[Server-side fix + regression test]
```

**Privacy:** Bearer tokens, cookies, secrets, email, IP, customer data-г screenshot/log/report-д нууцлах. Token value-г `REDACTED` гэж тэмдэглэ. Бусдын өгөгдөл рүү нэвтрэх, production write test, load testing хийхгүй.

---

## 9. Эх сурвалж, дараагийн сургалт

- **OWASP Web Security Testing Guide (WSTG):** https://wstg.owasp.org/
- **PortSwigger Web Security Academy — all topics:** https://portswigger.net/web-security/all-topics
- **XSS:** https://portswigger.net/web-security/cross-site-scripting
- **CSRF:** https://portswigger.net/web-security/csrf
- **Access Control / IDOR:** https://portswigger.net/web-security/access-control
- **SQL Injection:** https://portswigger.net/web-security/sql-injection
- **SSRF:** https://portswigger.net/web-security/ssrf
- **OWASP API Security Top 10:** https://owasp.org/API-Security/
- **OWASP Juice Shop:** https://owasp.org/www-project-juice-shop/
- **OWASP WebGoat:** https://owasp.org/www-project-webgoat/

**Зөвлөмжтэй дараалал:** HTTP/Burp → Reflected XSS → Stored/DOM XSS → CSRF → IDOR/BOLA → SQLi → JWT/Session → SSRF/Traversal → GraphQL → Logic/Cache. Онолын хэсэг бүрийн дараа **өөрийн lab-д нэг test case + нэг тайлан** бич.

> **Анхааруулга:** Энэ нь GitHub-ийн тодорхой материалыг үгчлэн хуулсан файл биш, хүссэн 5 асуултын бүтцээр шинээр эмхэтгэсэн Монгол хэл дээрх field guide юм. Тестийн URL-ууд нь тайлбарлах зорилготой бөгөөд тухайн lab-ийн бодит замтай тааруулах шаардлагатай.
