# Web Attacks Field Guide — Монгол Markdown Library

**50 web vulnerability topic** · Богино, шууд ашиглах бүтэц: **Юу вэ → Хаана шалгах → Аюулгүй жишээ → Яаж таних → Хэрхэн засах**.

Эхлээд [нэгдсэн guide](WEB_ATTACKS_FIELD_GUIDE_MN.md)-ийн эхний хэсгийг уншина уу. Тестийн endpoint-ууд нь **зөвхөн жишээ**; local lab ба in-scope зөвшөөрөлтэй environment-д тохируулж хэрэглэнэ. Эмзэг байдлыг HTTP status болон input reflection-ээр дангаар нь батлахгүй.

## Агуулга

- [01. Reflected XSS — Хариунд шууд туссан JavaScript](topics/01_browser_client/01_reflected_xss.md)
- [02. Stored XSS — Хадгалагддаг JavaScript](topics/01_browser_client/02_stored_xss.md)
- [03. DOM-based XSS — Browser-side JavaScript-ийн алдаа](topics/01_browser_client/03_dom_based_xss.md)
- [04. HTML Injection — HTML бүтэц оруулах](topics/01_browser_client/04_html_injection.md)
- [05. CSRF — Cross-Site Request Forgery](topics/01_browser_client/05_csrf.md)
- [06. Clickjacking — Харагдахгүй/давхарласан iframe-аар click хийлгэх](topics/01_browser_client/06_clickjacking.md)
- [07. CORS Misconfiguration — Cross-Origin Resource Sharing буруу тохируулга](topics/01_browser_client/07_cors_misconfiguration.md)
- [08. Open Redirect — Гадны сайт руу дур мэдэн чиглүүлэх](topics/01_browser_client/08_open_redirect.md)
- [09. Account Enumeration — Хэрэглэгч бүртгэлтэй эсэхийг ил болгох](topics/02_auth_session/09_account_enumeration.md)
- [10. Password Reset Flaw — Нууц үг сэргээх урсгалын алдаа](topics/02_auth_session/10_password_reset_flaw.md)
- [11. MFA Flow Bypass — Multi-Factor Authentication урсгалын алдаа](topics/02_auth_session/11_mfa_flow_bypass.md)
- [12. Session Fixation — Нэвтрэхэд session солигдохгүй байх](topics/02_auth_session/12_session_fixation.md)
- [13. Logout / Revocation Failure — Logout дараа session хүчинтэй үлдэх](topics/02_auth_session/13_logout_revocation_failure.md)
- [14. JWT Validation Flaw — JSON Web Token шалгалтын алдаа](topics/02_auth_session/14_jwt_validation_flaw.md)
- [15. OAuth 2.0 / OpenID Connect (OIDC) Flow Flaws](topics/02_auth_session/15_oauth_2_0_openid_connect_oidc_flow_flaws.md)
- [16. IDOR / BOLA — Object-level эрхийн алдаа](topics/03_authorization_api/16_idor_bola.md)
- [17. BFLA — Broken Function Level Authorization](topics/03_authorization_api/17_bfla.md)
- [18. Vertical Privilege Escalation — Role өсгөх](topics/03_authorization_api/18_vertical_privilege_escalation.md)
- [19. Mass Assignment / BOPLA — Илүүдэл property өөрчлөх](topics/03_authorization_api/19_mass_assignment_bopla.md)
- [20. Tenant Isolation — Байгууллага хоорондын тусгаарлалтын алдаа](topics/03_authorization_api/20_tenant_isolation.md)
- [21. Excessive Data Exposure — API илүүдэл мэдээлэл буцаах](topics/03_authorization_api/21_excessive_data_exposure.md)
- [22. GraphQL Authorization — Query resolver-ийн эрхийн алдаа](topics/03_authorization_api/22_graphql_authorization.md)
- [23. SQL Injection (SQLi) — SQL query-д input шингэх](topics/04_injection/23_sql_injection_sqli.md)
- [24. NoSQL Injection — NoSQL query operator шингэх](topics/04_injection/24_nosql_injection.md)
- [25. OS Command Injection — Shell command-д input шингэх](topics/04_injection/25_os_command_injection.md)
- [26. SSTI — Server-Side Template Injection](topics/04_injection/26_ssti.md)
- [27. LDAP Injection — Directory query filter-д input шингэх](topics/04_injection/27_ldap_injection.md)
- [28. XPath Injection — XML query expression-д input шингэх](topics/04_injection/28_xpath_injection.md)
- [29. CRLF / HTTP Response Splitting — Header-д мөр таслах](topics/04_injection/29_crlf_http_response_splitting.md)
- [30. HTTP Host Header Injection — Host-оос буруу absolute URL үүсэх](topics/04_injection/30_http_host_header_injection.md)
- [31. SSRF — Server-Side Request Forgery](topics/05_server_side/31_ssrf.md)
- [32. Path Traversal — Файлын замын хязгаараас гарах](topics/05_server_side/32_path_traversal.md)
- [33. LFI — Local File Inclusion](topics/05_server_side/33_lfi.md)
- [34. RFI — Remote File Inclusion](topics/05_server_side/34_rfi.md)
- [35. XXE — XML External Entity Injection](topics/05_server_side/35_xxe.md)
- [36. Insecure File Upload — Файл upload баталгаажуулалтын алдаа](topics/05_server_side/36_insecure_file_upload.md)
- [37. Insecure Deserialization — Итгэлгүй serialized object сэргээх](topics/05_server_side/37_insecure_deserialization.md)
- [38. HTTP Request Smuggling — Proxy/backend request boundary зөрөх](topics/05_server_side/38_http_request_smuggling.md)
- [39. Race Condition — Нэгэн зэрэг request-ээс үүсэх логикийн алдаа](topics/05_server_side/39_race_condition.md)
- [40. Price / Coupon Logic — Үнийн бизнес дүрэм алдагдах](topics/06_logic_cache_config/40_price_coupon_logic.md)
- [41. Workflow / Approval Bypass — Алхам алгасах](topics/06_logic_cache_config/41_workflow_approval_bypass.md)
- [42. Sensitive Data in JavaScript / Source Maps](topics/06_logic_cache_config/42_sensitive_data_in_javascript_source_maps.md)
- [43. Verbose Errors / Debug Exposure](topics/06_logic_cache_config/43_verbose_errors_debug_exposure.md)
- [44. Security Headers / Cookie Flags](topics/06_logic_cache_config/44_security_headers_cookie_flags.md)
- [45. Sensitive Caching — Private response cache-д хадгалагдах](topics/06_logic_cache_config/45_sensitive_caching.md)
- [46. Web Cache Poisoning — Shared cache-г хортой content-оор дүүргэх](topics/06_logic_cache_config/46_web_cache_poisoning.md)
- [47. Web Cache Deception — Private content public cache path-аар алдагдах](topics/06_logic_cache_config/47_web_cache_deception.md)
- [48. WebSocket Authorization / Cross-Site WebSocket Hijacking](topics/06_logic_cache_config/48_websocket_authorization_cross_site_websocket_hijacking.md)
- [49. Prototype Pollution — JavaScript object prototype бохирдох](topics/06_logic_cache_config/49_prototype_pollution.md)
- [50. API Rate-Limit / Resource Abuse Controls](topics/06_logic_cache_config/50_api_rate_limit_resource_abuse_controls.md)

## References

- https://wstg.owasp.org/
- https://portswigger.net/web-security/all-topics
- https://owasp.org/API-Security/
