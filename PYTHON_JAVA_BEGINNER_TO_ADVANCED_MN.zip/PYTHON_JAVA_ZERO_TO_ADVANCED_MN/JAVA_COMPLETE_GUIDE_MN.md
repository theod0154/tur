# JAVA — Beginner → Advanced | Монгол хэл дээрх практик сургалтын гарын авлага

> **Зорилго:** Анхан шатнаас эхлэн Java syntax, Object-Oriented Programming (OOP), Collections, Generics, Streams, concurrency, JVM, clean/secure coding, source code review эзэмших.
>
> **Орчин:** JDK 25 (Long-Term Support/LTS)-ийг санал болгоно; **жишээний хэлний онцлогууд JDK 21+ дээр ажиллахуйц** бичсэн. `javac` (compile), `java` (run), IDE нь IntelliJ IDEA Community эсвэл VS Code. **Localhost web lab шаардлагагүй.**
>
> **Сурах арга:** Кодыг эхлээд уншиж таамагла → өөрөө бич → ажиллуул → өөрчил → алдааг тайлбарла → бие даах дасгалаа гүйцэтгэ.

## Агуулга
1. JDK, JVM, bytecode, анхны Java програм
2. Primitive types, reference, String, operator
3. `if`, `switch`, `for`, `while`, arrays
4. Methods, parameters, recursion
5. Class, objects, constructors, encapsulation
6. Inheritance, interfaces, polymorphism, records, enums
7. Exception handling, resources
8. Collections, Generics, Optional
9. Lambda, Streams, functional thinking
10. Files, NIO, date/time
11. Maven, JUnit, tests, build
12. Threads, synchronization, virtual threads
13. JDBC, transactions, prepared statements
14. JVM memory, GC, performance, diagnostics
15. Secure coding, source review, capstone projects

---

## 01. Java гэж юу вэ? JDK, JVM ба анхны код

Java нь статик type шалгадаг, олон платформд ажиллах ecosystem бүхий програмчлалын хэл. **JDK** (Java Development Kit) дотор compiler `javac` болон `java` launcher орно. **JVM** (Java Virtual Machine) нь compiled bytecode ажиллуулна. `.java` нь source; `.class` нь байткод.

```bash
java -version       # Java runtime хувилбар
javac -version      # Compiler хувилбар
```

`Hello.java` үүсгэ:

```java
public class Hello {
    public static void main(String[] args) {
        System.out.println("Sain baina uu, Java!");
    }
}
```

```bash
javac Hello.java
java Hello
```

```text
Sain baina uu, Java!
```

**Код унших:** `class Hello` = class нэр, `main` = application entry point, `System.out.println` = console дээр мөр хэвлэх, `;` = statement дууслаа. `public class`-ийн нэр болон файлын нэр ижил байх ёстой. `java Hello` гэж ажиллуулахдаа `.class` нэмэхгүй.

**Алдаа:** `javac: command not found` бол JDK PATH тохируулаагүй; `Could not find or load main class` бол хавтас/classpath, class нэрийг шалга; `';' expected` бол төгсгөлийн `;` алга.

**Дасгал:** Нэр, нас, сурч буй хэлээ хэвлэ. `javac`-ийн үүрэг `java`-гаас ямар ялгаатай вэ?

## 02. Primitive types, reference, String

Java-ийн **primitive**: `byte`, `short`, `int`, `long`, `float`, `double`, `char`, `boolean`. Object type: `String`, `Integer`, `List` гэх мэт **reference**-ээр хандана. Type нь compile-time дээр шалгагдана.

```java
public class TypesDemo {
    public static void main(String[] args) {
        int count = 10;
        double price = 19.5;
        boolean active = true;
        String owner = "Anu";
        System.out.println(owner + ": " + (count * price));
        System.out.println(7 / 2);     // 3: бүхэл тоон хуваалт
        System.out.println(7.0 / 2);   // 3.5
    }
}
```

`String` нь immutable; текстийн **утга** тэнцүүг `.equals()`-аар харьцуул, `==` нь reference equality-г шалгадаг.

```java
String a = new String("hello");
String b = new String("hello");
System.out.println(a.equals(b)); // true
System.out.println(a == b);      // false
```

Энэ snippet-ийг `main` дотор байрлуул. `null` объект биш; `obj.method()` гэж `null` дээр дуудах үед `NullPointerException`. Мөнгөний дүн, нарийн аравтын тоонд `BigDecimal` хэрэглэх талаар дараа нь үз.

**Дасгал:** String-н уртыг `.length()`-ээр хэвлэ; `==` vs `.equals` зөрүүг өөрийн үгээр тайлбарла; `int`-ээс `double` рүү хөрвүүлэх код бич.

## 03. `if`, `switch`, `for`, `while`, arrays

```java
public class ControlFlow {
    public static void main(String[] args) {
        int score = 85;
        String grade = score >= 90 ? "A" : (score >= 70 ? "B" : "C");
        System.out.println(grade); // B

        int[] nums = {2, 4, 6};
        for (int n : nums) {
            System.out.println(n);
        }
    }
}
```

`int[] nums` нь array; хэмжээ нь тогтмол. `nums[0]` эхний элемент; `nums.length` хэмжээ (method биш). `for-each` нь бүх элементээр давтана; индекс хэрэгтэй бол `for (int i = 0; i < nums.length; i++)`.

```java
String status = "up";
String message = switch (status) {
    case "up" -> "OK";
    case "down" -> "ALERT";
    default -> "UNKNOWN";
};
System.out.println(message); // OK
```

`switch expression`-д бүх боломжийг хамруулах шаардлагатай (`default` эсвэл exhaustive cases). Давталтын нөхцөл буруу бол infinite loop үүсч болно.

**Дасгал:** 1–50 хүртэл 5-д хуваагдах тоонуудыг хэвлэ; 5 тооны max ол; өдөрт тохирсон `switch` message зохио.

## 04. Methods, parameters, return, recursion

Method нь class дотор тодорхойлдог, давтан ашиглаж болох үйлдэл. `public/private` нь access modifier, `static` нь объект үүсгэхгүйгээр class-аар дуудах, `void` нь буцаах утгагүй гэсэн утгатай.

```java
public class Calculator {
    static int add(int a, int b) {
        return a + b;
    }

    static int factorial(int n) {
        if (n < 0) throw new IllegalArgumentException("negative n");
        if (n <= 1) return 1;      // base case
        return n * factorial(n - 1);
    }

    public static void main(String[] args) {
        System.out.println(add(2, 3));      // 5
        System.out.println(factorial(4));    // 24
    }
}
```

`recursion` нь method өөрийгөө дуудах. Base case байхгүй бол `StackOverflowError`, хэт өндөр `n` бол `int` overflow болно. Java-ийн primitive аргумент утгаар дамжина; object reference **өөрөө** мөн утгаар дамжина (Java бол pass-by-value).

**Дасгал:** `isEven(int n)`, `max(int[] a)`, `isPrime(int n)` methods бич. 0, 1, сөрөг тооны edge case шалга.

## 05. OOP: class, encapsulation, constructor

**Encapsulation** нь object-ийн дотоод төлөвийг хяналттай method-аар өөрчлөх. Field-ийг шууд `public` болговол буруу утга чөлөөтэй оноох эрсдэлтэй.

```java
public class BankAccount {
    private final String owner;
    private long balance;

    public BankAccount(String owner, long openingBalance) {
        if (owner == null || owner.isBlank() || openingBalance < 0) {
            throw new IllegalArgumentException("invalid account");
        }
        this.owner = owner;
        this.balance = openingBalance;
    }

    public void deposit(long amount) {
        if (amount <= 0) throw new IllegalArgumentException("amount must be positive");
        balance = Math.addExact(balance, amount);  // overflow тохиолдолд exception
    }

    public long getBalance() { return balance; }
    public String getOwner() { return owner; }

    public static void main(String[] args) {
        BankAccount account = new BankAccount("Anu", 100);
        account.deposit(50);
        System.out.println(account.getBalance()); // 150
    }
}
```

`private` нь field-г class-аас гадна шууд өөрчлөхийг хязгаарлана. `final` field нь constructor-д нэг удаа оноогдоно. Санхүүгийн production тооцоонд `long`-ийг minor unit (жишээ нь цент) эсвэл `BigDecimal`-тай зохих бизнес дүрмээр сонго.

**Дасгал:** `InventoryItem` class-д `addStock`, `removeStock`, `getQuantity`; сөрөг үлдэгдэл зөвшөөрөхгүй. Public field болон private field-ийн ялгааг тайлбарла.

## 06. Inheritance, interface, polymorphism, record, enum

`Inheritance` = child class parent class-ийн боломжийг өвлөнө (`extends`). `Interface` = ямар үйлдэл хэрэгжүүлэх гэрээ (`implements`). `Polymorphism` = нэг interface-ээр олон төрлийн объекттой ажиллах. **Composition**-ийг inherit-ээс түрүүнд бодолц, ялангуяа "has-a" харилцаанд.

```java
interface Notifier {
    void send(String message);
}

class ConsoleNotifier implements Notifier {
    @Override
    public void send(String message) {
        System.out.println("NOTICE: " + message);
    }
}

public class NotifyDemo {
    static void notifyUser(Notifier notifier, String text) {
        notifier.send(text);
    }

    public static void main(String[] args) {
        notifyUser(new ConsoleNotifier(), "Ready"); // NOTICE: Ready
    }
}
```

**Record:** data-carrier class-ийг товч бичнэ; `record` shallow immutability-тай (доторх mutable object өөрчлөгдөж болно).

```java
record Finding(String title, int severity) {
    Finding {
        if (severity < 1 || severity > 5) throw new IllegalArgumentException();
    }
}
enum State { OPEN, CLOSED }
```

`sealed` class/interface нь хэн өвлөж болохыг хязгаарладаг; `record` болон `enum`-ийг JDK21+ дээр ашиглаж болно. Java-ийн `interface` дээр `default` method байж болно.

**Дасгал:** `Shape` interface + `Rectangle` ба `Circle` хэрэгжүүл; `area()`-г polymorphism-аар дуудах; `record Asset(String host, String owner)` үүсгэ.

## 07. Exception болон resource management

`Exception` нь урсгалыг өөрчилж болох алдаа. `checked exception`-ийг компилятор handle/declare хийхийг шаарддаг (`IOException`); `unchecked` (`IllegalArgumentException`) нь runtime-д шалгагдана. Буруу exception-ийг зүгээр залгиж болохгүй.

```java
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;

public class ReadDemo {
    public static void main(String[] args) {
        try {
            String text = Files.readString(Path.of("notes.txt"));
            System.out.println(text);
        } catch (IOException ex) {
            System.err.println("Cannot read notes.txt: " + ex.getMessage());
        }
    }
}
```

`try-with-resources` нь `AutoCloseable` объектыг хаадаг, `finally` нь амжилт эсэхээс үл хамааран ажилладаг. Error-г хэвлэхдээ secret/token эсвэл sensitive path гарч болзошгүй эсэхийг анхаар.

```java
import java.io.BufferedReader;
import java.nio.file.Files;
import java.nio.file.Path;

try (BufferedReader reader = Files.newBufferedReader(Path.of("notes.txt"))) {
    System.out.println(reader.readLine());
}
// Энэ snippet-ийг method дотор хэрэглэж,
// IOException-г catch эсвэл throws IOException-аар зохицуулна.
```

**Дасгал:** Байхгүй файл уншихад ямар exception гарах вэ? JSON parse алдааг хэрхэн тусад нь handle хийх вэ (номын сан ашиглавал)? Хэзээ `finally` шаардлагатай вэ?

---
## 08. Collections, Generics, Optional

`ArrayList` нь динамик list, `HashSet` нь давхардалгүй element, `HashMap` нь key/value, `Deque` нь queue/stack маягийн бүтэц. `Generics<T>` нь type-safe collection болон reusable method/class бичихэд тусалдаг.

```java
import java.util.*;

public class CollectionDemo {
    public static void main(String[] args) {
        List<String> hosts = new ArrayList<>();
        hosts.add("web01");
        hosts.add("db01");
        hosts.add("web01");
        System.out.println(hosts.size()); // 3
        Set<String> unique = new HashSet<>(hosts);
        System.out.println(unique.size()); // 2
        Map<String, Integer> counts = new HashMap<>();
        counts.put("up", 3);
        System.out.println(counts.getOrDefault("down", 0)); // 0
    }
}
```

`HashMap` ба `HashSet`-ийн iteration order баталгаагүй; insertion order хэрэгтэй үед `LinkedHashMap`/`LinkedHashSet`; sorted order хэрэгтэй бол `TreeMap`/`TreeSet`.

```java
import java.util.Optional;

public class OptionalDemo {
    static Optional<String> getOwner(boolean known) {
        return known ? Optional.of("IT") : Optional.empty();
    }
    public static void main(String[] args) {
        System.out.println(getOwner(false).orElse("unassigned")); // unassigned
    }
}
```

`Optional.get()`-ийг нөхцөлгүй дуудаж болохгүй; `orElse`, `orElseGet`, `ifPresent` ашигла. `List<String>` нь `List<Object>`-ийн subtype биш (invariance); `? extends T` нь read producer, `? super T` нь consumer-д тохирох *PECS* дүрмийг судал.

**Дасгал:** Хамгийн олон давтагдсан hostname ол; inventory-д hostname→owner map үүсгэ; Generic `Pair<A,B>` record зохио.

## 09. Lambda, Streams, functional style

`lambda` бол function-like inline expression; `Stream` нь collection-оор pipeline боловсруулна: `filter`, `map`, `sorted`, `collect`. Stream-ийг нэг удаа хэрэглэнэ; шаардлагагүй mutable side effect хийхгүй.

```java
import java.util.List;

public class StreamDemo {
    public static void main(String[] args) {
        List<Integer> nums = List.of(1, 2, 3, 4, 5);
        List<Integer> squares = nums.stream()
                .filter(n -> n % 2 == 0)
                .map(n -> n * n)
                .toList();
        System.out.println(squares); // [4, 16]
    }
}
```

`stream()` өөрөө эх өгөгдлийг өөрчилдөггүй. `toList()`-ийн буцаасан жагсаалт unmodifiable; элемент нэмэх шаардлагатай бол шинэ `ArrayList<>(...)` үүсгэ. Parallel stream хурдан гэсэн баталгаа биш; CPU, dataset, ordering болон side effect бодолц.

```java
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

var hosts = List.of("web01", "db01", "web01");
Map<String, Long> count = hosts.stream()
        .collect(Collectors.groupingBy(s -> s, Collectors.counting()));
System.out.println(count.get("web01")); // 2
```

Энэ snippet-ийг method дотор байрлуул. `var` бол local variable type inference, dynamic type биш.

**Дасгал:** Asset-ийн status=`down` мөрүүдийг filter хий; `groupingBy`-аар department тоол; Loop хувилбар ба Stream хувилбарын уншигдах байдлыг харьцуул.

## 10. File I/O, NIO, date/time

`java.nio.file.Path` нь файл зам, `Files` нь унших/бичих API; `java.time` нь өдөр/цагийн modern immutable API. `LocalDateTime` нь timezone агуулахгүй, `Instant` нь timeline цэг, `ZonedDateTime` timezone rule-тэй.

```java
import java.nio.file.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class FileDemo {
    public static void main(String[] args) throws IOException {
        Path p = Path.of("report.txt");
        Files.writeString(p, "host,status\nweb01,up\n", StandardCharsets.UTF_8);
        String value = Files.readString(p, StandardCharsets.UTF_8);
        System.out.print(value);
    }
}
```

```java
import java.time.*;
import java.time.format.DateTimeFormatter;

public class TimeDemo {
    public static void main(String[] args) {
        LocalDate d = LocalDate.of(2026, 11, 20);
        System.out.println(d.plusDays(7)); // 2026-11-27
        Instant now = Instant.now();
        System.out.println(now.isBefore(now.plusSeconds(1))); // true
    }
}
```

Найдвартай лог, audit-т `Instant` хадгалах, UI дээр хэрэглэгчийн timezone-аар хөрвүүлэх нь түгээмэл. File path-д user input оруулахдаа canonical path validation болон зөвшөөрөгдсөн directory boundary-г шалга.

**Дасгал:** `assets.txt` уншаад мөр бүрийн тоог тоол; системийн цаг хэрэглэж filename үүсгэхдээ зөв format ашигла; UTF-8 encoding алдааг тайлбарла.

## 11. Build tools, Maven, JUnit testing

Том төсөлд гар аргаар `javac` хийхэд dependency хэцүү. `Maven` нь build/dependency management; `pom.xml` project metadata; `JUnit` бол test framework. `Gradle` нь өөр build сонголт — нэгийг гүнзгий эзэмшээд нөгөөгийн үндсийг сур.

```text
my-app/
  pom.xml
  src/main/java/org/example/Calculator.java
  src/test/java/org/example/CalculatorTest.java
```

`pom.xml`-ийн минимал жишээ (Maven/JUnit суулгаж, dependency татаж ашиглах үед интернет шаардаж болно; localhost server хэрэггүй):

```xml
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <groupId>org.example</groupId>
  <artifactId>my-app</artifactId>
  <version>1.0-SNAPSHOT</version>
  <properties><maven.compiler.release>21</maven.compiler.release></properties>
  <dependencies>
    <dependency>
      <groupId>org.junit.jupiter</groupId>
      <artifactId>junit-jupiter</artifactId>
      <version>5.11.4</version>
      <scope>test</scope>
    </dependency>
  </dependencies>
  <build><plugins>
    <plugin>
      <groupId>org.apache.maven.plugins</groupId>
      <artifactId>maven-surefire-plugin</artifactId>
      <version>3.5.2</version>
    </plugin>
  </plugins></build>
</project>
```

> Dependency version нь суралцах үеийн **жишээ version**; ашиглахаасаа өмнө албан сайт/байгууллагын approved release-ийг шалга. Заавал latest гэж үзэхгүй.

```java
// src/main/java/org/example/Calculator.java
package org.example;
public class Calculator {
    public static int add(int a, int b) { return Math.addExact(a, b); }
}
```

```java
// src/test/java/org/example/CalculatorTest.java
package org.example;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class CalculatorTest {
    @Test void addsNumbers() { assertEquals(5, Calculator.add(2, 3)); }
    @Test void detectsOverflow() {
        assertThrows(ArithmeticException.class,
            () -> Calculator.add(Integer.MAX_VALUE, 1));
    }
}
```

```bash
mvn test      # Тест ажиллуулна
mvn package   # Build + тест, artifact үүсгэнэ
```

`mvn test` ажиллахгүй бол Maven суулгасан эсэх (`mvn -version`), Java version, интернет/dependency, зөв folder-т ажиллаж байгаа эсэхийг шалга. `mvn -q test` нь гаралтыг богиносгоно; debugging хийхдээ `-q`-г хас.

**Дасгал:** `subtract` method нэм; negative case-ууд тестлэ; тестийг зориудаар унагаж build failure-г ажигла.

## 12. Concurrency: Thread, synchronization, virtual threads

`Thread` нь гүйцэтгэлийн урсгал; олон thread-ийн **shared mutable state** хамгаалалтгүй бол race condition. `synchronized` болон `java.util.concurrent` API-ууд нь зохицуулдаг. `virtual threads` JDK21+ дээр олон I/O waiting task-д тустай; CPU-heavy тооцоог ид шидээр хурдлуулахгүй.

```java
import java.util.concurrent.*;

public class VirtualThreadDemo {
    public static void main(String[] args) throws Exception {
        try (ExecutorService service = Executors.newVirtualThreadPerTaskExecutor()) {
            Future<Integer> a = service.submit(() -> 20 + 22);
            Future<Integer> b = service.submit(() -> 10 * 2);
            System.out.println(a.get() + b.get()); // 62
        }
    }
}
```

```java
import java.util.concurrent.atomic.AtomicInteger;

AtomicInteger counter = new AtomicInteger(0);
counter.incrementAndGet();  // atomic update
System.out.println(counter.get()); // 1
```

`AtomicInteger` кодыг method дотор хэрэглэ. `volatile` нь visibility-г сайжруулах боловч `counter++`-ийг atomic болгодоггүй. `CompletableFuture` нь async result composition-д хэрэглэгдэнэ. Thread pool-ийг хэт том болгох, blocking task-ийг мэдэлгүй хаях, exception буруу handle хийх нь нийтлэг алдаа.

**Дасгал:** 1000 increment-ийг concurrency-аар хийж, зөв count-г `AtomicInteger`-ээр баталгаажуул; `Future.get()` юу хүлээдэгийг тайлбарла.

## 13. JDBC, SQL, transaction

`JDBC` (Java Database Connectivity) нь Java application-аас SQL database-тай холбогдох API. Энэ бүлгийн код **архитектурын жишээ**: бодит DB ажиллуулах шаардлагагүй. SQL Injection-ээс хамгаалахдаа query syntax ба user-provided value-г салгах `PreparedStatement` хэрэглэ.

```java
import java.sql.*;

public class UserRepository {
    public static String findEmail(Connection db, String username) throws SQLException {
        String sql = "SELECT email FROM users WHERE username = ?";
        try (PreparedStatement stmt = db.prepareStatement(sql)) {
            stmt.setString(1, username); // value binding (SQL string concatenation биш)
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() ? rs.getString("email") : null;
            }
        }
    }
}
```

`Connection` нь application-ийн trusted component-аас ирнэ; DB credentials-ийг source-д hardcode хийхгүй. `?` нь table/column name-ийн placeholder биш, зөвхөн value-binding-д зориулагдсан. Dynamic identifier хэрэгтэй бол **allowlist** ашигла.

**Transaction:** Бүтэн үйлдэл бүгд амжилттай бол `commit`, аль нэг нь амжилтгүй бол `rollback`. `setAutoCommit(false)`-ийг зориудаар ашиглахдаа connection lifecycle-г удирд; нууц мэдээлэл log-д бичихгүй.

**Дасгал:** `WHERE id = ? AND owner_id = ?` загварын **object-level authorization** шалгалт яагаад зөвхөн `WHERE id = ?`-ээс илүү хамгаалалттайг тайлбарла. SQL schema-д `UNIQUE`, `NOT NULL` аль нь ямар validation хийдэгийг нэрлэ.

## 14. JVM memory, Garbage Collection, performance

**JVM memory:** `stack` нь method call/local variables-ийн execution frame, `heap` нь object allocation, `metaspace` нь class metadata зэрэг зүйлсийн зориулалттай. `GC` (Garbage Collection) нь ашиглагдахаа больсон object-уудын memory-г reclaimed хийдэг; object memory алдагдахгүй гэсэн баталгаа биш.

```bash
java -XshowSettings:vm -version
java -Xmx256m Hello
```

`-Xmx256m` нь max Java heap size-г 256 MiB орчимд тохируулна; `-XshowSettings:vm` нь VM тохиргооны мэдээлэл харуулна. `-Xmx` багадвал `OutOfMemoryError` үүсч болно, зөвхөн heap өсгөх нь code bug-г арилгахгүй.

```java
import java.util.ArrayList;
import java.util.List;

public class MemoryDemo {
    public static void main(String[] args) {
        List<String> names = new ArrayList<>();
        for (int i = 0; i < 3; i++) names.add("host-" + i);
        System.out.println(names); // [host-0, host-1, host-2]
    }
}
```

Memory profiling-д `jcmd`, Java Flight Recorder (JFR), VisualVM зэрэг tool; гүйцэтгэл сайжруулахдаа эхлээд **measurement** хий. Төсөл бүрт complexity, allocation, GC pause, throughput, latency өөр ач холбогдолтой.

**Дасгал:** Heap ба stack ялгааг зурж тайлбарла; `StringBuilder` яагаад их давталтад `String +`-аас зарим нөхцөлд давуу байж болох вэ? Benchmark хийхдээ warmup яагаад чухал вэ?

## 15. Secure Coding, Source Code Review, capstone

**Secure review checklist:** input validation, authentication vs authorization, SQL parameters, deserialization, path handling, secrets, logging, dependency integrity, exception handling, concurrency invariants.

```java
// АЮУЛТАЙ ХЭВ МАЯГ: SQL утгыг string concatenation хийх
// String sql = "SELECT * FROM users WHERE name='" + name + "'";

// ЗӨВ: PreparedStatement + parameter binding (13-р бүлэг)
```

```java
// Bad: Path.of(base, untrustedFileName)-ийг шууд унших.
// Better: зөвшөөрөгдсөн нэр, base directory restriction,
// canonicalization, symbolic-link policy-г тус тусад нь хэрэгжүүлэх.
```

**Project J1 — Student Grade Manager (Beginner):** console input, `List<Student>`, grade rules, average, validation, `Scanner` ашиглана. Сөрөг оноо эсвэл 100-аас их оноог буцаана. `record Student(String name, int score)` + validation туршаад үз.

**Project J2 — Asset Inventory CLI (Intermediate):** `Map<String,Asset>`, search, add, remove, CSV export, exception handling; JUnit tests (8+), Maven build. Демо өгөгдөл л хэрэглэнэ.

**Project J3 — Offline Source Code Review Assistant (Advanced):** Java source-оос `Runtime.getRuntime().exec`, `Statement.execute`, `ObjectInputStream`, `Files.readString` зэрэг *эрсдэлийн pattern*-ийг хайж output гаргана; энэ нь **heuristic** төдий. AST эсвэл CodeQL/Semgrep мэт semantic analysis-тай харьцуул; false-positive/false-negative 3 жишээ гарга. Тухайн кодыг ажиллуулах, exploit хийх шаардлагагүй.

**Сайн инженерийн шалгуур:**
- Modular design, clear types, encapsulation, tests, meaningful errors, README.
- `mvn test` ажилладаг, build reproducible, dependencies удирдлагатай.
- SQL parameterization, input validation, secrets handling, no sensitive logs.
- Time/space complexity ба thread safety-д тайлбар өгч чаддаг.
- Review дээр таамгийг *confirmed vulnerability* гэж дүгнэдэггүй.

### Java self-assessment

| Түвшин | Чадварын шалгуур |
|---|---|
| Beginner | Class, variables, `if`, loop, arrays, methods ашиглан энгийн console програм бие даан бичдэг |
| Intermediate | OOP, interfaces, collections, exceptions, files, JUnit/Maven ашиглан төсөл хөгжүүлдэг |
| Advanced-oriented | Generics/Streams, concurrency tradeoffs, JVM diagnostics, clean architecture, secure coding, unit/integration tests-г тайлбарлаж хэрэглэдэг |

### Java албан эх сурвалж
- Modern Java learning — https://dev.java/learn/
- Your first Java application — https://dev.java/learn/first-steps/
- JDK APIs — https://docs.oracle.com/en/java/javase/25/docs/api/
- Java secure coding guidelines — https://www.oracle.com/java/technologies/javase/seccodeguide.html
- Maven introduction — https://maven.apache.org/guides/getting-started/
- JUnit user guide — https://docs.junit.org/current/user-guide/

> **Төгсгөл:** Java дээр Advanced болох нь framework нэрс цээжлэх биш. Зохион байгуулалттай application бүтээх, bug оношлох, тестээр баталгаажуулах, гүйцэтгэл хэмжих, аюулгүй код бичих чадвар юм.
