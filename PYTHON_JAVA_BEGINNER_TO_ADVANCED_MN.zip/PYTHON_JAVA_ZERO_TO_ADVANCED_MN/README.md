# Python + Java — Zero to Advanced-oriented (MN)

**Хэн ашиглах вэ?** Код бичиж үзээгүй Beginner → Intermediate → Advanced-ийн суурь, дадлага эзэмших хүсэлтэй суралцагч.

**Хичээлийн онцлог:** Монгол тайлбар; English syntax/commands; 30 тусдаа модуль; 30 solved practice + 30 independent challenge; 32 долоо хоногийн хөтөлбөр; хоёр offline source-code project; үнэлгээний шалгуур.

> **Localhost lab ороогүй.** Web server, Docker, vulnerable VM шаардлагагүй. Terminal, code editor, Python, JDK л байхад энгийн материалуудаа судалж болно. Maven/JUnit-ийн нэмэлт хэсэгт тусгай dependency татах шаардлага гарч магадгүй.

## Эхлэх дараалал

1. [`00_START_HERE_32_WEEK_ROADMAP_MN.md`](00_START_HERE_32_WEEK_ROADMAP_MN.md) — сурах хуваарь, зорилт, шат ахих шалгуур.
2. [`PYTHON_COMPLETE_GUIDE_MN.md`](PYTHON_COMPLETE_GUIDE_MN.md) — Python 01–15.
3. [`JAVA_COMPLETE_GUIDE_MN.md`](JAVA_COMPLETE_GUIDE_MN.md) — Java 01–15.
4. [`WORKBOOK_EXERCISES_SOLUTIONS_MN.md`](WORKBOOK_EXERCISES_SOLUTIONS_MN.md) — 30 шийдсэн жишээ + 30 өөрөө хийх бодлого.
5. [`PROJECTS_STEP_BY_STEP_MN.md`](PROJECTS_STEP_BY_STEP_MN.md) — Python/Java хоёр project + тест.
6. [`SYNTAX_COMPARISON_CHEATSHEET_MN.md`](SYNTAX_COMPARISON_CHEATSHEET_MN.md) — 2 хэлний команд ба онцлогийн харьцуулалт.

## Python — 15 тусдаа Markdown module

01. [`01_First_Steps_Install_Hello`](PYTHON/01_First_Steps_Install_Hello.md)
02. [`02_Variable_type_operator`](PYTHON/02_Variable_type_operator.md)
03. [`03_Conditions_And_Loops`](PYTHON/03_Conditions_And_Loops.md)
04. [`04_list_tuple_dict_set`](PYTHON/04_list_tuple_dict_set.md)
05. [`05_Function_scope`](PYTHON/05_Function_scope.md)
06. [`06_File_I_O_JSON_CSV_exception`](PYTHON/06_File_I_O_JSON_CSV_exception.md)
07. [`07_Module_package_venv_pip_CLI`](PYTHON/07_Module_package_venv_pip_CLI.md)
08. [`08_Object_Oriented_Programming_OOP`](PYTHON/08_Object_Oriented_Programming_OOP.md)
09. [`09_Iterable_iterator_generator`](PYTHON/09_Iterable_iterator_generator.md)
10. [`10_Decorator_context_manager_type_hints`](PYTHON/10_Decorator_context_manager_type_hints.md)
11. [`11_Testing_logging_debugging`](PYTHON/11_Testing_logging_debugging.md)
12. [`12_Algorithms_complexity`](PYTHON/12_Algorithms_complexity.md)
13. [`13_Concurrency_Thread_Process_asyncio`](PYTHON/13_Concurrency_Thread_Process_asyncio.md)
14. [`14_Production_quality_Python_secure_coding`](PYTHON/14_Production_quality_Python_secure_coding.md)
15. [`15_Python_capstone_projects_Beginner_Advanced`](PYTHON/15_Python_capstone_projects_Beginner_Advanced.md)

## Java — 15 тусдаа Markdown module

01. [`01_Java_JDK_JVM`](JAVA/01_Java_JDK_JVM.md)
02. [`02_Primitive_types_reference_String`](JAVA/02_Primitive_types_reference_String.md)
03. [`03_if_switch_for_while_arrays`](JAVA/03_if_switch_for_while_arrays.md)
04. [`04_Methods_parameters_return_recursion`](JAVA/04_Methods_parameters_return_recursion.md)
05. [`05_OOP_class_encapsulation_constructor`](JAVA/05_OOP_class_encapsulation_constructor.md)
06. [`06_Inheritance_interface_polymorphism_record_enum`](JAVA/06_Inheritance_interface_polymorphism_record_enum.md)
07. [`07_Exception_resource_management`](JAVA/07_Exception_resource_management.md)
08. [`08_Collections_Generics_Optional`](JAVA/08_Collections_Generics_Optional.md)
09. [`09_Lambda_Streams_functional_style`](JAVA/09_Lambda_Streams_functional_style.md)
10. [`10_File_I_O_NIO_date_time`](JAVA/10_File_I_O_NIO_date_time.md)
11. [`11_Build_tools_Maven_JUnit_testing`](JAVA/11_Build_tools_Maven_JUnit_testing.md)
12. [`12_Concurrency_Thread_synchronization_virtual_threa`](JAVA/12_Concurrency_Thread_synchronization_virtual_threa.md)
13. [`13_JDBC_SQL_transaction`](JAVA/13_JDBC_SQL_transaction.md)
14. [`14_JVM_memory_Garbage_Collection_performance`](JAVA/14_JVM_memory_Garbage_Collection_performance.md)
15. [`15_Secure_Coding_Source_Code_Review_capstone`](JAVA/15_Secure_Coding_Source_Code_Review_capstone.md)

## Offline executable project sources

- [`EXAMPLES/python_expense_tracker.py`](EXAMPLES/python_expense_tracker.py) — Python CSV expense CLI.
- [`EXAMPLES/test_python_expense_tracker.py`](EXAMPLES/test_python_expense_tracker.py) — Python 4 automated tests.
- [`EXAMPLES/JavaInventory.java`](EXAMPLES/JavaInventory.java) — Java inventory CLI.
- [`EXAMPLES/JavaInventoryTest.java`](EXAMPLES/JavaInventoryTest.java) — Java basic self-check.

**Шалгасан:** Python fenced code-ийн syntax (46 хэсэг), JDK 21 дээр Java-ийн standalone 28 class compilation, Python project 4 test OK, Java project self-check PASS. Java-ийн Maven/JUnit жишээ нь нэмэлт dependency шаарддаг тул compile шалгалтаас тусад нь авч үзнэ. `QUALITY_CHECK.json`-д статик шалгалтын дүн бий.

## Нэг чухал ялгаа

**Beginner** = syntax болон core control flow-г ашигладаг. **Intermediate** = модуль/тест/алдаа боловсруулах/проект байгуулах чадвартай. **Advanced-oriented** = performance, concurrency, secure coding, code review, архитектурын сонголтыг тайлбарлаж чаддаг. Гэхдээ бодит Advanced инженер болно гэдэг нь олон сарын production experience, code review, maintenance-тэй хамт хөгждөг.

## Албан эх сурвалж

- Python: https://docs.python.org/3/tutorial/
- Python Packaging: https://packaging.python.org/
- Java: https://dev.java/learn/
- JDK 25 API: https://docs.oracle.com/en/java/javase/25/docs/api/
- Maven: https://maven.apache.org/guides/getting-started/
- JUnit: https://docs.junit.org/current/user-guide/

**Хувилбар:** Python 3.13+ жишээ; Java JDK 21+ синтакс (суралцахад JDK 25 LTS санал болгоно). Шинэ version гарвал toolchain болон dependency compatibility-г дахин шалга.
