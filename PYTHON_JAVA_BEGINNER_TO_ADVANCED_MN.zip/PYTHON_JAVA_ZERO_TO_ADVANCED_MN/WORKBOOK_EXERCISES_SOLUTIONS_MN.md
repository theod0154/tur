# Python + Java Practical Workbook — 30 бодсон жишээ + 30 бие даалт

**Яаж ашиглах вэ?** `Problem`-ийг уншаад кодыг **харахгүйгээр** 15–30 минут бод. Дараа нь `Reference solution`-той харьцуул. Гаралт тогтмол эсэх, edge case, error path-ийг шалга. Хамгийн чухал нь *яагаад* ингэж бичсэнээ үгээр тайлбарлаж чаддаг байх. **Бүх жишээ offline/console.**

---
# Part A — Python 15 solved problems

## P01 — Hello / variable
**Problem:** Хэрэглэгчийн нэр ба дуртай хэлээр мэндчилгээ үүсгэдэг `greet()` функц бич. **Expected:** `Sain uu, Anu. Python surahad belen uu?`

```python
def greet(name: str, language: str) -> str:
    return f"Sain uu, {name}. {language} surahad belen uu?"

print(greet("Anu", "Python"))
```

**Тайлбар:** `return` функцийн утгыг буцаана; `print` зөвхөн дэлгэцэнд гаргана. **Challenge:** Хоосон нэрийн үед `ValueError` гарга.

## P02 — Decimal мөнгөн тооцоо
**Problem:** 15%-ийн хөнгөлөлттэй 200000₮-ийн үнийг гарга. **Expected:** `170000.00`

```python
from decimal import Decimal
price = Decimal("200000")
rate = Decimal("0.15")
result = price * (1 - rate)
print(f"{result:.2f}")
```

**Тайлбар:** `Decimal("0.15")` string-ээр дамжуулснаар binary float precision алдаа оруулахгүй. **Challenge:** Сөрөг price болон 0–1-ээс гаднах rate-г reject хий.

## P03 — Loop / нөхцөл
**Problem:** 1–10 хүртэлх тэгш тооны нийлбэр. **Expected:** `30`

```python
total = 0
for n in range(1, 11):
    if n % 2 == 0:
        total += n
print(total)
```

**Challenge:** Нэг `sum(...)` + generator ашигла. **Алдаа:** `range(1, 10)` нь 10-ыг оруулахгүй.

## P04 — Dictionary frequency count
**Problem:** `web db web api db web` доторх үгсийг тоол. **Expected:** `{'web': 3, 'db': 2, 'api': 1}`

```python
words = "web db web api db web".split()
counts: dict[str, int] = {}
for word in words:
    counts[word] = counts.get(word, 0) + 1
print(counts)
```

**Challenge:** `collections.Counter`-аар 1 мөр болгож бич. **Алдаа:** `dict[word]` гэдэг нь key байхгүй бол `KeyError`.

## P05 — Function / prime checker
**Problem:** `is_prime(7)→True`, `is_prime(9)→False`, `is_prime(1)→False`.

```python
def is_prime(n: int) -> bool:
    if n < 2:
        return False
    divisor = 2
    while divisor * divisor <= n:
        if n % divisor == 0:
            return False
        divisor += 1
    return True

print([is_prime(n) for n in (1, 7, 9)])  # [False, True, False]
```

**Тайлбар:** `sqrt(n)`-ээс их divisor шалгах шаардлагагүй (хуваагчдын нэг нь заавал жижиг байдаг). **Challenge:** 100 хүртэл анхны тоонууд.

## P06 — CSV parse & filter
**Problem:** CSV text-ээс `down` host-уудыг list болго. **Expected:** `['db01']`

```python
import csv
from io import StringIO
source = StringIO("host,status\nweb01,up\ndb01,down\n")
rows = list(csv.DictReader(source))
down = [row["host"] for row in rows if row["status"] == "down"]
print(down)
```

**Challenge:** `status` column байхгүй үед user-friendly exception гарга. **Алдаа:** CSV-г зүгээр `split(',')` хийх нь quoted comma-г буруу боловсруулна.

## P07 — Module & command-line args
**Problem:** `python sum_cli.py 2 3 4` → `9.0`.

```python
# sum_cli.py
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("numbers", nargs="+", type=float)
args = parser.parse_args()
print(sum(args.numbers))
```

**Challenge:** `--round 2` optional integer flag нэм. **Алдаа:** `parse_args()`-г REPL-д аргументгүй турших үед алдаа гарч болно — файл хэлбэрээр ажиллуул.

## P08 — OOP & validation
**Problem:** Stock хасахдаа 0-ээс доош үлдэгдэл гаргахгүй.

```python
class Inventory:
    def __init__(self, quantity: int):
        if quantity < 0:
            raise ValueError("negative quantity")
        self._quantity = quantity

    def remove(self, qty: int) -> None:
        if qty <= 0 or qty > self._quantity:
            raise ValueError("invalid qty")
        self._quantity -= qty

    @property
    def quantity(self) -> int:
        return self._quantity

item = Inventory(5)
item.remove(2)
print(item.quantity)  # 3
```

**Challenge:** `add`, `rename`, `snapshot` нэм. **Алдаа:** `@property` бол магадлан баталгаажуулалт хийхгүй — `remove` өөрөө guard-тай байна.

## P09 — Generator
**Problem:** 0–N доторх тэгш тоог lazy generate хий. **Expected:** `[0, 2, 4]`

```python
def evens_below(n: int):
    for x in range(n):
        if x % 2 == 0:
            yield x

print(list(evens_below(5)))
```

**Challenge:** 100 сая тоонд generator яагаад list-ээс илүү memory-efficient болохыг тайлбарла.

## P10 — Decorator
**Problem:** Функц дуудагдах үед нэрийг нь хэвлэдэг decorator.

```python
from functools import wraps

def trace(fn):
    @wraps(fn)
    def inner(*args, **kwargs):
        print("calling", fn.__name__)
        return fn(*args, **kwargs)
    return inner

@trace
def square(n): return n * n

print(square(4))
# calling square
# 16
```

**Challenge:** Exception гарсан ч function нэрийг audit log-д үлдээх, гэхдээ argument-ын secret хэвлэхгүй.

## P11 — `unittest`
**Problem:** `is_prime()`-ийн edge case test.

```python
# test_prime.py (P05-ыг prime.py файлд хадгалсан гэж үзэв)
import unittest
from prime import is_prime

class PrimeTests(unittest.TestCase):
    def test_one(self): self.assertFalse(is_prime(1))
    def test_seven(self): self.assertTrue(is_prime(7))
    def test_nine(self): self.assertFalse(is_prime(9))

if __name__ == "__main__":
    unittest.main()
```

`python -m unittest discover -v` → `Ran 3 tests ... OK`. **Challenge:** `0`, `-3`, `2`, `100` тест нэм. **Алдаа:** `prime.py` байхгүй бол `ModuleNotFoundError`; `is_prime`-ийг P05-оос хуулж тусдаа файлд хадгал.

## P12 — Algorithm & Counter
**Problem:** Үгийн давтамжийг хамгийн ихээс бага руу гарга. **Expected:** `[('web', 3), ('db', 2), ('api', 1)]`

```python
from collections import Counter
counts = Counter("web db web api db web".split())
print(counts.most_common())
```

**Challenge:** 10 сая мөртэй файлыг `.read().split()` биш streaming-ээр тоол.

## P13 — `asyncio`
**Problem:** Хоёр ажил нэгэн зэрэг I/O хүлээж буйг simulation хий.

```python
import asyncio

async def task(name: str) -> str:
    await asyncio.sleep(0.01)
    return name + " done"

async def main():
    print(await asyncio.gather(task("A"), task("B")))

asyncio.run(main())
# ['A done', 'B done']
```

**Challenge:** Нэг ажил exception гаргавал бусад ажлын behavior ямар байхыг судал; cancellation concept-г тайлбарла.

## P14 — SQL parameterization
**Problem:** SQL injection эрсдэлгүйгээр value bind хийх (in-memory SQLite).

```python
import sqlite3
with sqlite3.connect(":memory:") as db:
    db.execute("CREATE TABLE hosts(name TEXT)")
    db.execute("INSERT INTO hosts VALUES(?)", ("web01",))
    rows = db.execute("SELECT name FROM hosts WHERE name=?", ("web01",)).fetchall()
    print(rows)  # [('web01',)]
```

**Challenge:** Dynamic sort field шаардлагатай бол зөвшөөрөгдсөн `name` / `created_at` гэх мэт field name-ийг allowlist-аар сонгох pseudocode бич.

## P15 — Static code review concept
**Problem:** Python-ийн `ast`-ээр файлд `eval()` дуудлага байгаа эсэхийг **сэжиг** болгон тэмдэглэх. **Expected:** `[(1, 'eval usage requires review')]`.

```python
import ast
source = 'eval("2+2")\n'
tree = ast.parse(source)
findings = []
for node in ast.walk(tree):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
        if node.func.id == "eval":
            findings.append((node.lineno, "eval usage requires review"))
print(findings)
```

**Анхаар:** Энэ бол *pattern detection*; vulnerability баталгаажуулахгүй. `eval` зөвхөн trusted constants дээр байх боломжтой. **Challenge:** `ast.Attribute` call path-ийг ялгаж сурах; false positive жишээ гаргах.

---
# Part B — Java 15 solved problems

> Java-ийн бүрэн `public class` жишээнүүдийг class нэртэй ижил `.java` файлд хадгална. Бусад хэсэгчилсэн snippet-үүдийг `main` эсвэл тохирох class-д оруулна. `javac FileName.java && java FileName` (PowerShell/bash-д `&&` ашиглах боломж нь shell хувилбараас хамаарна).

## J01 — First class
**Problem:** 2 тооны нийлбэр хэвлэ. **Expected:** `5`

```java
public class J01 {
    public static void main(String[] args) {
        int a = 2, b = 3;
        System.out.println(a + b);
    }
}
```

**Challenge:** `String` мэндчилгээ нэм. **Алдаа:** `public class J01` файлын нэр `J01.java` байх ёстой.

## J02 — String equality
**Problem:** Text equality-г зөв шалга. **Expected:** `true`

```java
public class J02 {
    public static void main(String[] args) {
        String a = new String("admin");
        String b = new String("admin");
        System.out.println(a.equals(b));
    }
}
```

**Challenge:** `a == b` яагаад `false` болохыг тайлбарла.

## J03 — Array & loop
**Problem:** `{2,4,6,8}`-ийн нийлбэр. **Expected:** `20`

```java
public class J03 {
    public static void main(String[] args) {
        int[] values = {2, 4, 6, 8};
        int sum = 0;
        for (int value : values) sum += value;
        System.out.println(sum);
    }
}
```

**Challenge:** Average тооцохдоо integer division-оос сэргийл.

## J04 — Method & recursion
**Problem:** `factorial(5)` → `120`.

```java
public class J04 {
    static int factorial(int n) {
        if (n < 0) throw new IllegalArgumentException();
        if (n <= 1) return 1;
        return Math.multiplyExact(n, factorial(n - 1));
    }
    public static void main(String[] args) {
        System.out.println(factorial(5));
    }
}
```

**Challenge:** `factorial(13)` дээр `int` overflow яагаад үүсэхийг тайлбарла.

## J05 — Class & encapsulation
**Problem:** `Inventory` үлдэгдэл сөрөг болох ёсгүй.

```java
public class J05 {
    static class Inventory {
        private int qty;
        Inventory(int qty) {
            if (qty < 0) throw new IllegalArgumentException();
            this.qty = qty;
        }
        void remove(int amount) {
            if (amount <= 0 || amount > qty) throw new IllegalArgumentException();
            qty -= amount;
        }
        int getQty() { return qty; }
    }
    public static void main(String[] args) {
        Inventory i = new Inventory(5);
        i.remove(2);
        System.out.println(i.getQty()); // 3
    }
}
```

**Challenge:** `add` method, overflow protection нэм.

## J06 — Interface & polymorphism
**Problem:** Interface-ийн implementation-ийг class-аар сольж болохоор зохион байгуул.

```java
public class J06 {
    interface Printer { void print(String text); }
    static class ConsolePrinter implements Printer {
        public void print(String text) { System.out.println(text); }
    }
    public static void main(String[] args) {
        Printer p = new ConsolePrinter();
        p.print("ready");  // ready
    }
}
```

**Challenge:** `UpperPrinter` гэсэн шинэ implementation хий.

## J07 — Exception handling
**Problem:** Буруу string тоо биш гэдгийг тань. **Expected:** `invalid number`

```java
public class J07 {
    public static void main(String[] args) {
        try {
            System.out.println(Integer.parseInt("abc"));
        } catch (NumberFormatException ex) {
            System.out.println("invalid number");
        }
    }
}
```

**Challenge:** Exception class, message-г ялгаж тайлбарла.

## J08 — Map counting
**Problem:** `web db web` дотор давтамж. **Expected:** `2`

```java
import java.util.Map;
import java.util.HashMap;

public class J08 {
    public static void main(String[] args) {
        Map<String, Integer> count = new HashMap<>();
        for (String s : new String[]{"web", "db", "web"}) {
            count.merge(s, 1, Integer::sum);
        }
        System.out.println(count.get("web"));
    }
}
```

**Challenge:** Key байхгүй үед `getOrDefault` ашигла.

## J09 — Stream filter
**Problem:** Тэгш тооны квадратыг list болго. **Expected:** `[4, 16]`

```java
import java.util.List;

public class J09 {
    public static void main(String[] args) {
        List<Integer> data = List.of(1, 2, 3, 4, 5);
        System.out.println(data.stream().filter(x -> x % 2 == 0)
                .map(x -> x * x).toList());
    }
}
```

**Challenge:** Loop хувилбарыг бич.

## J10 — Date/time
**Problem:** `2026-11-20`-оос 7 хоногийн дараа. **Expected:** `2026-11-27`

```java
import java.time.LocalDate;

public class J10 {
    public static void main(String[] args) {
        System.out.println(LocalDate.of(2026, 11, 20).plusDays(7));
    }
}
```

**Challenge:** `Instant` ба `LocalDateTime` ялгааг тайлбарла.

## J11 — Basic automated checks
**Problem:** 2 тооны нийлбэрийн expected value-г шалга. **Expected:** `PASS`

```java
public class J11 {
    static int add(int a, int b) { return Math.addExact(a, b); }
    public static void main(String[] args) {
        if (add(2, 3) != 5) throw new AssertionError("expected 5");
        System.out.println("PASS");
    }
}
```

**Тайлбар:** Энэ бол JUnit биш, богино self-check. Мэргэжлийн төсөл дээр **JUnit** болон `mvn test` хэрэглэх. **Challenge:** Overflow exception-г test хий.

## J12 — Virtual Threads
**Problem:** Executor ашиглан 2 task-ийн үр дүнг нэм. **Expected:** `42`

```java
import java.util.concurrent.*;

public class J12 {
    public static void main(String[] args) throws Exception {
        try (ExecutorService pool = Executors.newVirtualThreadPerTaskExecutor()) {
            Future<Integer> a = pool.submit(() -> 20);
            Future<Integer> b = pool.submit(() -> 22);
            System.out.println(a.get() + b.get());
        }
    }
}
```

**Challenge:** `Future.get()` exception-тэй яаж ажилладаг вэ? Thread-safe counter хийнэ.

## J13 — SQL: Safe query concept
**Problem:** User-controlled string-г SQL syntax-тай нийлүүлэхгүй. **Expected:** `PreparedStatement` value binding.

```java
// JDBC Connection conn-г application-аас өгсөн гэж үзнэ.
String sql = "SELECT status FROM assets WHERE hostname = ?";
try (java.sql.PreparedStatement ps = conn.prepareStatement(sql)) {
    ps.setString(1, hostname);
    try (java.sql.ResultSet rs = ps.executeQuery()) {
        // rs.next() шалгасны дараа result уншина.
    }
}
```

**Тайлбар:** Энэ нь **code-review snippet**, дангаараа compile/run хийх зориулалтгүй; DB server шаардлагагүй. **Challenge:** Dynamic `ORDER BY` column-ийг parameter binding биш allowlist-аар хэрхэн зохицуулахыг тайлбарла.

## J14 — JVM options
**Problem:** Java heap хэмжээг хязгаарлаж console app ажиллуулах.

```bash
javac J01.java
java -Xmx256m J01
```

**Expected:** `5` — normal program-ийн output өөрчлөгдөхгүй. `-Xmx256m`: heap max ойролцоогоор 256 MiB. **Challenge:** Яагаад GC болон profiler-ийн үр дүнгээр performance claim баталгаажуулах хэрэгтэй вэ?

## J15 — Security review
**Problem:** Дараах кодыг security review хийхдээ эрсдэлийг нэрлэ.

```java
// Bad pattern; DO NOT use in production
// String sql = "SELECT * FROM users WHERE name='" + name + "'";
// String token = "hard-coded-secret";
// log.info("Authorization: {}", token);
```

**Expected:** String-built SQL → injection risk; hard-coded secret → key exposure; bearer token logging → sensitive disclosure. **Challenge:** PreparedStatement, runtime secrets, redaction гэсэн 3 remediation бич. Бодит vulnerability-г баталгаажуулахгүйгээр зөвхөн risk pattern гэж тайлагна.

---
# Part C — 30 independent challenges (хариу харахгүй бие дааж хийнэ)

| # | Python бодлого | Java бодлого | Амжилтын шалгуур |
|---:|---|---|---|
| 01 | `input` validation | `Scanner` validation | Алдаатай input reject |
| 02 | VAT + Decimal | `BigDecimal` invoice | Decimal precision |
| 03 | Prime numbers 1–100 | Prime numbers 1–100 | 25 prime |
| 04 | Dictionary word count | `Map` word count | Давтамж зөв |
| 05 | Sorting/tuples | `Comparator` sorting | Гаралт тогтвортой |
| 06 | CSV filter | File line filter | Empty file handling |
| 07 | CLI args | `main(String[] args)` | `--help`/usage |
| 08 | Inventory class | Inventory class | Negative stock reject |
| 09 | Lazy generator | `Stream.iterate` | No unnecessary full allocation |
| 10 | Audit decorator | Decorator pattern | No secret logging |
| 11 | `unittest` edge cases | JUnit edge cases | 8 tests each |
| 12 | Big-O explanation | Big-O explanation | O(n) vs O(n²) |
| 13 | `asyncio` I/O simulate | Virtual thread simulation | Deterministic result |
| 14 | Parameterized SQLite | PreparedStatement review | No string-built SQL |
| 15 | AST-based risk report | Static code pattern review | False positives identified |

> Дээрх хүснэгтийн мөр бүрт **Python нэг, Java нэг** тусдаа бодлого байгаа. Нийт 30 бие даалт. Хуучин материалын кодыг шууд хуулалгүй өөрийн шийдлийг эхлээд бүтээ.

## Суралцах үнэлгээний rubric (бодлого бүр 10 оноо)
- Correct output: **3** оноо
- Edge cases & invalid input: **2** оноо
- Clear names, clean structure: **2** оноо
- Error handling + security hygiene: **1** оноо
- Automated tests: **2** оноо

**8–10:** сайн эзэмшсэн. **6–7:** давт. **0–5:** ижил сэдвийн хялбар дасгалыг дахин ажилла. Тест огтгүй бол 8/10-аас дээш авахгүй.

## Асуултаа шалгах 7 алхам
1. Код яг юу хийх ёстойг нэг өгүүлбэрээр бич.
2. Input ба output-ийг тодорхойл.
3. Нэг энгийн жишээг гараар бод.
4. Empty, negative, malformed input-ийг тооц.
5. Кодоо бич, compile/run хий.
6. Automatic test бичээд нэг bug санаатай оруулж test-ээр илрүүл.
7. Дараа нь цэвэр код болон performance/security tradeoff-оо тайлбарла.
