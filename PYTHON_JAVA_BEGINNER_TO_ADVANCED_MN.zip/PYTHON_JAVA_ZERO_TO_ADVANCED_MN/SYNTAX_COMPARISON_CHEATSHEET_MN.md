# Python ↔ Java: Харьцуулсан Quick Cheat Sheet

**Ашиглах:** Нэг ижил асуудал Python ба Java дээр яаж бичигддэгийг харах. Кодыг сэтгэлгээний загварын түвшинд ойлго; syntax цээжлэхээс илүү *ямар type, data structure, control flow сонгох* гэдгийг бод.

| Ойлголт | Python | Java |
|---|---|---|
| Main entry | `if __name__ == "__main__": ...` (сонголттой) | `public static void main(String[] args)` |
| String | `name = "Anu"` | `String name = "Anu";` |
| Integer | `n = 10` | `int n = 10;` |
| Boolean | `True`, `False` | `true`, `false` |
| Missing value | `None` | `null`, заримдаа `Optional<T>` |
| Equality | `==` value, `is` identity | `.equals()` value for objects, `==` primitives/reference |
| Output | `print(x)` | `System.out.println(x);` |
| Condition | `if condition:` | `if (condition) { ... }` |
| Loop count | `for i in range(5):` | `for (int i=0; i<5; i++) {}` |
| Loop iterable | `for x in items:` | `for (var x : items) {}` |
| Function | `def add(a,b): return a+b` | `static int add(int a,int b){return a+b;}` |
| Array-like | `list` | `List<T>` / array `T[]` |
| Dictionary | `dict[str,int]` | `Map<String,Integer>` |
| Unique values | `set` | `Set<T>` |
| No return | implicit `None` | `void` |
| Exceptions | `try/except/finally` | `try/catch/finally` |
| File path | `pathlib.Path` | `java.nio.file.Path` |
| Unit test | `unittest`/`pytest` | JUnit |
| Dependency | `pip`, `pyproject.toml` | Maven/Gradle |
| Concurrency | `asyncio`, thread/process | `ExecutorService`, virtual threads |

## 1. List-д тэгш тоо шүүх

**Python**

```python
numbers = [1, 2, 3, 4]
result = [n for n in numbers if n % 2 == 0]
print(result)  # [2, 4]
```

**Java**

```java
import java.util.List;
public class EvenDemo {
    public static void main(String[] args) {
        List<Integer> numbers = List.of(1, 2, 3, 4);
        System.out.println(numbers.stream().filter(n -> n % 2 == 0).toList());
        // [2, 4]
    }
}
```

## 2. Input validation

**Python**

```python
def require_positive(n: int) -> int:
    if n <= 0:
        raise ValueError("must be positive")
    return n
```

**Java**

```java
static int requirePositive(int n) {
    if (n <= 0) throw new IllegalArgumentException("must be positive");
    return n;
}
// Энэ method-ийг class дотор байрлуулна.
```

## 3. CSV/JSON ба SQL — security

| Зорилт | Python | Java |
|---|---|---|
| Safe SQL value | `cursor.execute("... WHERE id=?", (id,))` | `PreparedStatement.setLong(1, id)` |
| CSV | `csv.DictReader` | Standard library `Files.lines` + parser/library |
| JSON | `json.loads()` | Approved Jackson/Gson зэрэг library (standard JDK-д general-purpose JSON mapper байхгүй) |
| Secret | `os.getenv()` | `System.getenv()` |
| CLI | `argparse` | `args[]` / approved CLI library |
| File reads | `Path.read_text()` | `Files.readString(Path.of(...))` |
| Dataclass/data carrier | `@dataclass` | `record` |

## 4. Type ба null/error

- Python `int` нь arbitrary precision (боломжит санах ойн хүрээнд); Java `int` нь fixed 32-bit signed integer.
- Python `list` нь олон type холимог хадгалж чадна; Java `List<T>` нь type parameter ашигладаг.
- Python `dict` insertion order хадгалдаг; Java `HashMap` iteration order нь баталгаагүй.
- Python `float` болон Java `double` хоёулаа binary floating point; санхүүгийн нарийн тооцоонд Python `Decimal`, Java `BigDecimal`.
- Python `None`-ийг `is None` гэж шалга; Java объектын `null`-ийг `== null` гэж шалга.
- Java checked exceptions (жишээ нь `IOException`) нь compile-time control flow-д нөлөөлнө; Python-д checked exception механизм байхгүй.

## 5. Хамгийн түгээмэл алдаа

| Python error | Шалтгаан | Java error | Шалтгаан |
|---|---|---|---|
| `SyntaxError` | Syntax буруу | `';' expected` | `;` эсвэл syntax дутуу |
| `IndentationError` | Мөрийн эхний зай зөрүүтэй | `cannot find symbol` | Хувьсагч/type/method мэдэгдэхгүй |
| `NameError` | Тодорхойлоогүй нэр | `NullPointerException` | `null` object method дуудах |
| `TypeError` | Type тохироогүй | `ClassCastException` | Буруу cast |
| `ValueError` | Утга буруу | `NumberFormatException` | Text→number parse алдаа |
| `KeyError` | `dict` key байхгүй | `NoSuchElementException` | Хоосон Optional/iterator |
| `IndexError` | List index хүрээнээс гарсан | `ArrayIndexOutOfBoundsException` | Array index хүрээнээс гарсан |

## 6. Сурах үед байнга асуух 8 асуулт

1. Энэ код ямар input авдаг вэ?
2. Output нь юу байх ёстой вэ?
3. Хамгийн бага/их/хоосон input-ыг тооцсон уу?
4. Үүнийг function/method-д ялгаж болох уу?
5. List, set, map аль нь илүү тохирох вэ?
6. Алдаатай input-д ямар exception гардаг вэ?
7. Тест амжилттай, зориудаар алдаа оруулахад унаж чадаж байна уу?
8. Хэрэглэгчийн өгөгдөл SQL, path, shell, log-д аюулгүй дамжиж байна уу?

## 7. Давтах mini challenge

`assets = [{"host":"web01","status":"up"},{"host":"db01","status":"down"}]` гэсэн өгөгдлөөс `status == "down"` хостуудыг **Python list comprehension** болон **Java Stream** хэлбэрээр хоёуланг нь бич. Empty list, missing status, duplicated host гэсэн 3 нөхцөлийн behavior тодорхойл.
