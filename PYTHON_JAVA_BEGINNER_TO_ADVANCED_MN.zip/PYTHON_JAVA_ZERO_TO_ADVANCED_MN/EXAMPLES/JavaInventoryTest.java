/** Offline self-check. For serious projects, learn JUnit in Java module 11. */
public class JavaInventoryTest {
    private static void expect(boolean condition) {
        if (!condition) throw new AssertionError("Check failed");
    }

    public static void main(String[] args) {
        JavaInventory.Inventory inventory = new JavaInventory.Inventory();
        inventory.add("web01", 5);
        expect(inventory.get("web01") == 5);
        inventory.remove("web01", 2);
        expect(inventory.get("web01") == 3);
        try {
            inventory.remove("web01", 4);
            throw new AssertionError("Expected invalid stock check");
        } catch (IllegalArgumentException expected) {
            expect(inventory.get("web01") == 3);
        }
        System.out.println("PASS");
    }
}
