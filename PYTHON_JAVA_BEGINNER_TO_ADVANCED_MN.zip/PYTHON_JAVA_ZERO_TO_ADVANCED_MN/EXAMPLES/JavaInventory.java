import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

/** Offline interactive inventory CLI for language practice. */
public class JavaInventory {
    static final class Inventory {
        private final Map<String, Integer> stock = new TreeMap<>();

        void add(String host, int amount) {
            validate(host, amount);
            stock.put(host, Math.addExact(stock.getOrDefault(host, 0), amount));
        }

        void remove(String host, int amount) {
            validate(host, amount);
            int remaining = stock.getOrDefault(host, 0) - amount;
            if (remaining < 0) throw new IllegalArgumentException("Not enough stock");
            if (remaining == 0) stock.remove(host);
            else stock.put(host, remaining);
        }

        int get(String host) { return stock.getOrDefault(host, 0); }
        Map<String, Integer> snapshot() { return Map.copyOf(stock); }

        private static void validate(String host, int amount) {
            if (host == null || !host.matches("[A-Za-z0-9][A-Za-z0-9.-]{0,62}")) {
                throw new IllegalArgumentException("Invalid host name");
            }
            if (amount <= 0) throw new IllegalArgumentException("Amount must be positive");
        }
    }

    public static void main(String[] args) {
        Inventory inventory = new Inventory();
        System.out.println("Commands: add HOST N | remove HOST N | list | quit");
        try (Scanner scanner = new Scanner(System.in)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.equals("quit")) break;
                String[] parts = line.split("\\s+");
                try {
                    if (parts.length == 1 && parts[0].equals("list")) {
                        inventory.snapshot().entrySet().stream()
                                .sorted(Map.Entry.comparingByKey())
                                .forEach(e -> System.out.println(e.getKey() + " " + e.getValue()));
                    } else if (parts.length == 3 &&
                            (parts[0].equals("add") || parts[0].equals("remove"))) {
                        int amount = Integer.parseInt(parts[2]);
                        if (parts[0].equals("add")) inventory.add(parts[1], amount);
                        else inventory.remove(parts[1], amount);
                        System.out.println("OK");
                    } else {
                        System.out.println("Usage: add HOST N | remove HOST N | list | quit");
                    }
                } catch (IllegalArgumentException | ArithmeticException ex) {
                    System.out.println("Error: " + ex.getMessage());
                }
            }
        }
    }
}
