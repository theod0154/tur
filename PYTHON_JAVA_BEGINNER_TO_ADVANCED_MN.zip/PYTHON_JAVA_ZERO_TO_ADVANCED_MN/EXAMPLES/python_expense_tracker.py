"""Offline beginner-to-intermediate CLI expense tracker; educational example."""
from __future__ import annotations

import argparse
import csv
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

FIELDS = ("date", "category", "amount")
CENT = Decimal("0.01")


def parse_amount(raw: str) -> Decimal:
    try:
        value = Decimal(raw)
    except InvalidOperation as exc:
        raise ValueError("Amount must be a decimal number") from exc
    if not value.is_finite() or value <= 0:
        raise ValueError("Amount must be finite and positive")
    return value.quantize(CENT, rounding=ROUND_HALF_UP)


def validate_category(category: str) -> str:
    value = category.strip()
    if not value or len(value) > 40:
        raise ValueError("Category must contain 1 to 40 characters")
    return value


def add_expense(path: Path, category: str, amount: Decimal, when: date | None = None) -> None:
    category = validate_category(category)
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists() or path.stat().st_size == 0
    with path.open("a", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDS)
        if write_header:
            writer.writeheader()
        writer.writerow({
            "date": (when or date.today()).isoformat(),
            "category": category,
            "amount": str(amount),
        })


def read_expenses(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        if reader.fieldnames is None or not set(FIELDS).issubset(reader.fieldnames):
            raise ValueError("Missing CSV header: date,category,amount")
        return list(reader)


def summary(path: Path) -> dict[str, Decimal]:
    totals: dict[str, Decimal] = {}
    for index, row in enumerate(read_expenses(path), start=2):
        try:
            category = validate_category(row["category"])
            amount = parse_amount(row["amount"])
            date.fromisoformat(row["date"])
        except (ValueError, KeyError, TypeError) as exc:
            raise ValueError(f"Invalid CSV row {index}") from exc
        totals[category] = totals.get(category, Decimal("0.00")) + amount
    return totals


def main() -> int:
    parser = argparse.ArgumentParser(description="Offline Expense Tracker")
    parser.add_argument("--file", type=Path, default=Path("expenses.csv"), help="CSV storage file")
    commands = parser.add_subparsers(dest="command", required=True)
    add = commands.add_parser("add", help="Add an expense")
    add.add_argument("category")
    add.add_argument("amount")
    commands.add_parser("list", help="Show stored expenses")
    commands.add_parser("summary", help="Sum expenses by category")
    args = parser.parse_args()
    try:
        if args.command == "add":
            amount = parse_amount(args.amount)
            add_expense(args.file, args.category, amount)
            print("Added", args.category, f"{amount:.2f}")
        elif args.command == "list":
            for row in read_expenses(args.file):
                print(row["date"], row["category"], row["amount"])
        elif args.command == "summary":
            for category, value in sorted(summary(args.file).items()):
                print(category, f"{value:.2f}")
    except (OSError, ValueError) as exc:
        parser.exit(2, f"Error: {exc}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
