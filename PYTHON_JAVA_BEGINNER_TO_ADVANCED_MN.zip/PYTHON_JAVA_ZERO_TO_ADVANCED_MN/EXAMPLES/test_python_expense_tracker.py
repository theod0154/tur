import tempfile
import unittest
from datetime import date
from decimal import Decimal
from pathlib import Path
from python_expense_tracker import add_expense, parse_amount, read_expenses, summary


class ExpenseTests(unittest.TestCase):
    def test_valid_amount(self):
        self.assertEqual(parse_amount("15.205"), Decimal("15.21"))

    def test_invalid_amounts(self):
        for value in ("abc", "-1", "0", "NaN", "Infinity"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                parse_amount(value)

    def test_add_and_summary(self):
        with tempfile.TemporaryDirectory() as folder:
            file = Path(folder) / "expenses.csv"
            add_expense(file, "Food", Decimal("10.50"), date(2026, 11, 20))
            add_expense(file, "Food", Decimal("1.25"), date(2026, 11, 20))
            self.assertEqual(len(read_expenses(file)), 2)
            self.assertEqual(summary(file)["Food"], Decimal("11.75"))

    def test_missing_file(self):
        with tempfile.TemporaryDirectory() as folder:
            self.assertEqual(read_expenses(Path(folder) / "missing.csv"), [])


if __name__ == "__main__":
    unittest.main()
