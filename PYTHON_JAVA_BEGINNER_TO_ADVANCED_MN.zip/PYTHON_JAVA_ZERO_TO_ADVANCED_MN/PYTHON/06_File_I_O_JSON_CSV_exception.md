# PYTHON — Module 06

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`PYTHON_COMPLETE_GUIDE_MN.md`](../PYTHON_COMPLETE_GUIDE_MN.md)

## 06. File I/O, JSON, CSV, exception

`I/O` (Input/Output) гэдэг нь файл унших, бичих зэрэг оролт/гаралт. `with` нь файл хаахыг найдвартай удирдана. `pathlib.Path` нь OS-оос хамаарал багатай замын API.

```python
from pathlib import Path
import json

path = Path("assets.json")
assets = [{"host": "web01", "critical": True}, {"host": "db01", "critical": False}]
path.write_text(json.dumps(assets, ensure_ascii=False, indent=2), encoding="utf-8")
loaded = json.loads(path.read_text(encoding="utf-8"))
print(len(loaded), loaded[0]["host"])  # 2 web01
```

```python
import csv
from pathlib import Path

with Path("report.csv").open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["host", "status"])
    writer.writeheader()
    writer.writerow({"host": "web01", "status": "up"})

with Path("report.csv").open(newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        print(row["host"], row["status"])  # web01 up
```

**Exception handling:**

```python
try:
    value = int("12")
except ValueError as exc:
    print("Тоон утга буруу:", exc)
else:
    print(value)  # 12
finally:
    print("Дууслаа")
```

`except Exception: pass` гэж алдаа залгиж болохгүй. `FileNotFoundError`, `PermissionError`, `UnicodeDecodeError` зэрэг **онцлог алдааг** тусад нь барь. Файлтай ажиллахдаа нууц token, password логт бичихгүй.

**Дасгал:** (1) CSV-ээс status=`down` мөрүүдийг шүүнэ. (2) JSON унших үед файл байхгүй болон JSON эвдэрсэн хоёр нөхцөлийг ялга. (3) Тайланг UTF-8 текст файлд бич.

