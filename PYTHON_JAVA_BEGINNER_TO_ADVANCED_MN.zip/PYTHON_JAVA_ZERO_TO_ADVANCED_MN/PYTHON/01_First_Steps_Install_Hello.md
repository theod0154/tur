# PYTHON — Module 01

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`PYTHON_COMPLETE_GUIDE_MN.md`](../PYTHON_COMPLETE_GUIDE_MN.md)

## 01. Программчлалын үндэс ба анхны Python код

**Тайлбар.** Программ гэдэг нь компьютерт алхамчилсан заавар өгсөн текст. `source code` нь таны бичсэн код, `interpreter` нь түүнийг ажиллуулдаг програм, `terminal` нь текст команд оруулах орчин. Алдаа гарахыг `bug`, алдаа олохыг `debugging` гэдэг.

**Суулгах:** Python-ыг https://www.python.org/downloads/ хуудаснаас ав. Windows дээр Python launcher ашиглавал `py`, Linux/macOS дээр `python3` түгээмэл. Суулгасан хувилбарыг шалгах:

```powershell
py --version
py -c "print('Sain baina uu, Python!')"
```

Linux/macOS:

```bash
python3 --version
python3 -c "print('Sain baina uu, Python!')"
```

`--version`: хувилбар харуулна; `-c`: богино кодыг шууд ажиллуулна. Боломжит гаралт: `Python 3.13.x`, дараа нь `Sain baina uu, Python!`. `py` олдохгүй бол Windows PATH эсвэл Python launcher суусан эсэхийг шалга. `python3` олдохгүй бол Python суулгасан эсэхээ шалга.

`hello.py` файл үүсгэ:

```python
name = "Anu"             # Текст утга (str)
print("Sain uu,", name)   # print() дэлгэцэнд бичнэ
print(2 + 3)              # Тооцоолол
```

```text
Sain uu, Anu
5
```

**Гол зарчим:** Python-ийн `indentation` (мөрийн эхний зай) нь кодын бүтцийг тодорхойлдог. Таб болон зайг санамсаргүй хольж болохгүй; ердийн стандарт нь 4 зай.

**Дасгал:** (1) Өөрийн нэр, сурч буй хэлийг хэвлэ. (2) 3 тооны нийлбэрийг хэвлэ. (3) `print(5 / 2)` ба `print(5 // 2)`-ын зөрүүг ажигла.

**Шалгах:** Та `.py` файл үүсгээд ажиллуулж чаддаг уу? `SyntaxError` болон `NameError` хоёрын утгыг ялгаж чаддаг уу?

