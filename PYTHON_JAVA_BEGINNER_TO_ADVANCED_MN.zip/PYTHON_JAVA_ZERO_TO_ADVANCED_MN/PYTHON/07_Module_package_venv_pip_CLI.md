# PYTHON — Module 07

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`PYTHON_COMPLETE_GUIDE_MN.md`](../PYTHON_COMPLETE_GUIDE_MN.md)

## 07. Module, package, `venv`, `pip`, CLI

`module` = нэг `.py` файл; `package` = зохион байгуулалттай modules; `pip` = Python package installer; `venv` = тусгаарласан Python орчин. Төслийн dependency-г үндсэн OS Python-д хольж суулгахгүй.

```bash
python3 -m venv .venv        # шинэ virtual environment үүсгэнэ
source .venv/bin/activate   # Linux/macOS дээр идэвхжүүлнэ
python -m pip --version     # энэ Python-ийн pip-г шалгана
```

Windows PowerShell:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip --version
```

`deactivate` нь environment-ээс гарна. `.venv/`-ийг Git-д commit хийхгүй. `python -m pip` нь яг аль interpreter-тай package холбоотойг тодорхой болгодог.

```python
# math_utils.py
def total(items):
    return sum(items)

# main.py
import argparse
from math_utils import total

parser = argparse.ArgumentParser(description="Sum numbers")
parser.add_argument("numbers", nargs="+", type=float)
args = parser.parse_args()
print(total(args.numbers))
```

`python main.py 2 3 4` → `9.0`. `nargs="+"`: дор хаяж нэг argument; `type=float`: тоо болгон хөрвүүлнэ. Алдаатай оролтод `argparse` туслах тайлбар хэвлэнэ. `--help`-ээр CLI тайлбар харах.

**Дасгал:** 2 module-тэй өөрийн CLI calculator хий; `--help`-ийг тохируул; оролтыг алдаатай өгөөд ямар error гарахыг ажигла.

---
