# PYTHON — Module 15

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`PYTHON_COMPLETE_GUIDE_MN.md`](../PYTHON_COMPLETE_GUIDE_MN.md)

## 15. Python capstone projects: Beginner → Advanced

**Project P1 — Expense Tracker (Beginner):** `date`, `category`, `amount` бүхий CSV файл хөтөлнө. `add/list/summary` CLI командтай; `amount > 0` шалгана; category-гаар нийлбэр гаргана. Зөвхөн `csv`, `argparse`, `decimal`, `pathlib` ашигла.

**Project P2 — Asset Inventory Analyzer (Intermediate):** `assets.csv` уншаад давхардсан hostname, дутуу owner, outdated inventory timestamp-ийг илрүүлж `report.json` гаргана. Data validation, `dataclass`, custom exceptions, test case 8+ ашигла. Нууц IP, жинхэнэ байгууллагын мэдээлэл оруулахгүй, sample data зохио.

**Project P3 — Offline Code Safety Checker (Advanced):** Өөрийн жишээ Python файлуудаас `eval(`, `shell=True`, `pickle.loads(` гэсэн *сэжигтэй pattern*-ийг `ast` модуль ашиглан илрүүлээд file/line/code-type тайлан гарга. Энэ нь **SAST heuristic** болохоос vulnerability-г нотлохгүй. False positive-ийн жишээ 3-аас доошгүй бэлд; syntax error-тэй файлыг тусад нь мэдээл.

**Төсөл хүлээн авах шалгуур:**
- `README.md`: хэрхэн ажиллуулах, ямар input авдаг, ямар output өгөх, хязгаарлалтууд.
- `src/` эсвэл ойлгомжтой module бүтэц; `tests/` хавтас.
- Энгийн болон алдаатай оролтын 8+ test, 1 integration scenario.
- File path болон exception хамгаалалт; хувийн мэдээлэлгүй example data.
- Санаатай bug үүсгээд test-ээр барьж, зассанаа нотолсон богино report.

### Python self-assessment

| Түвшин | Чадварын шалгуур |
|---|---|
| Beginner | `if/for/function/list/dict`-ээр 100 мөрөөс бага програм бие даан бичдэг |
| Intermediate | File I/O, OOP, modules, CLI, unittest-тэй 500+ мөр орчим төсөл зохион байгуулдаг |
| Advanced-oriented | Type design, concurrency tradeoff, packaging, profiler, security review, tests, documentation болон maintainability-ийг бие даан тайлбарладаг |

> **Санамж:** Зөвхөн материал уншаад Advanced болдоггүй. Өөрийн бичсэн кодыг олон удаа засварлаж, тест, code review, бодит төслийн туршлага хуримтлуулна.

### Python албан эх сурвалж
- Python language tutorial — https://docs.python.org/3/tutorial/
- Python standard library — https://docs.python.org/3/library/
- Python packaging / venv — https://packaging.python.org/en/latest/guides/installing-using-pip-and-virtual-environments/
- Python `unittest` — https://docs.python.org/3/library/unittest.html
- Python `asyncio` — https://docs.python.org/3/library/asyncio.html
- Python Security Considerations — https://docs.python.org/3/library/security_warnings.html
