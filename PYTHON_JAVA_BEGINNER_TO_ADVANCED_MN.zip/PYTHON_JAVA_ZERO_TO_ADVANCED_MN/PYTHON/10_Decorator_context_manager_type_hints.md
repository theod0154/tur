# PYTHON — Module 10

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`PYTHON_COMPLETE_GUIDE_MN.md`](../PYTHON_COMPLETE_GUIDE_MN.md)

## 10. Decorator, context manager, type hints

`decorator` нь function-ийг гаднаас нь чимж нэмэлт ажил хийдэг. `context manager` нь ресурс нээх/хаах амьдралын мөчлөгийг хариуцна. Type hints нь алдааг эрт илрүүлэхэд тустай боловч Python runtime дээр автоматаар type validation хийхгүй.

```python
from functools import wraps

def trace(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        print("calling", fn.__name__)
        return fn(*args, **kwargs)
    return wrapper

@trace
def double(x: int) -> int:
    return x * 2

print(double(3))
# calling double
# 6
```

```python
from contextlib import contextmanager

@contextmanager
def audit_step(label: str):
    print("START", label)
    try:
        yield
    finally:
        print("END", label)

with audit_step("parse"):
    print("reading...")
# START parse / reading... / END parse
```

**Typing:** `list[str]` тэмдэглэгээ, `str | None` option, `Protocol` (behavior-based interface), `TypedDict` (dict-ийн бүтэц), `Generic[T]`-ийг дараалж сур. Static check-д `mypy` эсвэл `pyright` ашиглаж болно; хэрэв суулгах бол virtual environment-д суулга.

```python
from typing import TypedDict

class Finding(TypedDict):
    title: str
    severity: str

f: Finding = {"title": "Missing check", "severity": "medium"}
```

**Дасгал:** Функц ажиллах хугацааг (зөвхөн duration) хэвлэдэг `@timer` decorator хий. Нууц утга, function argument-уудыг санамсаргүй логд бичихгүй.

