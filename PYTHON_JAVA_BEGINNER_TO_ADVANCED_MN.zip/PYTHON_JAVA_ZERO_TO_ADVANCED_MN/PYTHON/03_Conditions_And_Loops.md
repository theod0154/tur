# PYTHON — Module 03

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`PYTHON_COMPLETE_GUIDE_MN.md`](../PYTHON_COMPLETE_GUIDE_MN.md)

## 03. Нөхцөл ба давталт

`if/elif/else` шийдвэр гаргана; `for` нь iterable доторх зүйлсээр давтана; `while` нь нөхцөл үнэн байх хугацаанд үргэлжилнэ.

```python
score = 78
if score >= 90:
    grade = "A"
elif score >= 70:
    grade = "B"
else:
    grade = "C"
print(grade)  # B

for number in range(1, 4):
    print(number)
# 1, 2, 3 (тус тусдаа мөр)
```

```python
attempts = 0
while attempts < 3:
    attempts += 1
    if attempts == 2:
        continue       # энэ давталтын үлдсэн хэсгийг алгасна
    print(attempts)
# 1, 3
```

`range(1, 4)` нь 1-ээс эхлээд 4-ийг *оруулахгүй*. `break` давталтыг зогсооно. `while True` ашиглахдаа заавал гарах нөхцөл төлөвлө.

**Дасгал:** (1) 1–100 хүртэл 3-т хуваагдах тоонуудын нийлбэр. (2) Анхны тоо эсэхийг шалгах. (3) Өгөгдсөн жагсаалтаас зөвхөн тэгш тоо хэвлэх.

**Шалгах:** `if` нөхцөл `False` үед аль мөрүүд ажиллах вэ? `for` ба `while`-г хэзээ сонгох вэ?

