# PYTHON — Module 05

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`PYTHON_COMPLETE_GUIDE_MN.md`](../PYTHON_COMPLETE_GUIDE_MN.md)

## 05. Function ба scope

`function` нь давтан ашиглах үйлдлийг нэрлэдэг. `parameter` нь function тодорхойлох үеийн хувьсагч, `argument` нь дуудах үед дамжуулах утга. `return` үр дүнг буцаана (`print`-ээс өөр).

```python
def discount(price: float, percent: float = 10) -> float:
    """Үнэний хөнгөлөлт тооцох; percent 0–100 дотор байна."""
    if not 0 <= percent <= 100:
        raise ValueError("percent must be 0..100")
    return price * (1 - percent / 100)

print(discount(200, 15))          # 170.0
print(discount(price=100))       # 90.0
```

Python-д `local scope` нь function дотор; outer нэрийг өөрчлөхдөө `global`-д хэт найдахгүй, утга буцаадаг загвар сонго. **Mutable default argument** нь нийтлэг bug:

```python
# БУРУУ: нэг list бүх дуудлагад хадгалагдана
# def add(item, items=[]): ...

def add(item, items=None):
    if items is None:
        items = []
    items.append(item)
    return items
```

**Дасгал:** (1) `is_prime(n)` хэрэгжүүл. (2) `average(numbers)` хоосон list-д юу хийхийг тодорхойл. (3) Нэг том кодыг гурван тусдаа function болгон задла.

