# PYTHON — Module 12

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`PYTHON_COMPLETE_GUIDE_MN.md`](../PYTHON_COMPLETE_GUIDE_MN.md)

## 12. Algorithms, complexity, өгөгдлийн бүтэц сонголт

`algorithm` нь асуудал шийдэх алхмууд. `Big-O` нь оролт ихсэхэд ажиллах цаг/санах ойн өсөлтийг ерөнхийлнө. `O(1)` — тогтмол, `O(n)` — шугаман, `O(n log n)` — түгээмэл сайн sorting complexity, `O(n²)` — давхар nested scan. Үргэлж бодит хэмжилттэй хамт бодолц.

```python
# O(n) — утгыг нэг нэгээр хайна
def contains(items: list[int], target: int) -> bool:
    for item in items:
        if item == target:
            return True
    return False

# set-ийн membership нь дунджаар O(1)
allowed = {10, 20, 30}
print(20 in allowed)  # True
```

```python
from collections import Counter, deque
from bisect import bisect_left

print(Counter("banana"))        # Counter({'a': 3, 'n': 2, 'b': 1})
queue = deque(["a", "b"])
print(queue.popleft())           # a
print(bisect_left([2, 5, 8], 5)) # 1
```

`set` hashable element шаарддаг; hashing нь normal usage-д сайн ч худал амлалт болох worst-case deterministic O(1) биш. `sorted()` шинэ list буцаана, `.sort()` эх list-ийг өөрчилдөг.

**Дасгал:** (1) Дунджаар хурдан membership хэрэгтэй үед `set` ашигла. (2) Давхардсан ID тоол. (3) Queue-г `deque`-ээр хийгээд FIFO (First In, First Out) зарчмыг харуул.

