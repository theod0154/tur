# PYTHON — Module 08

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`PYTHON_COMPLETE_GUIDE_MN.md`](../PYTHON_COMPLETE_GUIDE_MN.md)

## 08. Object-Oriented Programming (OOP)

`OOP` нь өгөгдөл болон түүнийг боловсруулах аргыг нэг объектод нэгтгэх загвар. `class` = загвар, `object` = тэр загвараас бүтээгдсэн бодит утга, `attribute` = шинж, `method` = үйлдэл. `self` нь одоогийн объект. `__init__` нь объект үүсэх үед анхны утга оноодог.

```python
class BankAccount:
    def __init__(self, owner: str, balance: int = 0):
        if balance < 0:
            raise ValueError("opening balance cannot be negative")
        self.owner = owner
        self._balance = balance

    @property
    def balance(self) -> int:
        return self._balance

    def deposit(self, amount: int) -> None:
        if amount <= 0:
            raise ValueError("amount must be positive")
        self._balance += amount

account = BankAccount("Anu", 100)
account.deposit(50)
print(account.balance)  # 150
```

`_balance` нь Python convention-оор *internal* гэдгийг илтгэнэ, бодитоор private болгохгүй. `@property` нь уншихыг зөвшөөрөөд шууд солих боломжийг хязгаарлах interface; immutable object шаардлагатай бол `@dataclass(frozen=True)`.

```python
from dataclasses import dataclass

@dataclass(frozen=True)
class Asset:
    hostname: str
    owner: str

print(Asset("web01", "IT"))
# Asset(hostname='web01', owner='IT')
```

`Inheritance` (өвлөх) нь "is-a" харилцаанд, `composition` (объект дотроо өөр объект агуулдаг) нь "has-a" харилцаанд тохирдог. Давхар удамшлын төвөгтэй загварыг эхэндээ хэрэглэхгүй; composition-ийг түрүүнд бодолц.

**Дасгал:** `InventoryItem` class бич; тоо ширхэгийг сөрөг болгож болохгүй; `add_stock` ба `remove_stock` методтой болго; гурван test case гарга.

