# PYTHON — Module 09

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`PYTHON_COMPLETE_GUIDE_MN.md`](../PYTHON_COMPLETE_GUIDE_MN.md)

## 09. Iterable, iterator, generator

`iterable` нь давтаж болох (`list`, `str`, `dict`); `iterator` нь дараагийн элементийг `next()`-ээр өгдөг; `generator` нь бүх үр дүнг нэг дор RAM-д хадгалахгүй, шаардлагатай үедээ (`yield`) үүсгэдэг.

```python
def squares(limit: int):
    for n in range(limit):
        yield n * n

for value in squares(4):
    print(value)
# 0, 1, 4, 9 (тусдаа мөр)
```

```python
records = [
    {"host": "a", "status": "up"},
    {"host": "b", "status": "down"},
]
down_hosts = (r["host"] for r in records if r["status"] == "down")
print(list(down_hosts))  # ['b']
```

Generator **нэг удаа зарцуулагдана**. `list(generator)` нэг удаа уншсаны дараа дахин уншихад хоосон байж болно. File line streaming-д хэрэгтэй: `for line in file:`.

**Дасгал:** Маш олон тоог RAM-д бүхэлд нь хадгалахгүйгээр тэгшийг нь дараалан өгдөг generator бич. `list` ба `generator` санах ойг хэрхэн ялгаатай ашиглахыг тайлбарла.

