# PYTHON — Module 04

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`PYTHON_COMPLETE_GUIDE_MN.md`](../PYTHON_COMPLETE_GUIDE_MN.md)

## 04. Өгөгдлийн бүтэц: list, tuple, dict, set

| Type | Зориулалт | Өөрчилж болох уу? | Давхардал |
|---|---|---|---|
| `list` | Дараалал | Тийм | Болно |
| `tuple` | Тогтвортой дараалал | Үгүй | Болно |
| `dict` | Key → Value | Тийм | Key давхардахгүй |
| `set` | Давхардалгүй элементүүд | Тийм | Болохгүй |

```python
servers = ["web01", "db01", "web01"]
servers.append("api01")
print(servers[0], servers[-1]) # web01 api01
print(set(servers))            # дараалал нь баталгаагүй

asset = {"hostname": "web01", "status": "up", "ports": [443]}
asset["owner"] = "IT"
print(asset.get("ip", "not set")) # not set
for key, value in asset.items():
    print(key, value)
```

`list`-ийн index 0-ээс эхэлнэ. `dict["missing"]` байхгүй key дээр `KeyError`, харин `.get()` default буцааж болно. `set`-ийн хэвлэх дараалал тогтмол биш.

**List comprehension:**

```python
numbers = [1, 2, 3, 4, 5]
evens_squared = [n * n for n in numbers if n % 2 == 0]
print(evens_squared)  # [4, 16]
```

**Дасгал:** (1) Давхардсан hostname-ийг арилга. (2) `[{"name":..., "age":...}]` дундаас 18+ хүмүүсийг ол. (3) Нэг өгүүлбэрийн үгийн давтамжийг `dict`-ээр тоол.

