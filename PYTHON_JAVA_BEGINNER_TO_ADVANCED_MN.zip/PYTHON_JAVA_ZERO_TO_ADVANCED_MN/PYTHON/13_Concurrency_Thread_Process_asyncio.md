# PYTHON — Module 13

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`PYTHON_COMPLETE_GUIDE_MN.md`](../PYTHON_COMPLETE_GUIDE_MN.md)

## 13. Concurrency: Thread, Process, asyncio

`concurrency` нь олон ажил хооронд нь уялдуулж гүйцэтгэх; `parallelism` нь үнэхээр зэрэг CPU дээр ажиллах. `threading` нь I/O хүлээлттэй ажлуудад тустай; `multiprocessing` тусдаа process ашиглах боломжтой; `asyncio` нь `await`-аар cooperative scheduling хийдэг. Энэ нь автоматаар бүх кодыг хурдлуулахгүй.

```python
import asyncio

async def fetch_simulated(name: str) -> str:
    await asyncio.sleep(0.1)   # сүлжээний хүсэлт БИШ, зөвхөн simulation
    return f"{name}: ready"

async def main():
    results = await asyncio.gather(
        fetch_simulated("task-A"), fetch_simulated("task-B")
    )
    print(results)

asyncio.run(main())
# ['task-A: ready', 'task-B: ready']
```

```python
from concurrent.futures import ThreadPoolExecutor

with ThreadPoolExecutor(max_workers=2) as pool:
    print(list(pool.map(lambda n: n * n, [1, 2, 3])))
# [1, 4, 9]
```

**Эрсдэл:** Shared mutable state → race condition; lock ашиглан critical section хамгаал. `asyncio` coroutine дотор `time.sleep()` гэх мэт blocking call хийвэл event loop гацаана. `multiprocessing` дээр Windows/macOS-д `if __name__ == "__main__":` хамгаалалт чухал.

**Дасгал:** `asyncio.gather` ашиглан гурван симуляцийн ажил гүйцэтгэ; нэг ажлыг `await asyncio.sleep()`-оор хүлээлгэ; sync/async ялгааг тайлбарла.

