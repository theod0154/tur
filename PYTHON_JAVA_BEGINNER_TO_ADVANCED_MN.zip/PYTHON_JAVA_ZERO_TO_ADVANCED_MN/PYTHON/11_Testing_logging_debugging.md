# PYTHON — Module 11

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`PYTHON_COMPLETE_GUIDE_MN.md`](../PYTHON_COMPLETE_GUIDE_MN.md)

## 11. Testing, logging, debugging

`unit test` нь жижиг нэгжийг шалгана; `integration test` нь хэд хэдэн бүрэлдэхүүнийг хамтад нь шалгана. `assert` нь тест дотор хүлээгдэж буй нөхцөл; application validation-д `assert` биш `raise ValueError` зэрэг шалгалт хэрэглэ (optimization горимд assert хасагдаж болно).

```python
# calculator.py
def divide(a: float, b: float) -> float:
    if b == 0:
        raise ValueError("division by zero")
    return a / b

# test_calculator.py
import unittest
from calculator import divide

class DivideTests(unittest.TestCase):
    def test_normal(self):
        self.assertEqual(divide(8, 2), 4)

    def test_zero(self):
        with self.assertRaises(ValueError):
            divide(8, 0)

if __name__ == "__main__":
    unittest.main()
```

```bash
python -m unittest discover -v
```

Хүлээгдэх үр дүн: `Ran 2 tests ... OK` (формат хувилбараас хамаарна). `discover` нь `test*.py` хэв маягийн тестийг хайна; `-v` дэлгэрэнгүй мэдээлэл гаргана. `No tests found` бол файлын нэр, хавтсын байрлал, import error-ийг шалга.

```python
import logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
logging.info("processed %d records", 3)
```

Нууц, password, bearer token, хувийн мэдээллийг log-д гаргахгүй. Дибаг хийхдээ traceback-ийн **хамгийн сүүлчийн мөр** болон өөрийн файлд заасан дугаараас эхэл.

**Дасгал:** `divide()`-д negative/decimal тест нэм; `test_normal`-ийг санаатай унагаж traceback унш; тест давтагдах боломжтой (`deterministic`) байгаа эсэхийг шалга.

