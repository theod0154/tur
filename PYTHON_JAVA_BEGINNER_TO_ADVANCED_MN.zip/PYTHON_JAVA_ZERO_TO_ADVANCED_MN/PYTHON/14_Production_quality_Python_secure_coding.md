# PYTHON — Module 14

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`PYTHON_COMPLETE_GUIDE_MN.md`](../PYTHON_COMPLETE_GUIDE_MN.md)

## 14. Production-quality Python ба secure coding

**Цэвэр кодын шалгуур:** нэр ойлгомжтой, нэг function нэг үүрэгтэй, input validation ил тод, exception нь утгатай, тесттэй, dependency version хянадаг, secrets hardcode хийгээгүй, log-д эмзэг мэдээлэл байхгүй. `lint`/`format` tools — `ruff`, `black`; type tools — `mypy`/`pyright` (сонголттой).

```python
# АЮУЛТАЙ ХЭВ МАЯГ: shell=True + user input
# subprocess.run(f"echo {user_input}", shell=True)

# АЮУЛГҮЙ ХУВИЛБАР: arguments list, shell=False (default)
import subprocess
subprocess.run(["echo", "hello"], check=True)
```

Жишээ нь `echo` Windows дээр shell built-in байдаг тул Windows-д энэ snippet ажиллахгүй байж болно; зарчим нь *shell parsing* хэрэглэхгүйгээр program болон аргументуудыг тусад нь дамжуулах явдал. Хэрэглэгчийн input-аас executable нэрийг чөлөөтэй сонгож болохгүй — allowable list хэрэгтэй.

```python
# Secret-ийг source code-д хадгалахгүй
import os
api_key = os.getenv("MY_APP_API_KEY")
if api_key is None:
    print("Configuration missing")  # Нууц утгыг хэвлэхгүй
```

**Security code review-д үзэх зүйлс:**

| Кодын хэв маяг | Эрсдэл | Илүү зөв шийдэл |
|---|---|---|
| `eval(user_text)` | Arbitrary code execution | `json.loads`, зөвшөөрөгдсөн parser |
| `pickle.loads(untrusted)` | Unsafe deserialization | JSON зэрэг data-only format |
| string concatenation SQL | SQL injection | Parameterized query |
| `subprocess(..., shell=True)` | Command injection | Argument list, allowlist |
| `Path(base) / untrusted_name` | Path traversal | Canonical path validation, зөвшөөрөгдсөн нэр |
| `except Exception: pass` | Алдаа нуугдана | Narrow exception + structured logging |

```python
# Parameterized query — sqlite3 (server хэрэггүй, in-memory DB)
import sqlite3
with sqlite3.connect(":memory:") as db:
    db.execute("CREATE TABLE users (name TEXT)")
    db.execute("INSERT INTO users (name) VALUES (?)", ("Anu",))
    rows = db.execute("SELECT name FROM users WHERE name = ?", ("Anu",)).fetchall()
    print(rows)  # [('Anu',)]
```

`?` placeholder нь утгыг SQL syntax болгон нийлүүлдэггүй; SQL identifier (table name) dynamic бол allowlist шаарддаг. Энэ бол offline demonstration, network/server ажиллахгүй.

**Дасгал:** Энэ хүснэгт дэх 6 anti-pattern-аас аль нь зөвхөн *таамагласан* эрсдэл, аль нь баталгаажуулах шаардлагатайг тайлбарла; `eval`-гүйгээр JSON parse хий.

