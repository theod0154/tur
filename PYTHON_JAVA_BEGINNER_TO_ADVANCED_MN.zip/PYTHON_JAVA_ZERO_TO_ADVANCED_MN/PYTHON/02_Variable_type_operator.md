# PYTHON — Module 02

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`PYTHON_COMPLETE_GUIDE_MN.md`](../PYTHON_COMPLETE_GUIDE_MN.md)

## 02. Variable, type, operator

Python-ийн хувьсагч бол утгад өгсөн *нэр*. `int` бүхэл тоо, `float` бутархай, `str` текст, `bool` логик (`True`/`False`), `None` утгагүйг илэрхийлнэ.

```python
age = 22
price = 19.9
name = "Bataa"
is_active = True
unknown = None
print(type(age).__name__)      # int
print(f"{name}: {age} nastai") # f-string
print(7 / 2, 7 // 2, 7 % 2)  # 3.5 3 1
```

`=` бол утга оноох, `==` тэнцүү эсэхийг шалгах, `!=` ялгаатай, `and/or/not` логик оператор. `is` нь **ижил объект** эсэх, `==` нь **утга тэнцүү** эсэхийг шалгана. `input()` үргэлж `str` буцаана; тоо болгохын өмнө алдааг бодолц.

```python
raw = "15000"
amount = int(raw)           # str → int
vat = amount * 0.10
print(f"VAT: {vat:.2f}")  # VAT: 1500.00
```

**Алдаа:** `"10" + 5` нь `TypeError`; `int("abc")` нь `ValueError`. Мөнгөний нарийн тооцоонд binary `float` бус `decimal.Decimal` хэрэглэх нь зөв.

**Дасгал:** НӨАТ-тай үнийг тооц. 200,000₮-ийн 15% хөнгөлөлт хэд вэ? `is` ба `==` яагаад өөр вэ гэдгийг өөрийн үгээр тайлбарла.

