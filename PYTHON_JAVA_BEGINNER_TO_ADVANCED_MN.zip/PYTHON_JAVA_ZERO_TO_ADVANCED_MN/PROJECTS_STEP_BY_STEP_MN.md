# Python + Java — 2 бүрэн offline project-ийн алхамчилсан сургалт

Энэ нь зөвхөн code snippet цээжлэх биш, **project хэрхэн эхлүүлэх, requirement тодорхойлох, хөгжүүлэх, тест хийх, bug засах, refactor хийх** дадлага. Төслүүд `/EXAMPLES/` хавтаст байгаа; localhost, Docker, backend server шаардлагагүй. Эхний удаа бэлэн кодыг уншаад, дараа нь **харахгүйгээр дахин бич**.

---

## Project 1 — Python Expense Tracker CLI

### 1. Бодит хэрэгцээ

Хувийн зардлыг `CSV` файлд хадгалж, category-аар нийлбэрийг тооцдог console application. Зарим хэрэглэгч мөнгөний дүнд `0`, `-100`, `NaN` эсвэл `abc` оруулж болно; энэ үед програм буруу тоо хадгалах ёсгүй.

**Functional requirements:**
- `add CATEGORY AMOUNT` — нэг зардал нэмнэ.
- `list` — хадгалсан зардлуудыг харуулна.
- `summary` — category тус бүрийн нийлбэр харуулна.
- `--file PATH` — хадгалах CSV файлыг сонгоно.

**Nonfunctional:** UTF-8, Decimal precision, input validation, meaningful errors, testable functions, network шаардлагагүй.

### 2. Code architecture

```text
EXAMPLES/
  python_expense_tracker.py
  test_python_expense_tracker.py
  expenses.csv                 # ажиллуулах үед шинээр үүснэ, ZIP-д урьдчилан байхгүй
```

Source файл дахь дараах үүргүүдийг ялгаж ойлго:

| Function | Үүрэг | Яагаад тусад нь? |
|---|---|---|
| `parse_amount(raw)` | Text → Decimal, finite/positive validation | Нэг газарт бизнес дүрэм |
| `validate_category(category)` | Хоосон/хэт урт category reject | Data invariant |
| `add_expense(path, category, amount)` | CSV-д хадгалах | File I/O нь CLI-ээс тусгаарлагдсан |
| `read_expenses(path)` | CSV-ээс мөрүүд унших | Parsing нь display-ээс тусдаа |
| `summary(path)` | Category-гаар тооцох | Unit test-лэхэд амар |
| `main()` | Command-line аргумент, output, errors | Оролт/гаралтын orchestration |

**Яагаад `Decimal`?** `float` нь мөнгөн тооцоонд representation error үүсгэж болно; `Decimal` нь хүний хэрэглэдэг decimal утгад илүү тохиромжтой. Гэхдээ rounding policy-г business requirement-аар тодорхойлно.

### 3. Ажиллуулах (Windows PowerShell)

```powershell
cd EXAMPLES
py python_expense_tracker.py --file demo.csv add Food 1250.50
py python_expense_tracker.py --file demo.csv add Taxi 5000
py python_expense_tracker.py --file demo.csv summary
py python_expense_tracker.py --file demo.csv list
```

Linux/macOS дээр `py`-ийн оронд `python3`. `--file demo.csv` нь subcommand (`add`, `summary`)-ийн **өмнө** байрлана. `add` нь файл байхгүй бол header + row үүсгэдэг.

**Expected summary:**

```text
Food 1250.50
Taxi 5000.00
```

**Negative tests:**

```powershell
py python_expense_tracker.py --file demo.csv add Food -100
py python_expense_tracker.py --file demo.csv add Food abc
py python_expense_tracker.py --file demo.csv add Food NaN
```

Хүлээгдэх: `Error: Amount must be ...` ба exit code 2. Энэ нь мөнгөн дүнг буруу хадгалахаас хамгаалж буй жишээ. Өөрийн зохиомол өгөгдөл ашигла.

### 4. Unit tests

```bash
python3 -m unittest discover -s EXAMPLES -p 'test_*.py' -v
```

`-s EXAMPLES` нь test folder, `-p` нь файл нэрийн pattern, `-v` нь verbose output. **Expected:** 4 test method амжилттай (`OK`). Хэрэв `ModuleNotFoundError` гарвал test/source хоёулаа `EXAMPLES/`-т байгаа эсэхийг шалга.

**Алдаа илрүүлэх дасгал:** `parse_amount` дотор `value <= 0` шалгалтыг түр аваад test ажиллуул; `test_invalid_amounts` унах ёстой. Буцааж сэргээ. Ингэж test нь бодит өөрчлөлт барьж чаддагийг батална.

### 5. Refactoring ба advanced шат

1. `--month YYYY-MM` filter нэмэх (data format validation).
2. `Decimal`-ийн дүнг category currency code-оор хадгалах (нэгтгэхдээ currency холихгүй).
3. CSV corrupt row-д row number-тай error гаргадаг байгааг test-ээр баталгаажуул.
4. `unittest.mock`-оор date generator injected болгоод test deterministic болго.
5. `mypy`/`pyright` болон formatter-оор static check хий.
6. Data export хийхдээ spreadsheet formula injection эрсдэлийг таньж, **export context-д** formula-neutralization policy сонго. Raw CSV data model-г дотроо эвдэхгүй.

---

## Project 2 — Java Inventory Console

### 1. Бодит хэрэгцээ

Host / inventory зүйлийн тоо бүртгэх **ажиллаж байх үедээ RAM-д хадгалдаг** CLI. `quit` хийхэд өгөгдөл хадгалагдахгүй: file persistence-г дараагийн шатны нэмэлт ажил болгон өгсөн.

```text
Commands: add HOST N | remove HOST N | list | quit
```

**Business rules:**
- Host нэр `web01`, `db01` гэх мэт оролтын дүрэмтэй.
- Тоо `N > 0`.
- Сөрөг stock болох ёсгүй.
- Бүхэл тооны overflow-ийг `Math.addExact` илрүүлнэ.
- `list`-ийн гаралт hostname-аар эрэмбэлэгдсэн байна.

### 2. Source architecture

```text
EXAMPLES/
  JavaInventory.java
  JavaInventoryTest.java
```

`JavaInventory`-ийн доторх `Inventory` class-д бизнес дүрэм байрлана. `main()` нь console command-ийг уншиж `Inventory`-ийн method-уудыг дуудна. Энэ нь **separation of concerns** гэдэг зарчим: `main()`-д бүх логикийг чихэхгүй.

### 3. Compile/run

```bash
cd EXAMPLES
javac JavaInventory.java JavaInventoryTest.java
java JavaInventory
```

Console дээр дараах мөрүүдийг нэг нэгээр оруул:

```text
add web01 5
add db01 2
remove web01 1
list
quit
```

**Expected list:**

```text
db01 2
web01 4
```

Нэмэлт `OK` messages мөр болгонд харагдана. Invalid input (жишээ нь `remove web01 100`) өгвөл `Error: Not enough stock` гарна, stock хэвээр байна.

### 4. Automated self-check

```bash
java JavaInventoryTest
```

**Expected:** `PASS`. Энэ нь үндсэн invariant-уудыг шалгасан жижиг console self-check, **JUnit биш**. Java гарын авлагын 11-р бүлгээс Maven/JUnit test suite рүү шилжүүлж сураарай.

### 5. Хичээлийн өөрийн даалгавар

1. `remove` method 0 эсвэл negative input авч чадахгүй байгааг 2 test-ээр баталгаажуул.
2. `Map.copyOf(stock)` нь snapshot үүсгэдэг боловч гаралтын дараалал баталгаагүйг тайлбарла; одоогийн CLI `sorted(...)` ашиглаж буй шалтгааныг ойлго.
3. `InventoryService` болон `ConsoleUI` гэж class-уудыг салга.
4. `save/load` функцийг `Files.readAllLines()` / `Files.writeString()`-ээр нэм (file format validation-тай).
5. Maven project болгон хөрвүүлж, JUnit-д 10 test хийгээд `mvn test` ажиллуул.
6. Concurrency (хоёр thread нэг stock-ийг зэрэг өөрчлөх) орж ирвэл ямар invariant зөрчиж болохыг *зөвхөн conceptual* байдлаар тайлбарла; synchronization strategy бич.

---

## Project review checklist

- [ ] Functional requirement-ийг 1 мөрөөр тодорхой тайлбарласан.
- [ ] Valid/invalid input-ийн behavior тодорхой.
- [ ] Business logic, file I/O, console UI тусдаа.
- [ ] 8+ test scenarios (2 positive, 4 negative, 2 edge-case) байна.
- [ ] Кодын нэршил ойлгомжтой, function/method хэт том биш.
- [ ] Nondeterministic date, random value-г тестдээ control хийдэг.
- [ ] Secrets, real credentials, production data оруулаагүй.
- [ ] Static analysis hypothesis vs confirmed bug ялгасан.
- [ ] README болон sample output байна.

## Advanced project-д шилжих шалгуур

Эдгээр 2 project-ийг харалгүйгээр дахин бүтээж, 3 өөр feature нэмээд, 10 тест бичиж, нэг bug-г тестээр барьж чадвал **intermediate рүү шилжих бэлэн байдлын** сайн үзүүлэлт. Үүнийг Advanced цол гэж үзэхгүй — дараагийн алхам нь maintenance, code review, performance, architecture, concurrency юм.
