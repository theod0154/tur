# Python + Java: Zero → Advanced-oriented | 32 долоо хоногийн сургалтын замын зураг

> **Хэнд:** Программчлалын анхан шатны мэдлэггүй хүн. **Хэл:** Тайлбар Монгол; syntax, tools, code Англи. **Формат:** Файл, terminal, console project; localhost server / vulnerable lab шаардлагагүй.
>
> **Хугацаа:** 32 долоо хоног × 8–12 цаг = 256–384 цагийн **суурь+intermediate+advanced-oriented** сурах төлөвлөгөө. Advanced engineer болохын тулд үүнээс гадна бодит төсөл, багийн code review, удаан хугацааны debugging дадлага зайлшгүй. Түвшин нь долоо хоног өнгөрснөөр биш, хийж чаддаг ажлаар хэмжигдэнэ.

## 1. Аль хэлийг эхэлж сурах вэ?

**Python-оор эхэл.** Товч syntax нь algorithm, function, data structure-г эхэлж ойлгоход тусална. Эхний 8 долоо хоног Python дээр төвлөрч, дараа нь Java-ийн static typing, class, OOP, JVM-г сур. 17 дахь долоо хоногоос хоёр хэлээ ээлжлэн ашиглаж, нэг асуудлыг хоёр янзаар шийд.

| Таны зорилго | Python | Java |
|---|---|---|
| Скрипт, файл, automation | ★★★★★ | ★★★ |
| Enterprise backend / large codebase | ★★★★ | ★★★★★ |
| Security source review | ★★★★★ | ★★★★★ |
| OOP, type system-г гүн ойлгох | ★★★★ | ★★★★★ |
| Алгоритм, ерөнхий програмчлал | ★★★★★ | ★★★★★ |

**Харьцуулалт:** Python runtime дээр dynamic types-тэй; Java нь compiler-level static types-тэй. Python-д whitespace блок заагладаг; Java-д `{}` ба `;`. Python `list/dict`; Java `List/Map`. Python `None`; Java `null`. Python `unittest`; Java `JUnit`. Python орчныг `venv`; Java project build-г Maven/Gradle-аар зохион байгуулдаг.

## 2. Долоо хоногийн өдөр тутмын хуваарь

Дараах нь санал болгох 10 цагийн жишээ:

| Өдөр | Хугацаа | Ажил |
|---|---:|---|
| Даваа | 1 цаг | Нэг сэдвийн тайлбар унших, эхний код ажиллуулах |
| Мягмар | 1.5 цаг | Кодыг харалгүй дахин бичих, 2 жижиг бодлого |
| Лхагва | 1.5 цаг | Нэг шат ахисан дасгал, debug |
| Пүрэв | 1.5 цаг | Өмнөх кодыг refactor, tests нэмэх |
| Баасан | 1 цаг | Тест/дүгнэлт, 10 шинэ нэр томъёоны flashcard |
| Бямба | 2.5 цаг | Mini-project, README, Git commit |
| Ням | 1 цаг | Бие даасан шалгалт, дараагийн долоо хоногийн зорилго |

**50/30/20:** Цагийн ~50%-д код бич, 30%-д бодлого/тест хий, 20%-д видео/ном/баримт унш. Зөвхөн видео үзэх нь дадлага биш.

## 3. 32 долоо хоногийн дэлгэрэнгүй төлөвлөгөө

| Week | Сэдэв | Эцэст нь заавал хийсэн байх ажил |
|---|---|---|
| 01 | Python setup, print, variables | `hello.py` болон 5 жижиг код |
| 02 | Python operators, types, conversion | VAT/discount calculator + edge cases |
| 03 | Python conditions & loops | Prime checker, multiplication table |
| 04 | Python collections | Hostname deduplication + word counter |
| 05 | Python functions | Calculator module + 8 input cases |
| 06 | Python file, CSV, JSON, exceptions | Offline CSV report generator |
| 07 | Python module, venv, CLI | 3 command-тай CLI utility |
| 08 | Python beginner capstone | Expense Tracker v1 + README + test |
| 09 | Java JDK, hello, types | Java main class + Python/Java type comparison |
| 10 | Java condition, loops, arrays | Grade calculator + loops |
| 11 | Java methods, basic recursion | Prime checker Java version |
| 12 | Java class, constructor, encapsulation | BankAccount + tests/manual scenarios |
| 13 | Java interfaces, inheritance, records | Notification interface + 2 implementations |
| 14 | Java exceptions, files | Text-based inventory reader |
| 15 | Java collections, generics | Host counter + Map-based index |
| 16 | Java beginner capstone | Student Grade Manager + README |
| 17 | Python OOP, dataclass | Inventory Analyzer v1 |
| 18 | Python generators, decorators, typing | 2 decorators + streaming analyzer |
| 19 | Python tests/logging | Python project-д 12 unit test |
| 20 | Java Streams & Lambda | List processing + code readability review |
| 21 | Java Maven, JUnit | 12 JUnit tests; reproducible build |
| 22 | Algorithms & Big-O (хоёр хэл) | 5 sorting/search problems + complexity notes |
| 23 | Files, dates, exceptions (хоёр хэл) | CSV↔JSON converter буюу object↔file mapping |
| 24 | Intermediate checkpoint | 1 feature-г 2 хэл дээр хэрэгжүүл, test/report |
| 25 | Python concurrency & performance | async simulated task runner + measurements |
| 26 | Java concurrency | executor / virtual thread examples + race analysis |
| 27 | SQL injection prevention хоёр хэл | Python sqlite parameter, Java JDBC static review |
| 28 | Secure coding & source review | Own code-ийн 10-risk checklist + evidence |
| 29 | Python advanced project | Offline asset/report CLI full refactor |
| 30 | Java advanced project | Maven + JUnit + clean architecture app |
| 31 | Code review & refactor | Өмнөх code-ийн 10 improvement; regression tests |
| 32 | Final evaluation | Portfolio README, demo, tests, learning retrospective |

## 4. Түвшин ахих шалгуур (Gate)

### Gate A — Beginner (8 дугаар долоо хоног)
- [ ] Python variable, `if`, `for`, list/dict, function-ийг зааваргүй бичсэн.
- [ ] Алдаатай `str`→`int` хөрвүүлэлтэд exception зохицуулдаг.
- [ ] CSV/JSON уншиж үр дүн боловсруулдаг.
- [ ] 100–200 мөртэй offline project бие даан бүтээсэн.

### Gate B — Java Foundation (16 дугаар долоо хоног)
- [ ] Class, constructor, `private`, method, interface ашигладаг.
- [ ] `List`, `Map`, `Set` ялгааг мэддэг.
- [ ] Exception болон `try-with-resources`-ийг тайлбарлаж чаддаг.
- [ ] Java code-г `javac/java` ашиглан compile/run хийдэг.

### Gate C — Intermediate (24 дүгээр долоо хоног)
- [ ] Нэг хэрэглээний feature-г Python, Java хоёр хэлээр хэрэгжүүлдэг.
- [ ] Хоёр төсөлд test suite, README, version control байна.
- [ ] Type, data structure, OOP design, Big-O сонголтоо тайлбарладаг.
- [ ] Code review-ээр дор хаяж 5 бодит bug олж зассан.

### Gate D — Advanced-oriented (32 дугаар долоо хоног)
- [ ] Python `asyncio` болон Java virtual threads ямар нөхцөлд тохирохыг тайлбарладаг.
- [ ] Parameterized SQL, safe file paths, secrets hygiene хэрэгжүүлдэг.
- [ ] Test coverage зөвхөн хувь биш, business/edge cases-г хамарсан.
- [ ] Profiler/benchmark ашиглан bottleneck-ийг таамаг бус хэмжилтээр тогтоодог.
- [ ] Илрүүлсэн code risk-ийн false positive, actual evidence-ийг ялгадаг.
- [ ] 2 capstone project ба technical README бүхий portfolio бэлэн.

## 5. Хослуулах 5 ажил

1. **Number filtering:** Python list comprehension vs Java Stream.
2. **JSON/CSV inventory:** Python standard library vs Java collections/files (JSON-д approved third-party lib шаардлагатай байж болно).
3. **Object model:** Python dataclass vs Java record, `private` vs `_internal` convention.
4. **Unit testing:** `unittest` vs JUnit, exception assertions.
5. **Safe SQL:** Python `sqlite3` placeholders vs Java `PreparedStatement`.

## 6. Даалгавар хийх тэмдэглэл

Хамгийн энгийн `LEARNING_LOG.md`-ийг өөрөө үүсгэ:

```markdown
## 2026-11-20 — Python variables
- Сурсан: int, str, bool, input()
- Бичсэн: discount_calculator.py
- Гарсан алдаа: ValueError when converting "abc"
- Яаж зассан: try/except; invalid input message
- Маргааш давтах: list, for loop
```

`Git`-ийн үндсэн команд: `git init`, `git status`, `git add`, `git commit`. Эхний 4 долоо хоногт Git-ийг төслөө хадгалахад ашигла; мэргэжлийн workflow-г дараа нь нэм.

## 7. Үнэгүй албан эх сурвалж

- Python эх сурвалж: https://docs.python.org/3/tutorial/
- Python Packaging: https://packaging.python.org/
- Java modern lessons: https://dev.java/learn/
- Java JDK 25 API: https://docs.oracle.com/en/java/javase/25/docs/api/
- Java Maven: https://maven.apache.org/guides/getting-started/
- JUnit: https://docs.junit.org/current/user-guide/

**Анхаарах:** Python-ийн албан tutorial нь програмчлалын суурь мэдлэгтэй уншигчидтай илүү нийцдэг тул эхний бүлгийн жишээг өөрөө ажиллуулж, энэ гарын авлагын дасгалтай хослуулах нь чухал.
