# JAVA — Module 14

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`JAVA_COMPLETE_GUIDE_MN.md`](../JAVA_COMPLETE_GUIDE_MN.md)

## 14. JVM memory, Garbage Collection, performance

**JVM memory:** `stack` нь method call/local variables-ийн execution frame, `heap` нь object allocation, `metaspace` нь class metadata зэрэг зүйлсийн зориулалттай. `GC` (Garbage Collection) нь ашиглагдахаа больсон object-уудын memory-г reclaimed хийдэг; object memory алдагдахгүй гэсэн баталгаа биш.

```bash
java -XshowSettings:vm -version
java -Xmx256m Hello
```

`-Xmx256m` нь max Java heap size-г 256 MiB орчимд тохируулна; `-XshowSettings:vm` нь VM тохиргооны мэдээлэл харуулна. `-Xmx` багадвал `OutOfMemoryError` үүсч болно, зөвхөн heap өсгөх нь code bug-г арилгахгүй.

```java
import java.util.ArrayList;
import java.util.List;

public class MemoryDemo {
    public static void main(String[] args) {
        List<String> names = new ArrayList<>();
        for (int i = 0; i < 3; i++) names.add("host-" + i);
        System.out.println(names); // [host-0, host-1, host-2]
    }
}
```

Memory profiling-д `jcmd`, Java Flight Recorder (JFR), VisualVM зэрэг tool; гүйцэтгэл сайжруулахдаа эхлээд **measurement** хий. Төсөл бүрт complexity, allocation, GC pause, throughput, latency өөр ач холбогдолтой.

**Дасгал:** Heap ба stack ялгааг зурж тайлбарла; `StringBuilder` яагаад их давталтад `String +`-аас зарим нөхцөлд давуу байж болох вэ? Benchmark хийхдээ warmup яагаад чухал вэ?

