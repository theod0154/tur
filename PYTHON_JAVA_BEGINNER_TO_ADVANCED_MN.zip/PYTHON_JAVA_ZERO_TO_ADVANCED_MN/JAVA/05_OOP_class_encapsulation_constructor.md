# JAVA — Module 05

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`JAVA_COMPLETE_GUIDE_MN.md`](../JAVA_COMPLETE_GUIDE_MN.md)

## 05. OOP: class, encapsulation, constructor

**Encapsulation** нь object-ийн дотоод төлөвийг хяналттай method-аар өөрчлөх. Field-ийг шууд `public` болговол буруу утга чөлөөтэй оноох эрсдэлтэй.

```java
public class BankAccount {
    private final String owner;
    private long balance;

    public BankAccount(String owner, long openingBalance) {
        if (owner == null || owner.isBlank() || openingBalance < 0) {
            throw new IllegalArgumentException("invalid account");
        }
        this.owner = owner;
        this.balance = openingBalance;
    }

    public void deposit(long amount) {
        if (amount <= 0) throw new IllegalArgumentException("amount must be positive");
        balance = Math.addExact(balance, amount);  // overflow тохиолдолд exception
    }

    public long getBalance() { return balance; }
    public String getOwner() { return owner; }

    public static void main(String[] args) {
        BankAccount account = new BankAccount("Anu", 100);
        account.deposit(50);
        System.out.println(account.getBalance()); // 150
    }
}
```

`private` нь field-г class-аас гадна шууд өөрчлөхийг хязгаарлана. `final` field нь constructor-д нэг удаа оноогдоно. Санхүүгийн production тооцоонд `long`-ийг minor unit (жишээ нь цент) эсвэл `BigDecimal`-тай зохих бизнес дүрмээр сонго.

**Дасгал:** `InventoryItem` class-д `addStock`, `removeStock`, `getQuantity`; сөрөг үлдэгдэл зөвшөөрөхгүй. Public field болон private field-ийн ялгааг тайлбарла.

