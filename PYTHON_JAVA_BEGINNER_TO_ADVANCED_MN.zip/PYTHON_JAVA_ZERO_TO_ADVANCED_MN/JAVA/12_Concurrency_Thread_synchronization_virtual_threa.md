# JAVA — Module 12

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`JAVA_COMPLETE_GUIDE_MN.md`](../JAVA_COMPLETE_GUIDE_MN.md)

## 12. Concurrency: Thread, synchronization, virtual threads

`Thread` нь гүйцэтгэлийн урсгал; олон thread-ийн **shared mutable state** хамгаалалтгүй бол race condition. `synchronized` болон `java.util.concurrent` API-ууд нь зохицуулдаг. `virtual threads` JDK21+ дээр олон I/O waiting task-д тустай; CPU-heavy тооцоог ид шидээр хурдлуулахгүй.

```java
import java.util.concurrent.*;

public class VirtualThreadDemo {
    public static void main(String[] args) throws Exception {
        try (ExecutorService service = Executors.newVirtualThreadPerTaskExecutor()) {
            Future<Integer> a = service.submit(() -> 20 + 22);
            Future<Integer> b = service.submit(() -> 10 * 2);
            System.out.println(a.get() + b.get()); // 62
        }
    }
}
```

```java
import java.util.concurrent.atomic.AtomicInteger;

AtomicInteger counter = new AtomicInteger(0);
counter.incrementAndGet();  // atomic update
System.out.println(counter.get()); // 1
```

`AtomicInteger` кодыг method дотор хэрэглэ. `volatile` нь visibility-г сайжруулах боловч `counter++`-ийг atomic болгодоггүй. `CompletableFuture` нь async result composition-д хэрэглэгдэнэ. Thread pool-ийг хэт том болгох, blocking task-ийг мэдэлгүй хаях, exception буруу handle хийх нь нийтлэг алдаа.

**Дасгал:** 1000 increment-ийг concurrency-аар хийж, зөв count-г `AtomicInteger`-ээр баталгаажуул; `Future.get()` юу хүлээдэгийг тайлбарла.

