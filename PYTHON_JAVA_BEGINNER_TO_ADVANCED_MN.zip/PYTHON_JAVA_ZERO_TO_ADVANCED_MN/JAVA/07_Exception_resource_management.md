# JAVA — Module 07

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`JAVA_COMPLETE_GUIDE_MN.md`](../JAVA_COMPLETE_GUIDE_MN.md)

## 07. Exception болон resource management

`Exception` нь урсгалыг өөрчилж болох алдаа. `checked exception`-ийг компилятор handle/declare хийхийг шаарддаг (`IOException`); `unchecked` (`IllegalArgumentException`) нь runtime-д шалгагдана. Буруу exception-ийг зүгээр залгиж болохгүй.

```java
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;

public class ReadDemo {
    public static void main(String[] args) {
        try {
            String text = Files.readString(Path.of("notes.txt"));
            System.out.println(text);
        } catch (IOException ex) {
            System.err.println("Cannot read notes.txt: " + ex.getMessage());
        }
    }
}
```

`try-with-resources` нь `AutoCloseable` объектыг хаадаг, `finally` нь амжилт эсэхээс үл хамааран ажилладаг. Error-г хэвлэхдээ secret/token эсвэл sensitive path гарч болзошгүй эсэхийг анхаар.

```java
import java.io.BufferedReader;
import java.nio.file.Files;
import java.nio.file.Path;

try (BufferedReader reader = Files.newBufferedReader(Path.of("notes.txt"))) {
    System.out.println(reader.readLine());
}
// Энэ snippet-ийг method дотор хэрэглэж,
// IOException-г catch эсвэл throws IOException-аар зохицуулна.
```

**Дасгал:** Байхгүй файл уншихад ямар exception гарах вэ? JSON parse алдааг хэрхэн тусад нь handle хийх вэ (номын сан ашиглавал)? Хэзээ `finally` шаардлагатай вэ?

---
