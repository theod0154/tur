# JAVA — Module 04

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`JAVA_COMPLETE_GUIDE_MN.md`](../JAVA_COMPLETE_GUIDE_MN.md)

## 04. Methods, parameters, return, recursion

Method нь class дотор тодорхойлдог, давтан ашиглаж болох үйлдэл. `public/private` нь access modifier, `static` нь объект үүсгэхгүйгээр class-аар дуудах, `void` нь буцаах утгагүй гэсэн утгатай.

```java
public class Calculator {
    static int add(int a, int b) {
        return a + b;
    }

    static int factorial(int n) {
        if (n < 0) throw new IllegalArgumentException("negative n");
        if (n <= 1) return 1;      // base case
        return n * factorial(n - 1);
    }

    public static void main(String[] args) {
        System.out.println(add(2, 3));      // 5
        System.out.println(factorial(4));    // 24
    }
}
```

`recursion` нь method өөрийгөө дуудах. Base case байхгүй бол `StackOverflowError`, хэт өндөр `n` бол `int` overflow болно. Java-ийн primitive аргумент утгаар дамжина; object reference **өөрөө** мөн утгаар дамжина (Java бол pass-by-value).

**Дасгал:** `isEven(int n)`, `max(int[] a)`, `isPrime(int n)` methods бич. 0, 1, сөрөг тооны edge case шалга.

