# JAVA — Module 01

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`JAVA_COMPLETE_GUIDE_MN.md`](../JAVA_COMPLETE_GUIDE_MN.md)

## 01. Java гэж юу вэ? JDK, JVM ба анхны код

Java нь статик type шалгадаг, олон платформд ажиллах ecosystem бүхий програмчлалын хэл. **JDK** (Java Development Kit) дотор compiler `javac` болон `java` launcher орно. **JVM** (Java Virtual Machine) нь compiled bytecode ажиллуулна. `.java` нь source; `.class` нь байткод.

```bash
java -version       # Java runtime хувилбар
javac -version      # Compiler хувилбар
```

`Hello.java` үүсгэ:

```java
public class Hello {
    public static void main(String[] args) {
        System.out.println("Sain baina uu, Java!");
    }
}
```

```bash
javac Hello.java
java Hello
```

```text
Sain baina uu, Java!
```

**Код унших:** `class Hello` = class нэр, `main` = application entry point, `System.out.println` = console дээр мөр хэвлэх, `;` = statement дууслаа. `public class`-ийн нэр болон файлын нэр ижил байх ёстой. `java Hello` гэж ажиллуулахдаа `.class` нэмэхгүй.

**Алдаа:** `javac: command not found` бол JDK PATH тохируулаагүй; `Could not find or load main class` бол хавтас/classpath, class нэрийг шалга; `';' expected` бол төгсгөлийн `;` алга.

**Дасгал:** Нэр, нас, сурч буй хэлээ хэвлэ. `javac`-ийн үүрэг `java`-гаас ямар ялгаатай вэ?

