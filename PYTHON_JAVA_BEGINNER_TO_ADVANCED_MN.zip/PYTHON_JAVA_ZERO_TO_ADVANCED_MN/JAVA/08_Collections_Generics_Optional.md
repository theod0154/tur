# JAVA — Module 08

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`JAVA_COMPLETE_GUIDE_MN.md`](../JAVA_COMPLETE_GUIDE_MN.md)

## 08. Collections, Generics, Optional

`ArrayList` нь динамик list, `HashSet` нь давхардалгүй element, `HashMap` нь key/value, `Deque` нь queue/stack маягийн бүтэц. `Generics<T>` нь type-safe collection болон reusable method/class бичихэд тусалдаг.

```java
import java.util.*;

public class CollectionDemo {
    public static void main(String[] args) {
        List<String> hosts = new ArrayList<>();
        hosts.add("web01");
        hosts.add("db01");
        hosts.add("web01");
        System.out.println(hosts.size()); // 3
        Set<String> unique = new HashSet<>(hosts);
        System.out.println(unique.size()); // 2
        Map<String, Integer> counts = new HashMap<>();
        counts.put("up", 3);
        System.out.println(counts.getOrDefault("down", 0)); // 0
    }
}
```

`HashMap` ба `HashSet`-ийн iteration order баталгаагүй; insertion order хэрэгтэй үед `LinkedHashMap`/`LinkedHashSet`; sorted order хэрэгтэй бол `TreeMap`/`TreeSet`.

```java
import java.util.Optional;

public class OptionalDemo {
    static Optional<String> getOwner(boolean known) {
        return known ? Optional.of("IT") : Optional.empty();
    }
    public static void main(String[] args) {
        System.out.println(getOwner(false).orElse("unassigned")); // unassigned
    }
}
```

`Optional.get()`-ийг нөхцөлгүй дуудаж болохгүй; `orElse`, `orElseGet`, `ifPresent` ашигла. `List<String>` нь `List<Object>`-ийн subtype биш (invariance); `? extends T` нь read producer, `? super T` нь consumer-д тохирох *PECS* дүрмийг судал.

**Дасгал:** Хамгийн олон давтагдсан hostname ол; inventory-д hostname→owner map үүсгэ; Generic `Pair<A,B>` record зохио.

