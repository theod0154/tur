# JAVA — Module 13

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`JAVA_COMPLETE_GUIDE_MN.md`](../JAVA_COMPLETE_GUIDE_MN.md)

## 13. JDBC, SQL, transaction

`JDBC` (Java Database Connectivity) нь Java application-аас SQL database-тай холбогдох API. Энэ бүлгийн код **архитектурын жишээ**: бодит DB ажиллуулах шаардлагагүй. SQL Injection-ээс хамгаалахдаа query syntax ба user-provided value-г салгах `PreparedStatement` хэрэглэ.

```java
import java.sql.*;

public class UserRepository {
    public static String findEmail(Connection db, String username) throws SQLException {
        String sql = "SELECT email FROM users WHERE username = ?";
        try (PreparedStatement stmt = db.prepareStatement(sql)) {
            stmt.setString(1, username); // value binding (SQL string concatenation биш)
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() ? rs.getString("email") : null;
            }
        }
    }
}
```

`Connection` нь application-ийн trusted component-аас ирнэ; DB credentials-ийг source-д hardcode хийхгүй. `?` нь table/column name-ийн placeholder биш, зөвхөн value-binding-д зориулагдсан. Dynamic identifier хэрэгтэй бол **allowlist** ашигла.

**Transaction:** Бүтэн үйлдэл бүгд амжилттай бол `commit`, аль нэг нь амжилтгүй бол `rollback`. `setAutoCommit(false)`-ийг зориудаар ашиглахдаа connection lifecycle-г удирд; нууц мэдээлэл log-д бичихгүй.

**Дасгал:** `WHERE id = ? AND owner_id = ?` загварын **object-level authorization** шалгалт яагаад зөвхөн `WHERE id = ?`-ээс илүү хамгаалалттайг тайлбарла. SQL schema-д `UNIQUE`, `NOT NULL` аль нь ямар validation хийдэгийг нэрлэ.

