# JAVA — Module 11

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`JAVA_COMPLETE_GUIDE_MN.md`](../JAVA_COMPLETE_GUIDE_MN.md)

## 11. Build tools, Maven, JUnit testing

Том төсөлд гар аргаар `javac` хийхэд dependency хэцүү. `Maven` нь build/dependency management; `pom.xml` project metadata; `JUnit` бол test framework. `Gradle` нь өөр build сонголт — нэгийг гүнзгий эзэмшээд нөгөөгийн үндсийг сур.

```text
my-app/
  pom.xml
  src/main/java/org/example/Calculator.java
  src/test/java/org/example/CalculatorTest.java
```

`pom.xml`-ийн минимал жишээ (Maven/JUnit суулгаж, dependency татаж ашиглах үед интернет шаардаж болно; localhost server хэрэггүй):

```xml
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <groupId>org.example</groupId>
  <artifactId>my-app</artifactId>
  <version>1.0-SNAPSHOT</version>
  <properties><maven.compiler.release>21</maven.compiler.release></properties>
  <dependencies>
    <dependency>
      <groupId>org.junit.jupiter</groupId>
      <artifactId>junit-jupiter</artifactId>
      <version>5.11.4</version>
      <scope>test</scope>
    </dependency>
  </dependencies>
  <build><plugins>
    <plugin>
      <groupId>org.apache.maven.plugins</groupId>
      <artifactId>maven-surefire-plugin</artifactId>
      <version>3.5.2</version>
    </plugin>
  </plugins></build>
</project>
```

> Dependency version нь суралцах үеийн **жишээ version**; ашиглахаасаа өмнө албан сайт/байгууллагын approved release-ийг шалга. Заавал latest гэж үзэхгүй.

```java
// src/main/java/org/example/Calculator.java
package org.example;
public class Calculator {
    public static int add(int a, int b) { return Math.addExact(a, b); }
}
```

```java
// src/test/java/org/example/CalculatorTest.java
package org.example;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class CalculatorTest {
    @Test void addsNumbers() { assertEquals(5, Calculator.add(2, 3)); }
    @Test void detectsOverflow() {
        assertThrows(ArithmeticException.class,
            () -> Calculator.add(Integer.MAX_VALUE, 1));
    }
}
```

```bash
mvn test      # Тест ажиллуулна
mvn package   # Build + тест, artifact үүсгэнэ
```

`mvn test` ажиллахгүй бол Maven суулгасан эсэх (`mvn -version`), Java version, интернет/dependency, зөв folder-т ажиллаж байгаа эсэхийг шалга. `mvn -q test` нь гаралтыг богиносгоно; debugging хийхдээ `-q`-г хас.

**Дасгал:** `subtract` method нэм; negative case-ууд тестлэ; тестийг зориудаар унагаж build failure-г ажигла.

