# JAVA — Module 06

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`JAVA_COMPLETE_GUIDE_MN.md`](../JAVA_COMPLETE_GUIDE_MN.md)

## 06. Inheritance, interface, polymorphism, record, enum

`Inheritance` = child class parent class-ийн боломжийг өвлөнө (`extends`). `Interface` = ямар үйлдэл хэрэгжүүлэх гэрээ (`implements`). `Polymorphism` = нэг interface-ээр олон төрлийн объекттой ажиллах. **Composition**-ийг inherit-ээс түрүүнд бодолц, ялангуяа "has-a" харилцаанд.

```java
interface Notifier {
    void send(String message);
}

class ConsoleNotifier implements Notifier {
    @Override
    public void send(String message) {
        System.out.println("NOTICE: " + message);
    }
}

public class NotifyDemo {
    static void notifyUser(Notifier notifier, String text) {
        notifier.send(text);
    }

    public static void main(String[] args) {
        notifyUser(new ConsoleNotifier(), "Ready"); // NOTICE: Ready
    }
}
```

**Record:** data-carrier class-ийг товч бичнэ; `record` shallow immutability-тай (доторх mutable object өөрчлөгдөж болно).

```java
record Finding(String title, int severity) {
    Finding {
        if (severity < 1 || severity > 5) throw new IllegalArgumentException();
    }
}
enum State { OPEN, CLOSED }
```

`sealed` class/interface нь хэн өвлөж болохыг хязгаарладаг; `record` болон `enum`-ийг JDK21+ дээр ашиглаж болно. Java-ийн `interface` дээр `default` method байж болно.

**Дасгал:** `Shape` interface + `Rectangle` ба `Circle` хэрэгжүүл; `area()`-г polymorphism-аар дуудах; `record Asset(String host, String owner)` үүсгэ.

