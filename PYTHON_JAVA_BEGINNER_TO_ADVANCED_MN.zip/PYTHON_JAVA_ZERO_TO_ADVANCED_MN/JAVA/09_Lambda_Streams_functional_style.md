# JAVA — Module 09

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`JAVA_COMPLETE_GUIDE_MN.md`](../JAVA_COMPLETE_GUIDE_MN.md)

## 09. Lambda, Streams, functional style

`lambda` бол function-like inline expression; `Stream` нь collection-оор pipeline боловсруулна: `filter`, `map`, `sorted`, `collect`. Stream-ийг нэг удаа хэрэглэнэ; шаардлагагүй mutable side effect хийхгүй.

```java
import java.util.List;

public class StreamDemo {
    public static void main(String[] args) {
        List<Integer> nums = List.of(1, 2, 3, 4, 5);
        List<Integer> squares = nums.stream()
                .filter(n -> n % 2 == 0)
                .map(n -> n * n)
                .toList();
        System.out.println(squares); // [4, 16]
    }
}
```

`stream()` өөрөө эх өгөгдлийг өөрчилдөггүй. `toList()`-ийн буцаасан жагсаалт unmodifiable; элемент нэмэх шаардлагатай бол шинэ `ArrayList<>(...)` үүсгэ. Parallel stream хурдан гэсэн баталгаа биш; CPU, dataset, ordering болон side effect бодолц.

```java
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

var hosts = List.of("web01", "db01", "web01");
Map<String, Long> count = hosts.stream()
        .collect(Collectors.groupingBy(s -> s, Collectors.counting()));
System.out.println(count.get("web01")); // 2
```

Энэ snippet-ийг method дотор байрлуул. `var` бол local variable type inference, dynamic type биш.

**Дасгал:** Asset-ийн status=`down` мөрүүдийг filter хий; `groupingBy`-аар department тоол; Loop хувилбар ба Stream хувилбарын уншигдах байдлыг харьцуул.

