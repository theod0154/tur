# JAVA — Module 15

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`JAVA_COMPLETE_GUIDE_MN.md`](../JAVA_COMPLETE_GUIDE_MN.md)

## 15. Secure Coding, Source Code Review, capstone

**Secure review checklist:** input validation, authentication vs authorization, SQL parameters, deserialization, path handling, secrets, logging, dependency integrity, exception handling, concurrency invariants.

```java
// АЮУЛТАЙ ХЭВ МАЯГ: SQL утгыг string concatenation хийх
// String sql = "SELECT * FROM users WHERE name='" + name + "'";

// ЗӨВ: PreparedStatement + parameter binding (13-р бүлэг)
```

```java
// Bad: Path.of(base, untrustedFileName)-ийг шууд унших.
// Better: зөвшөөрөгдсөн нэр, base directory restriction,
// canonicalization, symbolic-link policy-г тус тусад нь хэрэгжүүлэх.
```

**Project J1 — Student Grade Manager (Beginner):** console input, `List<Student>`, grade rules, average, validation, `Scanner` ашиглана. Сөрөг оноо эсвэл 100-аас их оноог буцаана. `record Student(String name, int score)` + validation туршаад үз.

**Project J2 — Asset Inventory CLI (Intermediate):** `Map<String,Asset>`, search, add, remove, CSV export, exception handling; JUnit tests (8+), Maven build. Демо өгөгдөл л хэрэглэнэ.

**Project J3 — Offline Source Code Review Assistant (Advanced):** Java source-оос `Runtime.getRuntime().exec`, `Statement.execute`, `ObjectInputStream`, `Files.readString` зэрэг *эрсдэлийн pattern*-ийг хайж output гаргана; энэ нь **heuristic** төдий. AST эсвэл CodeQL/Semgrep мэт semantic analysis-тай харьцуул; false-positive/false-negative 3 жишээ гарга. Тухайн кодыг ажиллуулах, exploit хийх шаардлагагүй.

**Сайн инженерийн шалгуур:**
- Modular design, clear types, encapsulation, tests, meaningful errors, README.
- `mvn test` ажилладаг, build reproducible, dependencies удирдлагатай.
- SQL parameterization, input validation, secrets handling, no sensitive logs.
- Time/space complexity ба thread safety-д тайлбар өгч чаддаг.
- Review дээр таамгийг *confirmed vulnerability* гэж дүгнэдэггүй.

### Java self-assessment

| Түвшин | Чадварын шалгуур |
|---|---|
| Beginner | Class, variables, `if`, loop, arrays, methods ашиглан энгийн console програм бие даан бичдэг |
| Intermediate | OOP, interfaces, collections, exceptions, files, JUnit/Maven ашиглан төсөл хөгжүүлдэг |
| Advanced-oriented | Generics/Streams, concurrency tradeoffs, JVM diagnostics, clean architecture, secure coding, unit/integration tests-г тайлбарлаж хэрэглэдэг |

### Java албан эх сурвалж
- Modern Java learning — https://dev.java/learn/
- Your first Java application — https://dev.java/learn/first-steps/
- JDK APIs — https://docs.oracle.com/en/java/javase/25/docs/api/
- Java secure coding guidelines — https://www.oracle.com/java/technologies/javase/seccodeguide.html
- Maven introduction — https://maven.apache.org/guides/getting-started/
- JUnit user guide — https://docs.junit.org/current/user-guide/

> **Төгсгөл:** Java дээр Advanced болох нь framework нэрс цээжлэх биш. Зохион байгуулалттай application бүтээх, bug оношлох, тестээр баталгаажуулах, гүйцэтгэл хэмжих, аюулгүй код бичих чадвар юм.
