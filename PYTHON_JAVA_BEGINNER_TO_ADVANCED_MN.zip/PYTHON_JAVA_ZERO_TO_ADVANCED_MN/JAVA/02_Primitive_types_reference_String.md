# JAVA — Module 02

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`JAVA_COMPLETE_GUIDE_MN.md`](../JAVA_COMPLETE_GUIDE_MN.md)

## 02. Primitive types, reference, String

Java-ийн **primitive**: `byte`, `short`, `int`, `long`, `float`, `double`, `char`, `boolean`. Object type: `String`, `Integer`, `List` гэх мэт **reference**-ээр хандана. Type нь compile-time дээр шалгагдана.

```java
public class TypesDemo {
    public static void main(String[] args) {
        int count = 10;
        double price = 19.5;
        boolean active = true;
        String owner = "Anu";
        System.out.println(owner + ": " + (count * price));
        System.out.println(7 / 2);     // 3: бүхэл тоон хуваалт
        System.out.println(7.0 / 2);   // 3.5
    }
}
```

`String` нь immutable; текстийн **утга** тэнцүүг `.equals()`-аар харьцуул, `==` нь reference equality-г шалгадаг.

```java
String a = new String("hello");
String b = new String("hello");
System.out.println(a.equals(b)); // true
System.out.println(a == b);      // false
```

Энэ snippet-ийг `main` дотор байрлуул. `null` объект биш; `obj.method()` гэж `null` дээр дуудах үед `NullPointerException`. Мөнгөний дүн, нарийн аравтын тоонд `BigDecimal` хэрэглэх талаар дараа нь үз.

**Дасгал:** String-н уртыг `.length()`-ээр хэвлэ; `==` vs `.equals` зөрүүг өөрийн үгээр тайлбарла; `int`-ээс `double` рүү хөрвүүлэх код бич.

