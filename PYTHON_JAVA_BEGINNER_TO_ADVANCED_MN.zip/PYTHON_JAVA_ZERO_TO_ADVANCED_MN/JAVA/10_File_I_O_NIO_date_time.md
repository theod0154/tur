# JAVA — Module 10

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`JAVA_COMPLETE_GUIDE_MN.md`](../JAVA_COMPLETE_GUIDE_MN.md)

## 10. File I/O, NIO, date/time

`java.nio.file.Path` нь файл зам, `Files` нь унших/бичих API; `java.time` нь өдөр/цагийн modern immutable API. `LocalDateTime` нь timezone агуулахгүй, `Instant` нь timeline цэг, `ZonedDateTime` timezone rule-тэй.

```java
import java.nio.file.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class FileDemo {
    public static void main(String[] args) throws IOException {
        Path p = Path.of("report.txt");
        Files.writeString(p, "host,status\nweb01,up\n", StandardCharsets.UTF_8);
        String value = Files.readString(p, StandardCharsets.UTF_8);
        System.out.print(value);
    }
}
```

```java
import java.time.*;
import java.time.format.DateTimeFormatter;

public class TimeDemo {
    public static void main(String[] args) {
        LocalDate d = LocalDate.of(2026, 11, 20);
        System.out.println(d.plusDays(7)); // 2026-11-27
        Instant now = Instant.now();
        System.out.println(now.isBefore(now.plusSeconds(1))); // true
    }
}
```

Найдвартай лог, audit-т `Instant` хадгалах, UI дээр хэрэглэгчийн timezone-аар хөрвүүлэх нь түгээмэл. File path-д user input оруулахдаа canonical path validation болон зөвшөөрөгдсөн directory boundary-г шалга.

**Дасгал:** `assets.txt` уншаад мөр бүрийн тоог тоол; системийн цаг хэрэглэж filename үүсгэхдээ зөв format ашигла; UTF-8 encoding алдааг тайлбарла.

