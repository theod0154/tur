# JAVA — Module 03

> Шаталсан сургалтын хэсэг. Бүрэн гарын авлага: [`JAVA_COMPLETE_GUIDE_MN.md`](../JAVA_COMPLETE_GUIDE_MN.md)

## 03. `if`, `switch`, `for`, `while`, arrays

```java
public class ControlFlow {
    public static void main(String[] args) {
        int score = 85;
        String grade = score >= 90 ? "A" : (score >= 70 ? "B" : "C");
        System.out.println(grade); // B

        int[] nums = {2, 4, 6};
        for (int n : nums) {
            System.out.println(n);
        }
    }
}
```

`int[] nums` нь array; хэмжээ нь тогтмол. `nums[0]` эхний элемент; `nums.length` хэмжээ (method биш). `for-each` нь бүх элементээр давтана; индекс хэрэгтэй бол `for (int i = 0; i < nums.length; i++)`.

```java
String status = "up";
String message = switch (status) {
    case "up" -> "OK";
    case "down" -> "ALERT";
    default -> "UNKNOWN";
};
System.out.println(message); // OK
```

`switch expression`-д бүх боломжийг хамруулах шаардлагатай (`default` эсвэл exhaustive cases). Давталтын нөхцөл буруу бол infinite loop үүсч болно.

**Дасгал:** 1–50 хүртэл 5-д хуваагдах тоонуудыг хэвлэ; 5 тооны max ол; өдөрт тохирсон `switch` message зохио.

