# PYTHON — Beginner → Advanced | Монгол хэл дээрх практик сургалтын гарын авлага

> **Зорилго:** Хэзээ ч код бичиж байгаагүй хүн Python-оор асуудал шийдэж, цэвэр код бичиж, тест хийж, автоматжуулалт болон source-code security review хийх суурьтай болох.
>
> **Орчин:** Python 3.13+ (жишээнүүд Python 3.13 дээр шалгахад зориулагдсан), VS Code эсвэл дурын editor, Terminal. **Localhost web lab, server, Docker шаардлагагүй.**
>
> **Суралцах дүрэм:** Бэлэн кодыг унших → өөрөө шивж ажиллуулах → нэг мөрийг өөрчилж үр дүнг таамаглах → дасгалыг эхлээд тусламжгүй хийх → зөв хариутай тулгах.

## Агуулга
1. Компьютер программ гэж юу вэ? Python суулгах, эхний код
2. Variable, type, operator, conversion
3. `if`, `for`, `while` — нөхцөл ба давталт
4. `list`, `tuple`, `dict`, `set` — өгөгдлийн бүтэц
5. Function, scope, аргумент, код задлах
6. File I/O, JSON, CSV, exception
7. Module, package, `venv`, `pip`, CLI
8. OOP, class, dataclass, composition
9. Comprehension, iterator, generator
10. Decorator, context manager, typing
11. Unit test, logging, debugging
12. Algorithms, Big-O, стандарт сан
13. Threading, multiprocessing, `asyncio`
14. Secure coding, code review, quality
15. Төгсгөлийн төслүүд ба чадварын үнэлгээ

---

## 01. Программчлалын үндэс ба анхны Python код

**Тайлбар.** Программ гэдэг нь компьютерт алхамчилсан заавар өгсөн текст. `source code` нь таны бичсэн код, `interpreter` нь түүнийг ажиллуулдаг програм, `terminal` нь текст команд оруулах орчин. Алдаа гарахыг `bug`, алдаа олохыг `debugging` гэдэг.

**Суулгах:** Python-ыг https://www.python.org/downloads/ хуудаснаас ав. Windows дээр Python launcher ашиглавал `py`, Linux/macOS дээр `python3` түгээмэл. Суулгасан хувилбарыг шалгах:

```powershell
py --version
py -c "print('Sain baina uu, Python!')"
```

Linux/macOS:

```bash
python3 --version
python3 -c "print('Sain baina uu, Python!')"
```

`--version`: хувилбар харуулна; `-c`: богино кодыг шууд ажиллуулна. Боломжит гаралт: `Python 3.13.x`, дараа нь `Sain baina uu, Python!`. `py` олдохгүй бол Windows PATH эсвэл Python launcher суусан эсэхийг шалга. `python3` олдохгүй бол Python суулгасан эсэхээ шалга.

`hello.py` файл үүсгэ:

```python
name = "Anu"             # Текст утга (str)
print("Sain uu,", name)   # print() дэлгэцэнд бичнэ
print(2 + 3)              # Тооцоолол
```

```text
Sain uu, Anu
5
```

**Гол зарчим:** Python-ийн `indentation` (мөрийн эхний зай) нь кодын бүтцийг тодорхойлдог. Таб болон зайг санамсаргүй хольж болохгүй; ердийн стандарт нь 4 зай.

**Дасгал:** (1) Өөрийн нэр, сурч буй хэлийг хэвлэ. (2) 3 тооны нийлбэрийг хэвлэ. (3) `print(5 / 2)` ба `print(5 // 2)`-ын зөрүүг ажигла.

**Шалгах:** Та `.py` файл үүсгээд ажиллуулж чаддаг уу? `SyntaxError` болон `NameError` хоёрын утгыг ялгаж чаддаг уу?

## 02. Variable, type, operator

Python-ийн хувьсагч бол утгад өгсөн *нэр*. `int` бүхэл тоо, `float` бутархай, `str` текст, `bool` логик (`True`/`False`), `None` утгагүйг илэрхийлнэ.

```python
age = 22
price = 19.9
name = "Bataa"
is_active = True
unknown = None
print(type(age).__name__)      # int
print(f"{name}: {age} nastai") # f-string
print(7 / 2, 7 // 2, 7 % 2)  # 3.5 3 1
```

`=` бол утга оноох, `==` тэнцүү эсэхийг шалгах, `!=` ялгаатай, `and/or/not` логик оператор. `is` нь **ижил объект** эсэх, `==` нь **утга тэнцүү** эсэхийг шалгана. `input()` үргэлж `str` буцаана; тоо болгохын өмнө алдааг бодолц.

```python
raw = "15000"
amount = int(raw)           # str → int
vat = amount * 0.10
print(f"VAT: {vat:.2f}")  # VAT: 1500.00
```

**Алдаа:** `"10" + 5` нь `TypeError`; `int("abc")` нь `ValueError`. Мөнгөний нарийн тооцоонд binary `float` бус `decimal.Decimal` хэрэглэх нь зөв.

**Дасгал:** НӨАТ-тай үнийг тооц. 200,000₮-ийн 15% хөнгөлөлт хэд вэ? `is` ба `==` яагаад өөр вэ гэдгийг өөрийн үгээр тайлбарла.

## 03. Нөхцөл ба давталт

`if/elif/else` шийдвэр гаргана; `for` нь iterable доторх зүйлсээр давтана; `while` нь нөхцөл үнэн байх хугацаанд үргэлжилнэ.

```python
score = 78
if score >= 90:
    grade = "A"
elif score >= 70:
    grade = "B"
else:
    grade = "C"
print(grade)  # B

for number in range(1, 4):
    print(number)
# 1, 2, 3 (тус тусдаа мөр)
```

```python
attempts = 0
while attempts < 3:
    attempts += 1
    if attempts == 2:
        continue       # энэ давталтын үлдсэн хэсгийг алгасна
    print(attempts)
# 1, 3
```

`range(1, 4)` нь 1-ээс эхлээд 4-ийг *оруулахгүй*. `break` давталтыг зогсооно. `while True` ашиглахдаа заавал гарах нөхцөл төлөвлө.

**Дасгал:** (1) 1–100 хүртэл 3-т хуваагдах тоонуудын нийлбэр. (2) Анхны тоо эсэхийг шалгах. (3) Өгөгдсөн жагсаалтаас зөвхөн тэгш тоо хэвлэх.

**Шалгах:** `if` нөхцөл `False` үед аль мөрүүд ажиллах вэ? `for` ба `while`-г хэзээ сонгох вэ?

## 04. Өгөгдлийн бүтэц: list, tuple, dict, set

| Type | Зориулалт | Өөрчилж болох уу? | Давхардал |
|---|---|---|---|
| `list` | Дараалал | Тийм | Болно |
| `tuple` | Тогтвортой дараалал | Үгүй | Болно |
| `dict` | Key → Value | Тийм | Key давхардахгүй |
| `set` | Давхардалгүй элементүүд | Тийм | Болохгүй |

```python
servers = ["web01", "db01", "web01"]
servers.append("api01")
print(servers[0], servers[-1]) # web01 api01
print(set(servers))            # дараалал нь баталгаагүй

asset = {"hostname": "web01", "status": "up", "ports": [443]}
asset["owner"] = "IT"
print(asset.get("ip", "not set")) # not set
for key, value in asset.items():
    print(key, value)
```

`list`-ийн index 0-ээс эхэлнэ. `dict["missing"]` байхгүй key дээр `KeyError`, харин `.get()` default буцааж болно. `set`-ийн хэвлэх дараалал тогтмол биш.

**List comprehension:**

```python
numbers = [1, 2, 3, 4, 5]
evens_squared = [n * n for n in numbers if n % 2 == 0]
print(evens_squared)  # [4, 16]
```

**Дасгал:** (1) Давхардсан hostname-ийг арилга. (2) `[{"name":..., "age":...}]` дундаас 18+ хүмүүсийг ол. (3) Нэг өгүүлбэрийн үгийн давтамжийг `dict`-ээр тоол.

## 05. Function ба scope

`function` нь давтан ашиглах үйлдлийг нэрлэдэг. `parameter` нь function тодорхойлох үеийн хувьсагч, `argument` нь дуудах үед дамжуулах утга. `return` үр дүнг буцаана (`print`-ээс өөр).

```python
def discount(price: float, percent: float = 10) -> float:
    """Үнэний хөнгөлөлт тооцох; percent 0–100 дотор байна."""
    if not 0 <= percent <= 100:
        raise ValueError("percent must be 0..100")
    return price * (1 - percent / 100)

print(discount(200, 15))          # 170.0
print(discount(price=100))       # 90.0
```

Python-д `local scope` нь function дотор; outer нэрийг өөрчлөхдөө `global`-д хэт найдахгүй, утга буцаадаг загвар сонго. **Mutable default argument** нь нийтлэг bug:

```python
# БУРУУ: нэг list бүх дуудлагад хадгалагдана
# def add(item, items=[]): ...

def add(item, items=None):
    if items is None:
        items = []
    items.append(item)
    return items
```

**Дасгал:** (1) `is_prime(n)` хэрэгжүүл. (2) `average(numbers)` хоосон list-д юу хийхийг тодорхойл. (3) Нэг том кодыг гурван тусдаа function болгон задла.

## 06. File I/O, JSON, CSV, exception

`I/O` (Input/Output) гэдэг нь файл унших, бичих зэрэг оролт/гаралт. `with` нь файл хаахыг найдвартай удирдана. `pathlib.Path` нь OS-оос хамаарал багатай замын API.

```python
from pathlib import Path
import json

path = Path("assets.json")
assets = [{"host": "web01", "critical": True}, {"host": "db01", "critical": False}]
path.write_text(json.dumps(assets, ensure_ascii=False, indent=2), encoding="utf-8")
loaded = json.loads(path.read_text(encoding="utf-8"))
print(len(loaded), loaded[0]["host"])  # 2 web01
```

```python
import csv
from pathlib import Path

with Path("report.csv").open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["host", "status"])
    writer.writeheader()
    writer.writerow({"host": "web01", "status": "up"})

with Path("report.csv").open(newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        print(row["host"], row["status"])  # web01 up
```

**Exception handling:**

```python
try:
    value = int("12")
except ValueError as exc:
    print("Тоон утга буруу:", exc)
else:
    print(value)  # 12
finally:
    print("Дууслаа")
```

`except Exception: pass` гэж алдаа залгиж болохгүй. `FileNotFoundError`, `PermissionError`, `UnicodeDecodeError` зэрэг **онцлог алдааг** тусад нь барь. Файлтай ажиллахдаа нууц token, password логт бичихгүй.

**Дасгал:** (1) CSV-ээс status=`down` мөрүүдийг шүүнэ. (2) JSON унших үед файл байхгүй болон JSON эвдэрсэн хоёр нөхцөлийг ялга. (3) Тайланг UTF-8 текст файлд бич.

## 07. Module, package, `venv`, `pip`, CLI

`module` = нэг `.py` файл; `package` = зохион байгуулалттай modules; `pip` = Python package installer; `venv` = тусгаарласан Python орчин. Төслийн dependency-г үндсэн OS Python-д хольж суулгахгүй.

```bash
python3 -m venv .venv        # шинэ virtual environment үүсгэнэ
source .venv/bin/activate   # Linux/macOS дээр идэвхжүүлнэ
python -m pip --version     # энэ Python-ийн pip-г шалгана
```

Windows PowerShell:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip --version
```

`deactivate` нь environment-ээс гарна. `.venv/`-ийг Git-д commit хийхгүй. `python -m pip` нь яг аль interpreter-тай package холбоотойг тодорхой болгодог.

```python
# math_utils.py
def total(items):
    return sum(items)

# main.py
import argparse
from math_utils import total

parser = argparse.ArgumentParser(description="Sum numbers")
parser.add_argument("numbers", nargs="+", type=float)
args = parser.parse_args()
print(total(args.numbers))
```

`python main.py 2 3 4` → `9.0`. `nargs="+"`: дор хаяж нэг argument; `type=float`: тоо болгон хөрвүүлнэ. Алдаатай оролтод `argparse` туслах тайлбар хэвлэнэ. `--help`-ээр CLI тайлбар харах.

**Дасгал:** 2 module-тэй өөрийн CLI calculator хий; `--help`-ийг тохируул; оролтыг алдаатай өгөөд ямар error гарахыг ажигла.

---
## 08. Object-Oriented Programming (OOP)

`OOP` нь өгөгдөл болон түүнийг боловсруулах аргыг нэг объектод нэгтгэх загвар. `class` = загвар, `object` = тэр загвараас бүтээгдсэн бодит утга, `attribute` = шинж, `method` = үйлдэл. `self` нь одоогийн объект. `__init__` нь объект үүсэх үед анхны утга оноодог.

```python
class BankAccount:
    def __init__(self, owner: str, balance: int = 0):
        if balance < 0:
            raise ValueError("opening balance cannot be negative")
        self.owner = owner
        self._balance = balance

    @property
    def balance(self) -> int:
        return self._balance

    def deposit(self, amount: int) -> None:
        if amount <= 0:
            raise ValueError("amount must be positive")
        self._balance += amount

account = BankAccount("Anu", 100)
account.deposit(50)
print(account.balance)  # 150
```

`_balance` нь Python convention-оор *internal* гэдгийг илтгэнэ, бодитоор private болгохгүй. `@property` нь уншихыг зөвшөөрөөд шууд солих боломжийг хязгаарлах interface; immutable object шаардлагатай бол `@dataclass(frozen=True)`.

```python
from dataclasses import dataclass

@dataclass(frozen=True)
class Asset:
    hostname: str
    owner: str

print(Asset("web01", "IT"))
# Asset(hostname='web01', owner='IT')
```

`Inheritance` (өвлөх) нь "is-a" харилцаанд, `composition` (объект дотроо өөр объект агуулдаг) нь "has-a" харилцаанд тохирдог. Давхар удамшлын төвөгтэй загварыг эхэндээ хэрэглэхгүй; composition-ийг түрүүнд бодолц.

**Дасгал:** `InventoryItem` class бич; тоо ширхэгийг сөрөг болгож болохгүй; `add_stock` ба `remove_stock` методтой болго; гурван test case гарга.

## 09. Iterable, iterator, generator

`iterable` нь давтаж болох (`list`, `str`, `dict`); `iterator` нь дараагийн элементийг `next()`-ээр өгдөг; `generator` нь бүх үр дүнг нэг дор RAM-д хадгалахгүй, шаардлагатай үедээ (`yield`) үүсгэдэг.

```python
def squares(limit: int):
    for n in range(limit):
        yield n * n

for value in squares(4):
    print(value)
# 0, 1, 4, 9 (тусдаа мөр)
```

```python
records = [
    {"host": "a", "status": "up"},
    {"host": "b", "status": "down"},
]
down_hosts = (r["host"] for r in records if r["status"] == "down")
print(list(down_hosts))  # ['b']
```

Generator **нэг удаа зарцуулагдана**. `list(generator)` нэг удаа уншсаны дараа дахин уншихад хоосон байж болно. File line streaming-д хэрэгтэй: `for line in file:`.

**Дасгал:** Маш олон тоог RAM-д бүхэлд нь хадгалахгүйгээр тэгшийг нь дараалан өгдөг generator бич. `list` ба `generator` санах ойг хэрхэн ялгаатай ашиглахыг тайлбарла.

## 10. Decorator, context manager, type hints

`decorator` нь function-ийг гаднаас нь чимж нэмэлт ажил хийдэг. `context manager` нь ресурс нээх/хаах амьдралын мөчлөгийг хариуцна. Type hints нь алдааг эрт илрүүлэхэд тустай боловч Python runtime дээр автоматаар type validation хийхгүй.

```python
from functools import wraps

def trace(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        print("calling", fn.__name__)
        return fn(*args, **kwargs)
    return wrapper

@trace
def double(x: int) -> int:
    return x * 2

print(double(3))
# calling double
# 6
```

```python
from contextlib import contextmanager

@contextmanager
def audit_step(label: str):
    print("START", label)
    try:
        yield
    finally:
        print("END", label)

with audit_step("parse"):
    print("reading...")
# START parse / reading... / END parse
```

**Typing:** `list[str]` тэмдэглэгээ, `str | None` option, `Protocol` (behavior-based interface), `TypedDict` (dict-ийн бүтэц), `Generic[T]`-ийг дараалж сур. Static check-д `mypy` эсвэл `pyright` ашиглаж болно; хэрэв суулгах бол virtual environment-д суулга.

```python
from typing import TypedDict

class Finding(TypedDict):
    title: str
    severity: str

f: Finding = {"title": "Missing check", "severity": "medium"}
```

**Дасгал:** Функц ажиллах хугацааг (зөвхөн duration) хэвлэдэг `@timer` decorator хий. Нууц утга, function argument-уудыг санамсаргүй логд бичихгүй.

## 11. Testing, logging, debugging

`unit test` нь жижиг нэгжийг шалгана; `integration test` нь хэд хэдэн бүрэлдэхүүнийг хамтад нь шалгана. `assert` нь тест дотор хүлээгдэж буй нөхцөл; application validation-д `assert` биш `raise ValueError` зэрэг шалгалт хэрэглэ (optimization горимд assert хасагдаж болно).

```python
# calculator.py
def divide(a: float, b: float) -> float:
    if b == 0:
        raise ValueError("division by zero")
    return a / b

# test_calculator.py
import unittest
from calculator import divide

class DivideTests(unittest.TestCase):
    def test_normal(self):
        self.assertEqual(divide(8, 2), 4)

    def test_zero(self):
        with self.assertRaises(ValueError):
            divide(8, 0)

if __name__ == "__main__":
    unittest.main()
```

```bash
python -m unittest discover -v
```

Хүлээгдэх үр дүн: `Ran 2 tests ... OK` (формат хувилбараас хамаарна). `discover` нь `test*.py` хэв маягийн тестийг хайна; `-v` дэлгэрэнгүй мэдээлэл гаргана. `No tests found` бол файлын нэр, хавтсын байрлал, import error-ийг шалга.

```python
import logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
logging.info("processed %d records", 3)
```

Нууц, password, bearer token, хувийн мэдээллийг log-д гаргахгүй. Дибаг хийхдээ traceback-ийн **хамгийн сүүлчийн мөр** болон өөрийн файлд заасан дугаараас эхэл.

**Дасгал:** `divide()`-д negative/decimal тест нэм; `test_normal`-ийг санаатай унагаж traceback унш; тест давтагдах боломжтой (`deterministic`) байгаа эсэхийг шалга.

## 12. Algorithms, complexity, өгөгдлийн бүтэц сонголт

`algorithm` нь асуудал шийдэх алхмууд. `Big-O` нь оролт ихсэхэд ажиллах цаг/санах ойн өсөлтийг ерөнхийлнө. `O(1)` — тогтмол, `O(n)` — шугаман, `O(n log n)` — түгээмэл сайн sorting complexity, `O(n²)` — давхар nested scan. Үргэлж бодит хэмжилттэй хамт бодолц.

```python
# O(n) — утгыг нэг нэгээр хайна
def contains(items: list[int], target: int) -> bool:
    for item in items:
        if item == target:
            return True
    return False

# set-ийн membership нь дунджаар O(1)
allowed = {10, 20, 30}
print(20 in allowed)  # True
```

```python
from collections import Counter, deque
from bisect import bisect_left

print(Counter("banana"))        # Counter({'a': 3, 'n': 2, 'b': 1})
queue = deque(["a", "b"])
print(queue.popleft())           # a
print(bisect_left([2, 5, 8], 5)) # 1
```

`set` hashable element шаарддаг; hashing нь normal usage-д сайн ч худал амлалт болох worst-case deterministic O(1) биш. `sorted()` шинэ list буцаана, `.sort()` эх list-ийг өөрчилдөг.

**Дасгал:** (1) Дунджаар хурдан membership хэрэгтэй үед `set` ашигла. (2) Давхардсан ID тоол. (3) Queue-г `deque`-ээр хийгээд FIFO (First In, First Out) зарчмыг харуул.

## 13. Concurrency: Thread, Process, asyncio

`concurrency` нь олон ажил хооронд нь уялдуулж гүйцэтгэх; `parallelism` нь үнэхээр зэрэг CPU дээр ажиллах. `threading` нь I/O хүлээлттэй ажлуудад тустай; `multiprocessing` тусдаа process ашиглах боломжтой; `asyncio` нь `await`-аар cooperative scheduling хийдэг. Энэ нь автоматаар бүх кодыг хурдлуулахгүй.

```python
import asyncio

async def fetch_simulated(name: str) -> str:
    await asyncio.sleep(0.1)   # сүлжээний хүсэлт БИШ, зөвхөн simulation
    return f"{name}: ready"

async def main():
    results = await asyncio.gather(
        fetch_simulated("task-A"), fetch_simulated("task-B")
    )
    print(results)

asyncio.run(main())
# ['task-A: ready', 'task-B: ready']
```

```python
from concurrent.futures import ThreadPoolExecutor

with ThreadPoolExecutor(max_workers=2) as pool:
    print(list(pool.map(lambda n: n * n, [1, 2, 3])))
# [1, 4, 9]
```

**Эрсдэл:** Shared mutable state → race condition; lock ашиглан critical section хамгаал. `asyncio` coroutine дотор `time.sleep()` гэх мэт blocking call хийвэл event loop гацаана. `multiprocessing` дээр Windows/macOS-д `if __name__ == "__main__":` хамгаалалт чухал.

**Дасгал:** `asyncio.gather` ашиглан гурван симуляцийн ажил гүйцэтгэ; нэг ажлыг `await asyncio.sleep()`-оор хүлээлгэ; sync/async ялгааг тайлбарла.

## 14. Production-quality Python ба secure coding

**Цэвэр кодын шалгуур:** нэр ойлгомжтой, нэг function нэг үүрэгтэй, input validation ил тод, exception нь утгатай, тесттэй, dependency version хянадаг, secrets hardcode хийгээгүй, log-д эмзэг мэдээлэл байхгүй. `lint`/`format` tools — `ruff`, `black`; type tools — `mypy`/`pyright` (сонголттой).

```python
# АЮУЛТАЙ ХЭВ МАЯГ: shell=True + user input
# subprocess.run(f"echo {user_input}", shell=True)

# АЮУЛГҮЙ ХУВИЛБАР: arguments list, shell=False (default)
import subprocess
subprocess.run(["echo", "hello"], check=True)
```

Жишээ нь `echo` Windows дээр shell built-in байдаг тул Windows-д энэ snippet ажиллахгүй байж болно; зарчим нь *shell parsing* хэрэглэхгүйгээр program болон аргументуудыг тусад нь дамжуулах явдал. Хэрэглэгчийн input-аас executable нэрийг чөлөөтэй сонгож болохгүй — allowable list хэрэгтэй.

```python
# Secret-ийг source code-д хадгалахгүй
import os
api_key = os.getenv("MY_APP_API_KEY")
if api_key is None:
    print("Configuration missing")  # Нууц утгыг хэвлэхгүй
```

**Security code review-д үзэх зүйлс:**

| Кодын хэв маяг | Эрсдэл | Илүү зөв шийдэл |
|---|---|---|
| `eval(user_text)` | Arbitrary code execution | `json.loads`, зөвшөөрөгдсөн parser |
| `pickle.loads(untrusted)` | Unsafe deserialization | JSON зэрэг data-only format |
| string concatenation SQL | SQL injection | Parameterized query |
| `subprocess(..., shell=True)` | Command injection | Argument list, allowlist |
| `Path(base) / untrusted_name` | Path traversal | Canonical path validation, зөвшөөрөгдсөн нэр |
| `except Exception: pass` | Алдаа нуугдана | Narrow exception + structured logging |

```python
# Parameterized query — sqlite3 (server хэрэггүй, in-memory DB)
import sqlite3
with sqlite3.connect(":memory:") as db:
    db.execute("CREATE TABLE users (name TEXT)")
    db.execute("INSERT INTO users (name) VALUES (?)", ("Anu",))
    rows = db.execute("SELECT name FROM users WHERE name = ?", ("Anu",)).fetchall()
    print(rows)  # [('Anu',)]
```

`?` placeholder нь утгыг SQL syntax болгон нийлүүлдэггүй; SQL identifier (table name) dynamic бол allowlist шаарддаг. Энэ бол offline demonstration, network/server ажиллахгүй.

**Дасгал:** Энэ хүснэгт дэх 6 anti-pattern-аас аль нь зөвхөн *таамагласан* эрсдэл, аль нь баталгаажуулах шаардлагатайг тайлбарла; `eval`-гүйгээр JSON parse хий.

## 15. Python capstone projects: Beginner → Advanced

**Project P1 — Expense Tracker (Beginner):** `date`, `category`, `amount` бүхий CSV файл хөтөлнө. `add/list/summary` CLI командтай; `amount > 0` шалгана; category-гаар нийлбэр гаргана. Зөвхөн `csv`, `argparse`, `decimal`, `pathlib` ашигла.

**Project P2 — Asset Inventory Analyzer (Intermediate):** `assets.csv` уншаад давхардсан hostname, дутуу owner, outdated inventory timestamp-ийг илрүүлж `report.json` гаргана. Data validation, `dataclass`, custom exceptions, test case 8+ ашигла. Нууц IP, жинхэнэ байгууллагын мэдээлэл оруулахгүй, sample data зохио.

**Project P3 — Offline Code Safety Checker (Advanced):** Өөрийн жишээ Python файлуудаас `eval(`, `shell=True`, `pickle.loads(` гэсэн *сэжигтэй pattern*-ийг `ast` модуль ашиглан илрүүлээд file/line/code-type тайлан гарга. Энэ нь **SAST heuristic** болохоос vulnerability-г нотлохгүй. False positive-ийн жишээ 3-аас доошгүй бэлд; syntax error-тэй файлыг тусад нь мэдээл.

**Төсөл хүлээн авах шалгуур:**
- `README.md`: хэрхэн ажиллуулах, ямар input авдаг, ямар output өгөх, хязгаарлалтууд.
- `src/` эсвэл ойлгомжтой module бүтэц; `tests/` хавтас.
- Энгийн болон алдаатай оролтын 8+ test, 1 integration scenario.
- File path болон exception хамгаалалт; хувийн мэдээлэлгүй example data.
- Санаатай bug үүсгээд test-ээр барьж, зассанаа нотолсон богино report.

### Python self-assessment

| Түвшин | Чадварын шалгуур |
|---|---|
| Beginner | `if/for/function/list/dict`-ээр 100 мөрөөс бага програм бие даан бичдэг |
| Intermediate | File I/O, OOP, modules, CLI, unittest-тэй 500+ мөр орчим төсөл зохион байгуулдаг |
| Advanced-oriented | Type design, concurrency tradeoff, packaging, profiler, security review, tests, documentation болон maintainability-ийг бие даан тайлбарладаг |

> **Санамж:** Зөвхөн материал уншаад Advanced болдоггүй. Өөрийн бичсэн кодыг олон удаа засварлаж, тест, code review, бодит төслийн туршлага хуримтлуулна.

### Python албан эх сурвалж
- Python language tutorial — https://docs.python.org/3/tutorial/
- Python standard library — https://docs.python.org/3/library/
- Python packaging / venv — https://packaging.python.org/en/latest/guides/installing-using-pip-and-virtual-environments/
- Python `unittest` — https://docs.python.org/3/library/unittest.html
- Python `asyncio` — https://docs.python.org/3/library/asyncio.html
- Python Security Considerations — https://docs.python.org/3/library/security_warnings.html
